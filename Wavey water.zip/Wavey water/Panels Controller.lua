

require("script")
if host:isHost() then
local panels = require('panels.main')
local page = panels.newPage('main')
local spawner = panels.newPage('spawner')
local physics = panels.newPage('physics')
local miscellaneous = panels.newPage('miscellaneous')
panels.setPage(page)
do
    local obj = page:newText()
    obj:setText('Entities')
    obj:setSize(2, 2)
    obj:setMargin(4)
  end
  page:newSlider():setText(' :ping4: Set Size'):setColor(1, 1, 1):setMax(100.00000001):setValue(sizewaves):setStep(0.01, 1):allowWarping(true):onScroll(function(value, self) pings.sizewaves(value) end)
  page:newSlider():setText(' :ping4: Set Speed'):setColor(1, 1, 1):setMax(100.00000001):setValue(speed):setStep(0.01, 1):allowWarping(true):onScroll(function(value, self) pings.speed(value) end)
  page:newSlider():setText(' :ping4: Set Height'):setColor(1, 1, 1):setMax(100.00000001):setValue(speed):setStep(0.01, 1):allowWarping(true):onScroll(function(value, self) pings.size2(value) end)



end
function pings.speed(value)
  speed = value
end
function pings.sizewaves(value)
sizewaves = value
end
function pings.size2(value)
  size2 = value
  end