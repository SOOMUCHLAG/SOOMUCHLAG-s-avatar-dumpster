scale = 0
x = 0
y = 0
size2 = 2
size =50
pos = 0
positions = {}
place = false
Sprites ={}
sizewaves = 0.84
speed= 2
models.Body:setParentType("WORLD")
function events.entity_init()
  pos = vec(math.floor(player:getPos().x),math.floor(player:getPos().y),math.floor(player:getPos().z)) - vec(size/2,150,size/2)
  smalltext = textures:newTexture(""..math.random(), 1, 1)
  smalltext:setPixel(0,0,1,1,1)
while y <= size do
  place = false
scale = 1
block, hitPos, side = raycast:block(pos+vec(x,300,y), pos+vec(x,0,y), "COLLIDER", "ANY")
if #block:getFluidTags() ~= 0 then
place = true
end
local block1, hitPos1, side1 = raycast:block(pos+vec(x+1,300,y), pos+vec(x+1,0,y), "COLLIDER", "ANY")

if #block1:getFluidTags() ~= 0 and  #block:getFluidTags() ~= 0 then
  local block2, hitPos2, side2 = raycast:block(pos+vec(x+1,300,y), pos+vec(x+1,0,y), "COLLIDER", "ANY")
  while #block2:getFluidTags() ~= 0 and x <= size-1 and hitPos.y == hitPos2.y do
    x=x+1
    local mysprite = models.Body:newSprite(""..math.random()..math.random()):setTexture("textures/block/water_still.png",16,16):setDimensions(16, 512):setPos(0,1,0)

    mysprite:getVertices()[1]:setPos(-pos.x_z*16+32*vec(0,0,pos.z) +vec(-x,-hitPos.y,y)*16)
    mysprite:getVertices()[2]:setPos(-pos.x_z*16+32*vec(0,0,pos.z) +vec(-x,-hitPos.y,y+1)*16)
    mysprite:getVertices()[3]:setPos(-pos.x_z*16+32*vec(0,0,pos.z) +vec(-x+1,-hitPos.y,y+1)*16)
    mysprite:getVertices()[4]:setPos(-pos.x_z*16+32*vec(0,0,pos.z) +vec(-x+1,-hitPos.y,y)*16)
    mysprite:setColor(0.27058, 0.67843, 0.94901)

   table.insert(Sprites,mysprite)
   table.insert(positions,{mysprite:getVertices()[1]:getPos(),mysprite:getVertices()[2]:getPos(),mysprite:getVertices()[3]:getPos(),mysprite:getVertices()[4]:getPos()})

 block2, hitPos2, side2 = raycast:block(pos+vec(x,300,y), pos+vec(x,0,y), "COLLIDER", "ANY")
 scale = scale + 1
  end
  local copy = models.Body.bone:copy("block")
  models.Body.bone2:addChild(copy)
  copy:setPos((pos.x_z+vec(x-scale/2,math.ceil(hitPos.y)-0.35,y))*16)
  copy:setScale(scale,1,1)
  copy:setLight(16)

else
if place then
  local copy = models.Body.bone:copy("block")
  models.Body.bone2:addChild(copy)
  copy:setPos((pos.x_z+vec(x,pos.y+hitPos.y,y))*16)
  copy:setLight(16)

end
end

x=x+1
if x >= size-1 then
y = y+1
x= 0
end  
  end




end
timer = 0
function events.tick()
  time = client:getSystemTime()/1000
timer = timer + 1
if timer >= 31 then
  timer = 0
end
  for i, mysprite in pairs(Sprites) do
    mysprite:getVertices()[1]:setPos(positions[i][1]+vec(math.sin((time+positions[i][1].x+positions[i][1].z)*speed)*1.5,math.sin((time+positions[i][1].y+positions[i][1].x)*speed)*size2,(math.cos((time+positions[i][1].z)*speed)+math.sin(time+positions[i][1].z-positions[i][1].x*speed))*2)*sizewaves)
    mysprite:getVertices()[2]:setPos(positions[i][2]+vec(math.sin((time+positions[i][2].x+positions[i][2].z)*speed)*1.5,math.sin((time+positions[i][2].y+positions[i][2].x)*speed)*size2,(math.cos((time+positions[i][2].z)*speed)+math.sin(time+positions[i][2].z-positions[i][2].x*speed))*2)*sizewaves)
    mysprite:getVertices()[3]:setPos(positions[i][3]+vec(math.sin((time+positions[i][3].x+positions[i][3].z)*speed)*1.5,math.sin((time+positions[i][3].y+positions[i][3].x)*speed)*size2,(math.cos((time+positions[i][3].z)*speed)+math.sin(time+positions[i][3].z-positions[i][3].x*speed))*2)*sizewaves)
    mysprite:getVertices()[4]:setPos(positions[i][4]+vec(math.sin((time+positions[i][4].x+positions[i][4].z)*speed)*1.5,math.sin((time+positions[i][4].y+positions[i][4].x)*speed)*size2,(math.cos((time+positions[i][4].z)*speed)+math.sin(time+positions[i][4].z-positions[i][4].x*speed))*2)*sizewaves)
    
  end
end

function events.render(delta, context)

end
