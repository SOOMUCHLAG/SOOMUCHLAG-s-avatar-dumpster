-- Auto generated script file --
Start = nil
Dest = nil
Triggered = false
Triggered2 = false

Velocity = vec(0,0,0)

Timer = 0
PrevPos = {}
Points = {}
Copies = {}
Velocity = {}
Lengths = {}
MaxLength = 0
GravitySwitch = false
models.block:setParentType("WORLD")
function VectorToAngles(dir)
  dir:normalize()
    return vec(-math.deg(math.atan2(dir.y, math.sqrt(dir.x * dir.x + dir.z * dir.z))), math.deg(math.atan2(dir.x, dir.z)), 0)
end

--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()
Start = player:getPos()
end


function events.tick()



  for i, copy in pairs(Copies)do

    PrevPos[i] = Points[i]
    Points[i] = Points[i] - Gravity*0.05


 local block, hitPos1, side = raycast:block(PrevPos[i], vec(PrevPos[i].x ,Points[i].y,PrevPos[i].z))
if hitPos1.y ~= Points[i].y then
Points[i].y = hitPos1.y+0.001

end


end

  if Dest ~= nil and Start ~= nil then
    FABRIK()
    end  
    for i = 1, #Copies-1 do 

      Copies[i]:setRot(VectorToAngles(Points[i]-Points[i+1]))

    end
end


function events.render(delta, context, matrix)
Timer = Timer + 0.1
  if player:isCrouching() then
  Dest = player:getPos(delta):add(0,0.9,0) -vectors.angleToDir(vec(0,player:getBodyYaw(delta)))*(0.3-Timer/100000)
  else
    Dest = player:getPos(delta):add(0,1.1,0)-vectors.angleToDir(vec(0,player:getBodyYaw(delta)))*(0.3-Timer/100000)
  end
  if PrevPos[1]~=nil then
for i, copy in pairs(Copies)do

  copy:setPos(math.lerp(PrevPos[i].x*16,Points[i].x*16,delta),math.lerp(PrevPos[i].y*16,Points[i].y*16,delta),math.lerp(PrevPos[i].z*16,Points[i].z*16,delta))

end
end

  if not Triggered and Start ~= nil then
    table.insert(Points,Start)

  for i = 1, AmountOfPoints do
    table.insert(Points,Start+vec(0,i/density,0))

  end
  for i, point in pairs(Points) do
    if i < #Points then
    table.insert(Lengths, math.sqrt(math.abs(Points[i].y - Points[i+1].y)^2 + math.sqrt( (math.abs(Points[i].x - Points[i+1].x)^2 + math.abs(Points[i].z - Points[i+1].z)^2)^2 )))
  end 
end
MaxLength = 0
for i, length in pairs(Lengths) do
MaxLength = MaxLength + length
end
for i, point in pairs(Points) do
  local copy = models.block.bone:copy("block")
models.block.bone2:addChild(copy)
if i == #Points then 
copy:setVisible(false)
end
copy:setPrimaryRenderType("EMISSIVE_SOLID")

if i < #Points then
copy:setScale(Lengths[i]*2*density,Lengths[i]*0.6*density,Lengths[i]*2.66*density)
end
table.insert(Copies, copy)
  end
Triggered = not Triggered
end


end

--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
  --code goes here
end




function FABRIK()
Points[#Points] = Dest 
  for i, point in pairs(Points) do
    if i < #Points then
  Points[#Points-i] = (Points[#Points-i] - Points[#Points-i+1]):normalize()*Lengths[#Lengths-i+1]+Points[#Points-i+1]
  end
end
Start = Points[1]
end