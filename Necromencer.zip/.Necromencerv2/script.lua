--to do: verticy check


opacity = 1
opacityswitch = false
r = 1
g = 1
b = 1
local is_skeleton = true
local x_spacing = 1
local z_spacing = 1
local x_count = 5
local z_count = 5
local x_base = -2
local z_base = -2
local x_scale = 1
local y_scale = 1
local z_scale = 1
visibility = 1
parenttype = 1
models.skelly:setParentType("World")
models.zombie:setParentType("World")
models.skelly.skel:setVisible(false)
models.zombie.skel:setVisible(false)
models.skelly.skel.RightArm:setRot(-90, 0, 0)
models.zombie.skel.RightArm:setRot(-90, 0, 0)

vanilla_model.RIGHT_ARM:setOffsetRot(90, 0, 0)
models.staff.RightArm.root:setRot(-90, 0, 0)
models.staff.RightArm.root:setPos(8, -8, 15)

animations.staff.idle:play()

local copies = {}
local should_delete_grid = false
local sound_timer = 0



function events.render(delta, context)


    if parenttype == 1 then
    local blockLight = world.getBlockLightLevel(player:getPos():add(0,.2,0))
    local skyLight = world.getSkyLightLevel(player:getPos():add(0,.2,0))





    for k, copy in pairs(copies) do
        if #copies == 1 then


            renderer:setCameraPivot(copy.copy.Head:partToWorldMatrix():apply().x, copy.copy.Head:partToWorldMatrix():apply().y + (0.25*y_scale), copy.copy.Head:partToWorldMatrix():apply().z) 
            
        end

        local offsets = calculate_offsets(copy.i, copy.j)
        copy.copy:setPos(offsets.xoff + (player:getPos(delta).x * 16), 0 + (player:getPos(delta).y * 16), offsets.zoff + (player:getPos(delta).z * 16)) 
        copy.copy:setLight(blockLight,skyLight)
        copy.copy:setRot(0, -player:getRot().y + 180, 0)
        copy.copy:setPivot(___)


end
if #copies > 1 or #copies == 0 then
    renderer:setCameraPivot(vanilla_model.HEAD:getPos())

    end

end
end
function hide()
    visibility = 0
    models.skelly.group1:setVisible(false)
    models.skelly.group:setVisible(false)
    models.zombie.group1:setVisible(false)
    models.zombie.group:setVisible(false)
    log("OFF")
end
function unhide()
    visibility = 1
    log("ON")
    models.skelly.group1:setVisible(true)
    models.skelly.group:setVisible(true)
    models.zombie.group1:setVisible(true)
    models.zombie.group:setVisible(true)
end 



function create_copy(is_skeleton, xoff, zoff)
    if parenttype == 0 then
    local name = is_skeleton and "skelly" or "zombie"
    local copy = models[name].skel:copy("name")
    models[name].group:addChild(copy)
    copy:setPos(xoff, 0, zoff)
    copy:setVisible(true)
    return copy
    end
if parenttype == 1 then
    local name = is_skeleton and "skelly" or "zombie"
    local copy = models[name].skel:copy("name")
    models[name].group1:addChild(copy)
    copy:setPos(xoff, 0, zoff)
    copy:setVisible(true)
    return copy
end
    
end

function calculate_offsets(i, j)
    local xoff = (i * x_spacing + x_base) * 16
    local zoff = (j * z_spacing + z_base) * 16
    local yaw = player:getBodyYaw()
    local sin = math.sin(math.rad(yaw))
    local cos = math.cos(math.rad(yaw))
    local rxoff = xoff * cos + zoff * sin
    local rzoff = zoff * cos - xoff * sin
    local nth = 0
    local nth1 = 0
    if parenttype == 0 then
    return {xoff = rxoff, zoff = rzoff}
    end
    if parenttype == 1 then 
    return {xoff = xoff, zoff = zoff}
    end
end

function create_grid()
    copies = {}
    for i = 0, x_count - 1 do
        for j = 0, z_count - 1 do
            local offsets = calculate_offsets(i, j)
            local copy = create_copy(is_skeleton, offsets.xoff, offsets.zoff)
            copy:setScale(x_scale, y_scale, z_scale)
            if opacityswitch == true then
            copy:setOpacity(opacity)
            end
            copy:setColor(r,g,b)
            table.insert(copies, {copy = copy, i = i, j = j})
        end
    end





end

function update_grid_positions()
    if parenttype == 0 then
    for k, copy in pairs(copies) do
        local offsets = calculate_offsets(copy.i, copy.j)
        copy.copy:setPos(offsets.xoff, 0, offsets.zoff)
    end
    end

end

function delete_grid()
    for k, copy in pairs(copies) do
        copy.copy:getParent():removeChild(copy.copy)
    end
    copies = {}
    should_delete_grid = false
end

function update_grid()
    if #copies == 0 then return end
    delete_grid()
    create_grid()
    if parenttype == 0 then
        models.skelly.group:setVisible(true)
        models.zombie.group:setVisible(true)  
        models.skelly.group1:setVisible(false)
        models.zombie.group1:setVisible(false)
        end
        if parenttype == 1 then
            models.skelly.group:setVisible(false)
            models.zombie.group:setVisible(false)  
            models.skelly.group1:setVisible(true)
            models.zombie.group1:setVisible(true)  
            end
end

function visibilityOFF()
    vanilla_model.PLAYER:setVisible(false)
    models.staff.RightArm:setVisible(false)
    log("ON")
end

function visibilityON()
    vanilla_model.PLAYER:setVisible(true)
    models.staff.RightArm:setVisible(true)
    log("OFF")
end

function pings.create_grid() create_grid() end
function pings.update_grid_positions() update_grid_positions() end
function pings.delete_grid() delete_grid() end
function pings.update_grid() update_grid() end
function pings.set_x_spacing(s) x_spacing = s end
function pings.set_z_spacing(s) z_spacing = s end
function pings.set_x_count(s) x_count = s update_grid() end
function pings.set_z_count(s) z_count = s update_grid() end
function pings.set_x_base(s) x_base = s end
function pings.set_z_base(s) z_base = s end
function pings.set_is_skeleton(s) is_skeleton = s end
function pings.set_x_scale(s) x_scale = s update_grid() end
function pings.set_y_scale(s) y_scale = s update_grid() end
function pings.set_z_scale(s) z_scale = s update_grid() end
function pings.setparenttype1() setparenttypePlayer() end
function pings.setparenttype2() setparenttypeWorld() end
function pings.visibility1() visibilityOFF() end
function pings.visibility2() visibilityON() end
function pings.opacity() update_grid() end
function pings.opacityswitchON() opacityswitch = true log("ON") update_grid() end
function pings.opacityswitchOFF() opacityswitch = false log("OFF") update_grid() end
function pings.r(s) r = s update_grid() end
function pings.g(s) g = s update_grid() end
function pings.b(s) b = s update_grid() end
   
    function pings.summon()
    if animations.skelly.spawn:isPlaying() or animations.zombie.spawn:isPlaying() then return end
    if animations.skelly.banish:isPlaying() or animations.zombie.banish:isPlaying() then return end
    if #copies > 0 then delete_grid() end
    create_grid()
    animations.staff.stomp:play()
    animations[is_skeleton and "skelly" or "zombie"].spawn:play()
end
function pings.banish()
    if animations.skelly.spawn:isPlaying() or animations.zombie.spawn:isPlaying() then return end
    if animations.skelly.banish:isPlaying() or animations.zombie.banish:isPlaying() then return end
    if #copies == 0 then return end
    animations.staff.stomp:play()
    animations[is_skeleton and "skelly" or "zombie"].banish:play()
    should_delete_grid = true
end

function setparenttypePlayer()
    models.skelly:setParentType("Player")
    models.zombie:setParentType("Player")
    parenttype = 0
    log("OFF")
end
function setparenttypeWorld()
    models.skelly:setParentType("World")
    models.zombie:setParentType("World")
    log("ON")
    parenttype = 1
end

events.TICK:register(function()
    if #copies > 0 then update_grid_positions() end
    if should_delete_grid and not animations.skelly.banish:isPlaying() and not animations.zombie.banish:isPlaying() then
        pings.delete_grid()
    end
    if (animations.skelly.spawn:isPlaying() or animations.zombie.spawn:isPlaying()
        or animations.skelly.banish:isPlaying() or animations.zombie.banish:isPlaying()) then
        if sound_timer == 0 then
            sounds:playSound("gravel1", player:getPos(), 50, 0.75, false)
            sounds:playSound("grass3", player:getPos(), 50, 1.25, false)
            sound_timer = 10
        end
        sound_timer = sound_timer - 1
    end

end)
function events.tick()

        end
local page = action_wheel:newPage()
action_wheel:setPage(page)

page:newAction()
    :setTitle("Change X spacing")
    :setItem("oak_trapdoor")
    :setColor(0, 0, 0.5)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        x_spacing = math.max(0, x_spacing + dir / 4)
        pings.set_x_spacing(x_spacing)
        log("§aX spacing is now " .. x_spacing)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

page:newAction()
    :setTitle("Change Z spacing")
    :setItem("oak_fence")
    :setColor(0, 0.5, 0)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        z_spacing = math.max(0, z_spacing + dir / 4)
        pings.set_z_spacing(z_spacing)
        log("§aZ spacing is now " .. z_spacing)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

page:newAction()
    :setTitle("Change X count")
    :setItem("blue_dye")
    :setColor(0, 0.5, 1)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        x_count = math.max(0, x_count + dir)
        pings.set_x_count(x_count)
        log("§aX count is now " .. x_count)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

page:newAction()
    :setTitle("Change Z count")
    :setItem("green_dye")
    :setColor(0, 1, 0.5)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        z_count = math.max(0, z_count + dir)
        pings.set_z_count(z_count)
        log("§aZ count is now " .. z_count)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

page:newAction()
    :setTitle("Change X Offset")
    :setItem("purple_dye")
    :setColor(0.5, 0, 1)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        x_base = x_base + dir / 4
        pings.set_x_base(x_base)
        log("§aX Offset is now " .. x_base)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

page:newAction()
    :setTitle("Change Z Offset")
    :setItem("lime_dye")
    :setColor(0.5, 1, 0)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        z_base = z_base + dir / 4
        pings.set_z_count(z_count)
        log("§aZ Offset is now " .. z_base)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

page:newAction()
    :setTitle("Switch to Zombie")
    :setItem("zombie_head")
    :setColor(0.5, 0, 0)
    :setHoverColor(0, 1, 0)
    :setOnLeftClick(function(this)
        is_skeleton = not is_skeleton
        pings.set_is_skeleton(is_skeleton)
        this:setTitle("Switch to " .. (is_skeleton and "Zombie" or "Skeleton"))
        this:setItem(is_skeleton and "zombie_head" or "skeleton_skull")
        pings.update_grid()
    end)

page:newAction()
    :setTitle("Summon")
    :setItem("structure_block")
    :setColor(0.5, 0.5, 0.5)
    :setHoverColor(0, 1, 0)
    :setOnLeftClick(function(this)
        if this:getTitle() == "Summon" then
            pings.summon()
            this:setTitle("Banish")
            this:setItem("structure_void")
        else
            pings.banish()
            this:setTitle("Summon")
            this:setItem("structure_block")
        end
    end)

page:newAction()
    :setTitle("Change X scale")
    :setItem("blue_wool")
    :setColor(0, 0, 0.5)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        x_scale = math.max(0, x_scale + dir / 4)
        pings.set_x_scale(x_scale)
        log("§aX scale is now " .. x_scale)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

page:newAction()
    :setTitle("Change Y scale")
    :setItem("red_wool")
    :setColor(0.5, 0, 0)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        y_scale = math.max(0, y_scale + dir / 4)
        pings.set_y_scale(y_scale)
        log("§aY scale is now " .. y_scale)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

page:newAction()
    :setTitle("Change Z scale")
    :setItem("green_wool")
    :setColor(0, 0.5, 0)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        z_scale = math.max(0, z_scale + dir / 4)
        pings.set_z_scale(z_scale)
        log("§aZ scale is now " .. z_scale)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)


    page:newAction()
    :setTitle("World Parent Type Toggle")
    :setItem("crafting_table")
    :setColor(0, 0.5, 0)
    :setHoverColor(0, 1, 0)
    :setOnLeftClick(function(this)
        pings.setparenttype1()

    end)
    :setOnRightClick(function(this)
        pings.setparenttype2()

    end)

    page:newAction()
    :setTitle("Player visibility")
    :setItem("ender_eye")
    :setColor(0, 0, 0)
    :setHoverColor(0, 1, 0)
    :setOnLeftClick(function(this)
       pings.visibility1() 
    end)
    :setOnRightClick(function(this)
       pings.visibility2() 

    end)

    page:newAction()
    :setTitle("Mob Visibility(Client-side)")
    :setItem("ender_eye")
    :setColor(0, 0, 0)
    :setHoverColor(0, 1, 1)
    :setOnLeftClick(function(this)
hide()
    end)
    :setOnRightClick(function(this)
unhide()

    end)

    page:newAction()
    :setTitle("Opacity")
    :setItem("white_stained_glass")
    :setColor(0.5, 0, 0)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        opacity = math.max(0, opacity + dir / 32)
        pings.opacity(opacity)
        log("§aOpacity is now " .. opacity)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

    page:newAction()
    :setTitle("Opacity Toggle(Note:This setting disables clientside mob hiding and its global meaning other players will see the opacity change)")
    :setItem("white_stained_glass")
    :setColor(0, 0, 0)
    :setHoverColor(0, 1, 1)
    :setOnLeftClick(function(this)
        pings.opacityswitchOFF()
    end)
    :setOnRightClick(function(this)

        pings.opacityswitchON()
    end)

    page:newAction()
    :setTitle("R")
    :setItem("red_dye")
    :setColor(0.5, 0, 0)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        r = math.max(0, r + dir/64)
        pings.r(r)
        log("§aR is now " .. r)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

    page:newAction()
    :setTitle("G")
    :setItem("green_dye")
    :setColor(0, 0.5, 0)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        g = math.max(0, g + dir/64)
        pings.g(g)
        log("§aG is now " .. g)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

    page:newAction()
    :setTitle("B")
    :setItem("blue_dye")
    :setColor(0, 0, 0.5)
    :setHoverColor(0, 1, 0)
    :setOnScroll(function (dir)
        b = math.max(0, b + dir/64)
        pings.b(b)
        log("§aG is now " .. b)
    end)
    :setOnLeftClick(function() log("§cUse the scroll wheel") end)

    page:newAction()
    :setTitle("INFO:Deafault for RBG values is R = 1 G = 1 B = 1. Changing them all to 0 will result in pitch black minions.")
    :setItem("oak_sign")
    :setColor(1, 1, 1)






