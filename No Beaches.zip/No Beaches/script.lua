-- Auto generated script file --
x = 0 
z = 0
Copies = {}
Time = 0
models.BBB:setParentType("World")
--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()

end

--tick event, called 20 times per second
function events.tick()
Time = Time + 1

local finished = false
if Time%60 == 1 then
  Dematerialize()
  x = 256
  z = 256
  x1 = x
  z1 = z
while finished ~= true do
    if world.getBiome(math.floor(player:getPos().x) +x1,0,math.floor(player:getPos().z) +z1).id == "minecraft:beach" then
      PlaceBlock(vec(math.floor(player:getPos().x) + x1, 0 ,math.floor(player:getPos().z) + z1))
    end
    x1 = x1 - 4

    if x1 < -x then

      z1 = z1-4
      x1 = x
  end  
  if z1 < -z then
    finished = true
end  
end  
end
end

--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
  --code goes here
end


function PlaceBlock(pos)
  local copy = models.BBB.bone:copy("block")
  models.BBB.bone2:addChild(copy)
  copy:setVisible(true)
  copy:setPos((pos.x*16),20*16,(pos.z*16))
  copy:setScale(4,200,4)
  copy:setColor(0,0,0,1)
  table.insert(Copies, copy)
end  


function Dematerialize()
  if Copies ~= {} then
    for k ,copy in pairs(Copies) do
    copy:getParent():removeChild(copy)
    end
    Copies = {}
  end
end