copies = {}
rotcopies ={}
branches = {}
branchlengthmin = 5
branchlengthmax = 20
reach = 30
branchrandomness = 60
branchchance = 0.15
state = false
timer = 0
spellStorage3 = models:newPart("copyStorage", "WORLD")
spellStorage2 = models:newPart("copyStorage", "WORLD")
models.cube:setParentType("WORLD")
models.plane:setParentType("World")
function events.tick()
  yes = true
end
local exampleKey = keybinds:newKeybind("Keybind Name", "key.keyboard.h", false)
exampleKey.press = function()
state = true
end  
exampleKey.release = function()
  state = false
end 
function events.entity_init()

end
num = 1
function VectorToAngles(dir)
  dir:normalize()
    return vec(-math.deg(math.atan2(dir.y, math.sqrt(dir.x * dir.x + dir.z * dir.z))), math.deg(math.atan2(dir.x, dir.z)), 0)
end
-- Auto generated script file --
--entity init event, used for when the avatar entity is loaded for the first time


--tick event, called 20 times per second
function events.tick()
if state then
  local reached = false
  local pos = player:getPos()+vec(0,player:getEyeHeight(),0)
  local prevPos
  local dest = player:getPos()+player:getLookDir()*reach+vec(0,player:getEyeHeight(),0)+vec(math.random()-0.5,math.random()-0.5,math.random()-0.5)*5
  branches = {}
  num =1 

  for i = 1, 1 do
  pings.create(player:getPos():length()+client:getSystemTime()*1000+i*10000)
  end
else

    end
end
function events.key_press(key, action, modifier)

if key == 72 and action == 2 then


 -- pings.create(player:getPos():length()+client:getSystemTime()*1000)

end  
end
--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
  for i, copy in pairs(rotcopies) do
      copy:setOffsetRot(VectorToAngles(-copy:getPos()/16+client:getCameraPos())+vec(90,0,0))
  end


end

function pings.create(randseed)
  for i, copy in pairs(rotcopies) do 
    copy:getParent():removeChild(copy)
    copy:remove()
    end
    rotcopies = {}  
    for i, copy in pairs(copies) do 
      copy:getParent():removeChild(copy)
      copy:remove()
      end
      copies = {}  
  if player:isLoaded() then
  math.randomseed(randseed)
  local reached = false
  local pos = player:getPos()+vec(0,reach,0)
  local prevPos
  local dest = player:getPos()
  branches = {}
  num =1 

      while reached == false do
    
    
      if num ~= 1 then
      local copy = models.cube:copy(":skull:")
      spellStorage3:addChild(copy)
      copy:setParentType("WORLD"):setScale(vec(2,2,(pos-prevPos):length()*16)):setPos(pos*16):setPrimaryRenderType("EMISSIVE_SOLID"):setRot(VectorToAngles(pos-prevPos)):setOpacity(0.8)
      table.insert(copies,copy)
      local copy = models.plane.plane:copy(":skull:")
      for i, vertextbl in pairs(copy.plane:getAllVertices()) do
        for i, vertex in pairs(vertextbl) do
        vertex:setNormal(1,1,1)
        end
      end
      spellStorage2:addChild(copy)
      copy:setPos(pos*16):setLight(15)
      table.insert(rotcopies,copy)
      local copy = models.plane.plane:copy(":skull:")
      for i, vertextbl in pairs(copy.plane:getAllVertices()) do
        for i, vertex in pairs(vertextbl) do
        vertex:setNormal(1,1,1)
        end
      end
      spellStorage2:addChild(copy)
      copy:setPos((pos-((pos-prevPos)/3))*16):setLight(15)
      table.insert(rotcopies,copy)
      local copy = models.plane.plane:copy(":skull:")
      spellStorage2:addChild(copy)
      for i, vertextbl in pairs(copy.plane:getAllVertices()) do
        for i, vertex in pairs(vertextbl) do
        vertex:setNormal(1,1,1)
        end
      end
      copy:setPos((pos-((pos-prevPos)*2/3))*16):setLight(15)
      table.insert(rotcopies,copy)
      end
      if math.random() <= branchchance then
        table.insert(branches,{pos,math.random(branchlengthmin,branchlengthmax)})
      end
      prevPos = pos
        if (-pos+dest):length() < 1 then
        reached = true  
        end
        pos = pos+(-pos+dest):normalized()*0.6+vec(math.random()-0.5,math.random()-0.5,math.random()-0.5)*1.2
    num = num + 1
    
      end

      for i, branch in pairs(branches) do
  
        local pos = branch[1]
        local prevPos
        local dest1 = (player:getPos()+vec(math.random()-0.5,math.random()-0.5,math.random()-0.5)*branchrandomness)/3 + 2*dest/3
        num = 1
        for i = 1, branch[2] do


          if num ~= 1 then

           local copy = models.cube:copy(":skull:")
           spellStorage3:addChild(copy)
           copy:setParentType("WORLD"):setScale(vec(2,2,(pos-prevPos):length()*16)):setPos(pos*16):setPrimaryRenderType("EMISSIVE_SOLID"):setRot(VectorToAngles(pos-prevPos)):setOpacity(0.8)
           table.insert(copies,copy)
           local copy = models.plane.plane:copy(":skull:")
          for i, vertextbl in pairs(copy.plane:getAllVertices()) do
            for i, vertex in pairs(vertextbl) do
            vertex:setNormal(1,1,1)
            end
          end
           spellStorage2:addChild(copy)
           copy:setPos(pos*16):setLight(15)
           table.insert(rotcopies,copy)
           local copy = models.plane.plane:copy(":skull:")
           for i, vertextbl in pairs(copy.plane:getAllVertices()) do
            for i, vertex in pairs(vertextbl) do
            vertex:setNormal(1,1,1)
            end
          end
           spellStorage2:addChild(copy)
           copy:setPos((pos-((pos-prevPos)/3))*16):setLight(15)
           table.insert(rotcopies,copy)
           local copy = models.plane.plane:copy(":skull:")
           for i, vertextbl in pairs(copy.plane:getAllVertices()) do
            for i, vertex in pairs(vertextbl) do
            vertex:setNormal(1,1,1)
            end
          end
           spellStorage2:addChild(copy)
           copy:setPos((pos-((pos-prevPos)*2/3))*16):setLight(15)
           table.insert(rotcopies,copy)

           if (-pos+dest1):length() < 2 then
            break
            end

           end
           prevPos = pos
           pos = pos+(-pos+dest1):normalized()*0.7+vec(math.random()-0.5,math.random()-0.5,math.random()-0.5)*1.6
           num = num+1
        end 
      end
      for i, copy in pairs(rotcopies) do
        copy:setOffsetRot(VectorToAngles(-copy:getPos()/16+client:getCameraPos())+vec(90,0,0))
    end
    end
end