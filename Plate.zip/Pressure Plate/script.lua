-- Auto generated script file --
soundtimer=0
--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)

--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

vanilla_model.PLAYER:setVisible(false)

function events.entity_init()

       
  
end

function events.tick(context)

    pp = player:getTargetedEntity(entity)
    
    for _, players in pairs(world.getPlayers()) do
        local playerspos = players:getPos()
        if playerspos.x >= player:getPos().x - 0.5 and playerspos.x <= player:getPos().x + 0.5 and playerspos.z >= player:getPos().z - 0.5 and playerspos.z <= player:getPos().z + 0.5 and playerspos.y >= player:getPos().y and playerspos.y <= player:getPos().y + 0.2 then  
        if playerspos == player:getPos() then 
        else
        if soundtimer <= 0 then
            rng = 0
            models:setScale(1, 0.5, 1)
            sounds:playSound("Plate1", player:getPos(),10, 1, false)
            rng = math.random(0,3)
            if rng == 0 then
            sounds:playSound("Sans", player:getPos(), 100, 1, false)
            end
            if rng == 1 then
                sounds:playSound("Pipe", player:getPos(), 100, 1, false)
                end
                if rng == 2 then
                    sounds:playSound("Vine", player:getPos(), 100, 1, false)
                    end
                    if rng == 3 then
                        sounds:playSound("Farb", player:getPos(), 100, 1, false)
                        end
                        soundtimer = 24
        end 
    end
       
       
   end
   
end

soundtimer = soundtimer - 1

if soundtimer == 4 then
    models:setScale(1,1,1)
end 













    --if pp ~= nil then 
--log(pp:getPos())
--end
end

function sounds1()

end