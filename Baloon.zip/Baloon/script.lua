-- Auto generated script file --
Start = nil
Dest = nil

Triggered2 = false

Velocity = {}

Timer = 0
PrevPos = {}
Points = {}
Copies = {}
Velocity = {}
Lengths = {}
MaxLength = 0
GravitySwitch = false
Triggered = true
models.block:setParentType("WORLD")





local speed = 0.2
local distance = 3.5
local height = 4
 cubePos = nil
local _cubePos

function VectorToAngles(dir)
  dir:normalize()
    return vec(-math.deg(math.atan2(dir.y, math.sqrt(dir.x * dir.x + dir.z * dir.z))), math.deg(math.atan2(dir.x, dir.z)), 0)
end
function events.entity_init()
    cubePos = player:getPos()
    models.Balloon.World:setPos(player:getPos()*16)
    _cubePos = cubePos
    Start = player:getPos()
end
function events.tick()
    _cubePos = cubePos
    local target = player:getPos():add(0,height,0):add((cubePos-(player:getPos():add(0,height,0))):normalized()*distance)
    if Points[#Points-1] ~= nil and 0.001 <  math.sqrt(math.abs(Points[#Points-1].y+0.2 - cubePos.y)^2 + math.sqrt( (math.abs(Points[#Points-1].x - cubePos.x)^2 + math.abs(Points[#Points-1].z - cubePos.z)^2)^2 )) and MaxLength-3 <  math.sqrt(math.abs(player:getPos().y - cubePos.y)^2 + math.sqrt( (math.abs(player:getPos().x - cubePos.x)^2 + math.abs(player:getPos().z - cubePos.z)^2)^2 )) and MaxLength ~= 0 then

        cubePos = Points[#Points-1]+vec(0,0.2,0)
    end
      cubePos = math.lerp(cubePos, target, speed)

end
function events.render(delta)
    
  models.Balloon.World:setPos(math.lerp(_cubePos, cubePos, delta)*16)
    if Points[#Points] == nil then 
    models.Balloon.World:setRot(VectorToAngles(_cubePos-cubePos).x*0.1,VectorToAngles(_cubePos-cubePos).y,0)
    else
      models.Balloon.World:setRot(VectorToAngles(_cubePos-Points[#Points]).x*0.1,VectorToAngles(_cubePos-Points[#Points]).y,0)
end
end






function VectorToAngles(dir1)
  dir = vec(dir1.x,dir1.y,dir1.z):normalize()
    return vec(-math.deg(math.atan2(dir.y, math.sqrt(dir.x * dir.x + dir.z * dir.z))), math.deg(math.atan2(dir.x, dir.z)), 0)
end

--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()
Start = nil
end


function events.tick()
Start = player:getPos():add(0,0.6,0)-vectors.angleToDir(vec(0,player:getBodyYaw()))*0
Dest = models.Balloon.World:getPos()/16

  for i, copy in pairs(Copies)do

    PrevPos[i] = Points[i]
    Points[i] = Points[i] - Gravity*0.05


 local block, hitPos1, side = raycast:block(PrevPos[i], vec(PrevPos[i].x ,Points[i].y,PrevPos[i].z))
if hitPos1.y ~= Points[i].y then
Points[i].y = hitPos1.y+0.01

end


end

  if Dest ~= nil and Start ~= nil and Triggered2 == true then
    FABRIK()
  end
    for i = 1, #Copies-1 do 

      Copies[i]:setRot(VectorToAngles(Points[i]-Points[i+1]))

    end

end


function events.render(delta, context, matrix)

  if PrevPos[1]~=nil then
for i, copy in pairs(Copies)do

  copy:setPos(math.lerp(PrevPos[i].x*16,Points[i].x*16,delta),math.lerp(PrevPos[i].y*16,Points[i].y*16,delta),math.lerp(PrevPos[i].z*16,Points[i].z*16,delta))

end
end

  if not Triggered and Start ~= nil and Dest ~= nil then
    table.insert(Points,Start)

  for i = 1, AmountOfPoints do
    table.insert(Points,Start+vec(0,i/density,0))

  end
  for i, point in pairs(Points) do
    if i < #Points then
    table.insert(Lengths, math.sqrt(math.abs(Points[i].y - Points[i+1].y)^2 + math.sqrt( (math.abs(Points[i].x - Points[i+1].x)^2 + math.abs(Points[i].z - Points[i+1].z)^2)^2 )))
  end 
end
MaxLength = 0
for i, length in pairs(Lengths) do
MaxLength = MaxLength + length
end
for i, point in pairs(Points) do
  local copy = models.block.bone:copy("block")
models.block.bone2:addChild(copy)
if i == #Points then 
copy:setVisible(false)
end
copy:setPrimaryRenderType("EMISSIVE_SOLID")

if i < #Points then
copy:setScale(Lengths[i]*0.25*density,Lengths[i]*0.25*density,Lengths[i]*1*density)
end
table.insert(Copies, copy)
  end
Triggered = not Triggered
Triggered2 = not Triggered2
end


end

--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
  --code goes here
end




function FABRIK()
Points[#Points] = Dest

  for i, point in pairs(Points) do
    if i < #Points then
  Points[#Points-i] = (Points[#Points-i] - Points[#Points-i+1]):normalize()*Lengths[#Lengths-i+1]+Points[#Points-i+1]
  end
end
Points[1] = Start
for i, point in pairs(Points) do
  if i ~= 1 and i < #Points then
Points[i] = (Points[i] - Points[i-1]):normalize()*Lengths[i]+Points[i-1]
end
end

end