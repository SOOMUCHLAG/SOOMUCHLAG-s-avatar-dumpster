AmountOfPoints = 100
density = 25
Gravity = vec(0,15,0)
local panels = require('panels.main')
local page = panels.newPage('main')

panels.setPage(page)
do
    local obj = page:newText()
    obj:setText('Cape Settings')
    obj:setSize(2, 2)
    obj:setMargin(4)
  end


  page:newSlider():setText(' :ping4: Change Rope Color'):setColor(1, 1, 1):setMax(360):setValue(0):setStep(1, 1):allowWarping(false):onScroll(function(value, self) pings.SetCapeColor(value) end)
  page:newSlider():setText(' :ping4: Change Rope Saturation'):setColor(1, 1, 1):setMax(100):setValue(90):setStep(1, 1):allowWarping(false):onScroll(function(value, self) pings.SetCapeSatur(value) end)
  page:newSlider():setText(' :ping4: Change Rope Blackness'):setColor(1, 1, 1):setMax(100):setValue(90):setStep(1, 1):allowWarping(false):onScroll(function(value, self) pings.SetCapeBlackness(value) end)
  page:newText():setText({text = ' :ping4: Set Rope Color To Rainbow'}):onPress(function(self) pings.SetCapeRAINBOW() end)
  page:newSlider():setText(' :ping4: Change Rope Segments Amount'):setColor(1, 1, 1):setMax(3000):setValue(AmountOfPoints):setStep(2, 2):allowWarping(false):onScroll(function(value, self) pings.SetSegments(value) pings.Reload() end)
  page:newSlider():setText(' :ping4: Change Rope Segments Density'):setColor(1, 1, 1):setMax(100):setValue(density):setStep(0.25, 0.25):allowWarping(false):onScroll(function(value, self) pings.SetDensity(value) pings.Reload() end)
  page:newText():setText({text = ' :ping4: Reload Rope'}):onPress(function(self) pings.Reload() end)
  page:newSlider():setText(' :ping4: Set Gravity'):setColor(1, 1, 1):setMax(50):setValue(Gravity.y):setStep(0.25, 0.25):allowWarping(false):onScroll(function(value, self) pings.SetGravity(value) end)
  page:newText():setText({text = ' :ping4: Rope Start'}):onPress(function(self) pings.SetStart() end)
  page:newText():setText({text = ' :ping4: Rope End'}):onPress(function(self) pings.SetEnd() end)
  --page:newPageRedirect():setText(' :terraria: Entity Spawner'):setPage('spawner')


--spawner:newText():setText({text = ' :checkmark: Spawn Entity At Your Current Location'}):onPress(function(self) pings.SpawnAtPlayer() end)

--spawner:newSlider():setText(' :creeper: Spawn Amount'):setColor(1, 1, 1):setMax(10.00000001):setValue(1):setStep(1, 1):allowWarping(true):onScroll(function(value, self) pings.SpawnAmount(value) end)

--spawner:newReturnButton()

function pings.SetCapeColor(value)
  for i, copy in pairs(Copies) do
    copy:setColor(vectors.hsvToRGB(vec(value/360,vectors.rgbToHSV(copy:getColor()).y,vectors.rgbToHSV(copy:getColor()).z)))
  
  end 
end
function pings.SetCapeSatur(value)
  for i, copy in pairs(Copies) do
    copy:setColor(vectors.hsvToRGB(vec(vectors.rgbToHSV(copy:getColor()).x,value/100,vectors.rgbToHSV(copy:getColor()).z)))
  end 
end
function pings.SetCapeBlackness(value)
  for i, copy in pairs(Copies) do
    copy:setColor(vectors.hsvToRGB(vec(vectors.rgbToHSV(copy:getColor()).x,vectors.rgbToHSV(copy:getColor()).y,value/100)))
  end 
end
function pings.SetSegments(value)

AmountOfPoints = value

end
function pings.SetDensity(value)
density = value
end
function pings.SetCapeRAINBOW()
  for i, copy in pairs(Copies) do
    copy:setColor(vectors.hsvToRGB(vec(i/#Points-math.random()/100,0.9,0.9)))
  end 
end 
function pings.SetGravity(value)
Gravity = vec(0,value,0)
end   
function pings.Reload()

    if Copies ~= {} then
      for k ,copy in pairs(Copies) do
      copy:getParent():removeChild(copy)
      end
      Copies = {}
      end
Start = nil
Dest = nil
Timer = 0
Copies = {}
PrevPos = {}
Points = {}
Velocity = {}
Lengths = {}
Triggered = false
Triggered2 = false
end
function pings.SetStart()
  local eyePos = player:getPos() + vec(0, player:getEyeHeight(), 0)
local eyeEnd = eyePos + (player:getLookDir() * 20)
local block, hitPos, side = raycast:block(eyePos, eyeEnd)
Start = hitPos+vec(0,0.4,0)
end
function pings.SetEnd()
  local eyePos = player:getPos() + vec(0, player:getEyeHeight(), 0)
local eyeEnd = eyePos + (player:getLookDir() * 20)
local block, hitPos, side = raycast:block(eyePos, eyeEnd)
Dest = hitPos+vec(0,0.4,0)
end

