local line = require("Bresenham")
--I just gave up trying to implement 90 deg rotation using flipping the signs :(
   local Y90degRotMat= matrices.yRotation3(90)
   local X90degRotMat= matrices.xRotation3(-90)
require("Main")
local function cross2D (vec1a,vec2a)
return vec1a.x*vec2a.y -vec1a.y*vec2a.x
end  
local function dirToAngle(dir)
    return vec(-math.deg(math.atan2(dir.y, math.sqrt(dir.x * dir.x + dir.z * dir.z))), math.deg(math.atan2(dir.x, dir.z)), 0)
end
Screens = {}
local screenPart = models:newPart("Screen", "WORLD") --Im not coping auria I swear
function createScreen(pos,rot,width,height)

local screenText = textures:newTexture("screenText",width , height)
log(Y90degRotMat)
local sprite = screenPart:newSprite("Screen"):setPos(pos*16 + vec(0,100,0) + vec(0,player:getEyeHeight(),0)*16 + player:getLookDir()*120 + player:getLookDir()*Y90degRotMat*100 or vec(0,height,0)):setRot(rot or vec(0,0,0)):setTexture(screenText,200,200):setRenderType("EMISSIVE_SOLID"):setRot(dirToAngle(player:getLookDir()))
Screens[1] = {sprite = sprite, screenText = screenText,width=width,height= height} 
end
function clearScreen()
  for i, screen in pairs(Screens) do
    screen.screenText:fill(0,0,screen.width,screen.height,0,0,0,0.2)
  end
end
function drawPix(pos,rgb)
  if pos.x >= 0 and pos.x <= width - 2 and pos.y >= 0 and pos.y <= height-2 then
  Screens[1].screenText:setPixel(pos.x,pos.y,rgb)
  end
end
function calculateBarycentric(p, a, b, c)
  -- Calculate the denominator (area of the whole triangle)
  local denominator = ((b.y - c.y) * (a.x - c.x) + (c.x - b.x) * (a.y - c.y))
  
  -- Check for degenerate triangle (zero area)
  if denominator == 0 then
      return nil, nil, nil -- Degenerate triangle, no valid barycentric coordinates
  end

  -- Calculate the barycentric coordinates
  local lambda1 = ((b.y - c.y) * (p.x - c.x) + (c.x - b.x) * (p.y - c.y)) / denominator
  local lambda2 = ((c.y - a.y) * (p.x - c.x) + (a.x - c.x) * (p.y - c.y)) / denominator
  local lambda3 = 1 - lambda1 - lambda2

  return lambda1, lambda2, lambda3
end

function drawTriangle(pos1, pos2, pos3, color)
  -- Get texture dimensions (screen size in this case)

  -- Calculate the bounding box of the triangle
  local xMin = math.floor(math.min(pos1.x, pos2.x, pos3.x))
  local xMax = math.ceil(math.max(pos1.x, pos2.x, pos3.x))
  local yMin = math.floor(math.min(pos1.y, pos2.y, pos3.y))
  local yMax = math.ceil(math.max(pos1.y, pos2.y, pos3.y))

  -- Clip the bounding box to the screen dimensions
  xMin = math.max(0, xMin)
  xMax = math.min(width - 1, xMax)
  yMin = math.max(0, yMin)
  yMax = math.min(height - 1, yMax)

  -- Iterate over each pixel within the bounding box
  for y = yMin, yMax do
      for x = xMin, xMax do
          -- Calculate the barycentric coordinates for the point (x, y)
          local lambda1, lambda2, lambda3 = calculateBarycentric(vec(x, y), pos1, pos2, pos3)

          -- If any barycentric coordinate is negative, the point is outside the triangle
          if lambda1 and lambda2 and lambda3 and lambda1 >= 0 and lambda2 >= 0 and lambda3 >= 0 then
              -- The point is inside the triangle, draw the pixel
              Screens[1].screenText:setPixel(x, y, color)
          end
      end
  end
end
function drawLine(pos1,pos2,color)
  line.line( math.floor(pos1.x), math.floor(pos1.y), math.floor(pos2.x), math.floor(pos2.y), function( x, y, counter )
    if x >= 1 and x <= width - 2 and y >= 1 and y <= height-2 then
        Screens[1].screenText:setPixel(x,y,color)
      end
      return true
  end)
end  



--3 positions with uvs
function drawTexturedTriangle(pos1, pos2, pos3, uv1, uv2, uv3, tex,brightness)
  local tempVar

  -- Sort vertices by Y coordinate (pos1.y <= pos2.y <= pos3.y)
  if pos2.y < pos1.y then
      tempVar = pos1
      pos1 = pos2
      pos2 = tempVar
      tempVar = uv1
      uv1 = uv2
      uv2 = tempVar
  end  

  if pos3.y < pos1.y then
      tempVar = pos1
      pos1 = pos3
      pos3 = tempVar
      tempVar = uv1
      uv1 = uv3
      uv3 = tempVar
  end  

  if pos3.y < pos2.y then
      tempVar = pos2
      pos2 = pos3
      pos3 = tempVar
      tempVar = uv2
      uv2 = uv3
      uv3 = tempVar
  end  

  -- Compute delta values for the upper half of the triangle
  local dy1 = pos2.y - pos1.y
  local dx1 = pos2.x - pos1.x
  local du1 = uv2.x - uv1.x
  local dv1 = uv2.y - uv1.y
  local dw1 = uv2.z - uv1.z

  local dy2 = pos3.y - pos1.y
  local dx2 = pos3.x - pos1.x
  local du2 = uv3.x - uv1.x
  local dv2 = uv3.y - uv1.y
  local dw2 = uv3.z - uv1.z
  -- Initialize variables for interpolation
  local daxStep, dbxStep, du1Step, dv1Step, du2Step, dv2Step, dw1Step, dw2Step = 0, 0, 0, 0, 0, 0,0,0

  if dy1 ~= 0 then
      daxStep = dx1 / math.abs(dy1)
      du1Step = du1 / math.abs(dy1)
      dv1Step = dv1 / math.abs(dy1)
      dw1Step = dw1 / math.abs(dy1)
  end

  if dy2 ~= 0 then
      dbxStep = dx2 / math.abs(dy2)
      du2Step = du2 / math.abs(dy2)
      dv2Step = dv2 / math.abs(dy2)
      dw2Step = dw2 / math.abs(dy2)
  end

  -- Render the upper part of the triangle
  if dy1 ~= 0 then
      for i = pos1.y, pos2.y do
          local ax = math.ceil(pos1.x + (i - pos1.y) * daxStep)
          local bx = math.ceil(pos1.x + (i - pos1.y) * dbxStep)

          local texSU = uv1.x + (i - pos1.y) * du1Step
          local texSV = uv1.y + (i - pos1.y) * dv1Step
          local texSW = uv1.z + (i - pos1.y) * dw1Step

          local texEU = uv1.x + (i - pos1.y) * du2Step
          local texEV = uv1.y + (i - pos1.y) * dv2Step
          local texEW = uv1.z + (i - pos1.y) * dw2Step

          if ax > bx then
              ax, bx = bx, ax
              texSU, texEU = texEU, texSU
              texSV, texEV = texEV, texSV
              texSW, texEW = texEW, texSW
          end

          local tStep = 1 / (bx - ax)
          local t = 0

          for j = ax, math.ceil(bx) do
              local texU = (1 - t) * texSU + t * texEU
              local texV = (1 - t) * texSV + t * texEV
              local texW = (1 - t) * texSW + t * texEW

                if texW > depthBuffer[j][i] then

                    Screens[1].screenText:setPixel(j, i, vectors.hsvToRGB(vectors.rgbToHSV(tex:getPixel(math.ceil((texU/texW)%1 * (tex:getDimensions().x - 2)), math.ceil((texV/texW)%1 * (tex:getDimensions().y - 2))).xyz):mul(1,1,0.7)+brightness*0.3))
                  depthBuffer[j][i] = texW
                  end

              t = t + tStep
          end
      end
  end  

  -- Compute new delta values for the lower half of the triangle
  dy1 = pos3.y - pos2.y
  dx1 = pos3.x - pos2.x
  du1 = uv3.x - uv2.x
  dv1 = uv3.y - uv2.y
  dw1 = uv3.z - uv2.z

  if dy1 ~= 0 then
      daxStep = dx1 / math.abs(dy1)
      du1Step = du1 / math.abs(dy1)
      dv1Step = dv1 / math.abs(dy1)
      dw1Step = dw1 / math.abs(dy1)
  end

  if dy2 ~= 0 then
      dbxStep = dx2 / math.abs(dy2)
  end 

  -- Render the lower part of the triangle
  if dy1 ~= 0 then
      for i = pos2.y, pos3.y do
          local ax = math.ceil(pos2.x + (i - pos2.y) * daxStep)
          local bx = math.ceil(pos1.x + (i - pos1.y) * dbxStep)

          local texSU = uv2.x + (i - pos2.y) * du1Step
          local texSV = uv2.y + (i - pos2.y) * dv1Step
          local texSW = uv2.z + (i - pos2.y) * dw1Step

          local texEU = uv1.x + (i - pos1.y) * du2Step
          local texEV = uv1.y + (i - pos1.y) * dv2Step
          local texEW = uv1.z + (i - pos1.y) * dw2Step

          if ax > math.ceil(bx) then
              ax, bx = bx, ax
              texSU, texEU = texEU, texSU
              texSV, texEV = texEV, texSV
              texSW, texEW = texEW, texSW
          end

          local tStep = 1 / (bx - ax)
          local t = 0

          for j = ax, math.ceil(bx) do
              local texU = (1 - t) * texSU + t * texEU
              local texV = (1 - t) * texSV + t * texEV
              local texW = (1 - t) * texSW + t * texEW

                if texW > depthBuffer[j][i] then
                  Screens[1].screenText:setPixel(j, i, vectors.hsvToRGB(vectors.rgbToHSV(tex:getPixel(math.ceil((texU/texW)%1 * (tex:getDimensions().x - 2)), math.ceil((texV/texW)%1 * (tex:getDimensions().y - 2))).xyz):mul(1,1,0.7)+brightness*0.3))
                  depthBuffer[j][i] = texW
              end
              t = t + tStep
          end
      end
  end  
end



