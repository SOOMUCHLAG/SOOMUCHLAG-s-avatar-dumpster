width =80
height =80
heightW = 9
widthW = 25
breadthW = 25
takeDebug = false
depthBuffer = {}
curBlock = 1
colSpherePos = vec(10,-6,-8)
colSphereRadius = 0.5
local playerVel = vec(0,0,0)
local gravity = vec(0,0.07,0)
local friction = 0.5
local frictionY = 0.9
local yaw = 0
--models.model:setVisible(false)
local pitch = 0
local function multMatrix(vec3d,mat)
  local multvec = mat * vec(vec3d.x,vec3d.y,vec3d.z,1)
  if multvec.w ~= 0 then
  return vec(multvec.x,multvec.y,multvec.z),multvec.w
  else 
  return vec(multvec.x,multvec.y,multvec.z),multvec.w
  end



end
local function pointAtMatrix(pos,target,up)
local newForward = (target - pos):normalized()

local a = newForward * up:dot(newForward)
local newUp = (up-a):normalize()

local newRight = newUp:crossed(newForward)

local tranMat = matrices.mat4()
tranMat[1] = vec(newRight.x,newRight.y,newRight.z,0)
tranMat[2] = vec(newUp.x,newUp.y,newUp.z,0)
tranMat[3] = vec(newForward.x,newForward.y,newForward.z,0)
tranMat[4] = vec(pos.x,pos.y,pos.z,1)
return tranMat
end  
local function QuickInverse(mat)
local traslation = vec(mat[4].x,mat[4].y,mat[4].z)
local A = vec(mat[1].x,mat[1].y,mat[1].z)
local B = vec(mat[2].x,mat[2].y,mat[2].z)
local C = vec(mat[3].x,mat[3].y,mat[3].z)
local newMat = matrices.mat4()
newMat[1] = vec(mat[1].x,mat[2].x,mat[3].x,0)
newMat[2] = vec(mat[1].y,mat[2].y,mat[3].y,0)
newMat[3] = vec(mat[1].z,mat[2].z,mat[3].z,0)
newMat[4] = vec(-(traslation):dot(A),-(traslation):dot(B),-(traslation):dot(C),1)
return newMat
end

local function dist(planeNormal, planePoint, p)
  -- Dot product between plane normal and point, projecting the point onto the plane normal
  return (planeNormal.x * p.x + planeNormal.y * p.y + planeNormal.z * p.z - planeNormal:dot(planePoint))
end


local function Vector_IntersectPlane(planePoint, planeNormal, lineStart, lineEnd)
  -- Plane equation
  local plane_d = -planeNormal:dot(planePoint)
  local ad = lineStart:dot(planeNormal)
  local bd = lineEnd:dot(planeNormal)
  
  -- Calculate t where the line intersects the plane
  local t = (-plane_d - ad) / (bd - ad)
  
  -- If t is outside 0 and 1, there's no intersection within the line segment
  if t < 0 or t > 1 then return nil, t end
  
  -- Calculate intersection point
  local lineStartToEnd = lineEnd - lineStart
  local lineToIntersect = lineStartToEnd * t
  return (lineStart + lineToIntersect), t
end


local function triClipAgainstPlane(planePoint, planeNormal, triangle)
  planeNormal:normalize()  -- Ensure plane normal is normalized

  -- Containers for points and texture coordinates
  local insidePoints, outsidePoints = {}, {}
  local insideTexes, outsideTexes = {}, {}

  -- Calculate distances from each vertex of the triangle to the plane
  local d0 = dist(planeNormal, planePoint, triangle[1])
  local d1 = dist(planeNormal, planePoint, triangle[2])
  local d2 = dist(planeNormal, planePoint, triangle[3])

  -- Classify each point based on its distance to the plane
  if d0 >= 0 then
    table.insert(insidePoints, triangle[1])
    table.insert(insideTexes, triangle[6])
  else
    table.insert(outsidePoints, triangle[1])
    table.insert(outsideTexes, triangle[6])
  end

  if d1 >= 0 then
    table.insert(insidePoints, triangle[2])
    table.insert(insideTexes, triangle[7])
  else
    table.insert(outsidePoints, triangle[2])
    table.insert(outsideTexes, triangle[7])
  end

  if d2 >= 0 then
    table.insert(insidePoints, triangle[3])
    table.insert(insideTexes, triangle[8])
  else
    table.insert(outsidePoints, triangle[3])
    table.insert(outsideTexes, triangle[8])
  end

  -- Handle different cases based on the number of inside and outside points
  if #insidePoints == 0 then
    return 0  -- No points inside, triangle is clipped entirely
  end
  
  if #insidePoints == 3 then
    return 1, triangle  -- All points inside, no clipping required
  end

  if #insidePoints == 1 and #outsidePoints == 2 then
    -- Triangle becomes a smaller triangle
    local outTriangle = {}

    outTriangle[1] = insidePoints[1]
    outTriangle[6] = insideTexes[1]
    outTriangle[4] = vec(0,0,1)
    outTriangle[9] = triangle[9]
    outTriangle[5] = triangle[5]
    -- Intersect plane with the two outside points
    local t
    outTriangle[2], t = Vector_IntersectPlane(planePoint, planeNormal, insidePoints[1], outsidePoints[1])
    outTriangle[7] = vec(
      t * (outsideTexes[1].x - insideTexes[1].x) + insideTexes[1].x,
      t * (outsideTexes[1].y - insideTexes[1].y) + insideTexes[1].y,
      t * (outsideTexes[1].z - insideTexes[1].z) + insideTexes[1].z
    )

    outTriangle[3], t = Vector_IntersectPlane(planePoint, planeNormal, insidePoints[1], outsidePoints[2])
    outTriangle[8] = vec(
      t * (outsideTexes[2].x - insideTexes[1].x) + insideTexes[1].x,
      t * (outsideTexes[2].y - insideTexes[1].y) + insideTexes[1].y,
      t * (outsideTexes[2].z - insideTexes[1].z) + insideTexes[1].z
    )

    return 1, outTriangle
  end

  if #insidePoints == 2 and #outsidePoints == 1 then
    -- Triangle becomes two new triangles
    local outTriangle1, outTriangle2 = {}, {}
    local t

    -- First triangle
    outTriangle1[4] = vec(1,0,0)
    outTriangle1[5] = triangle[5]
    outTriangle1[9] = triangle[9]
    outTriangle1[1] = insidePoints[1]
    outTriangle1[6] = insideTexes[1]
    outTriangle1[2] = insidePoints[2]
    outTriangle1[7] = insideTexes[2]
    outTriangle1[3], t = Vector_IntersectPlane(planePoint, planeNormal, insidePoints[2], outsidePoints[1])
    outTriangle1[8] = vec(
      t * (outsideTexes[1].x - insideTexes[2].x) + insideTexes[2].x,
      t * (outsideTexes[1].y - insideTexes[2].y) + insideTexes[2].y,
      t * (outsideTexes[1].z - insideTexes[2].z) + insideTexes[2].z
    )

    -- Second triangle
    outTriangle2[4] = vec(0,1,0)
    outTriangle2[5] = triangle[5]
    outTriangle2[9] = triangle[9]
    outTriangle2[1] = insidePoints[1]
    outTriangle2[6] = insideTexes[1]
    outTriangle2[2] = outTriangle1[3]
    outTriangle2[7] = outTriangle1[8]
    outTriangle2[3], t = Vector_IntersectPlane(planePoint, planeNormal, insidePoints[1], outsidePoints[1])
    outTriangle2[8] = vec(
      t * (outsideTexes[1].x - insideTexes[1].x) + insideTexes[1].x,
      t * (outsideTexes[1].y - insideTexes[1].y) + insideTexes[1].y,
      t * (outsideTexes[1].z - insideTexes[1].z) + insideTexes[1].z
    )

    return 2, outTriangle1, outTriangle2
  end
end
--[[
local function clipTriangleAgainstAllPlanes(triangles)
    local clippedTriangles = {}
    
    -- Define the clipping planes
    local screenPlanes = {
      {planePoint = vec(0, -0.65, 0), planeNormal = vec(0, 1, 0)},  -- Top
        {planePoint = vec(0, 0.65, 0), planeNormal = vec(0, -1, 0)},  -- Bottom
        {planePoint = vec(-0.65, 0, 0), planeNormal = vec(1, 0, 0)},  -- Left
        {planePoint = vec(0.65, 0, 0), planeNormal = vec(-1, 0, 0)}  -- Right
    }

    -- Add initial triangles to the queue
    local queue = {}
    for _, tri in ipairs(triangles) do
        table.insert(queue, tri)
    end

    -- Iterate through each plane for clipping
    for i, plane in ipairs(screenPlanes) do
        local newTriangles = {}

        -- Process each triangle currently in the queue
        while #queue > 0 do
            local testTriangle = table.remove(queue, 1)

            -- Clip against the current plane
            local numClipped, clippedTri1, clippedTri2 = triClipAgainstPlane(plane.planePoint, plane.planeNormal, testTriangle)
          log(clippedTri1,clippedTri2,"tris",i,#queue)
            -- Add the clipped triangles to the list
            if numClipped == 1 then
                table.insert(newTriangles, clippedTri1)
            elseif numClipped == 2 then
                table.insert(newTriangles, clippedTri1)
                table.insert(newTriangles, clippedTri2)
            end
        end

        -- Update the queue with the newly clipped triangles
        queue = newTriangles
    end
 
    return queue  -- Return all the triangles clipped against all planes
end
]]


local function clipTriangleAgainstAllPlanes(triangles)
  -- Clipping planes definition
  local screenPlanes = {
    {planePoint = vec(0,1.3, 0), planeNormal = vec(0, 1, 0)},
    {planePoint = vec(1.3, 0, 0), planeNormal = vec(1, 0, 0)},
    {planePoint = vec(0, height-2.3, 0), planeNormal = vec(0, -1, 0)},
    {planePoint = vec(width-2.3, 0, 0), planeNormal = vec(-1, 0, 0)},
    -- Top
  }

  -- Copy the initial triangles
  local queue = {}
  for _, tri in ipairs(triangles) do
      table.insert(queue, tri)
  end

  -- Iterate through each clipping plane
  for i, plane in ipairs(screenPlanes) do
      local newTriangles = {}

      -- Process each triangle in the queue
      while #queue > 0 do
          local testTriangle = table.remove(queue, 1)

          -- Clip against the current plane
          local numClipped, clippedTri1, clippedTri2 = triClipAgainstPlane(plane.planePoint, plane.planeNormal, testTriangle)
          
          -- Add the valid clipped triangles to the list
          if numClipped == 1  then
              table.insert(newTriangles, clippedTri1)
          elseif numClipped == 2 then
         
                  table.insert(newTriangles, clippedTri1)
        
                  table.insert(newTriangles, clippedTri2)
     
          end
      end

      -- Update the queue with newly clipped triangles for the next plane
      queue = newTriangles
  end

  -- Return all triangles after clipping against all planes
  return queue
end




local World = {}



function events.entity_init()
  createScreen(player:getPos(),nil,width,height)
  for i = 1, widthW do
    World[i] = {}
    for j = 1, heightW do
      World[i][j] = {}
      for k = 1, breadthW do
        World[i][j][k] = 0
      end
    end
  end


  for i, tblx in pairs(World) do
    for j, tbly in pairs(tblx) do
      for k, value in pairs(tbly) do
        if (j == 1 ) and k >= 7 and k <= breadthW -4 and i >= 7 and i <= widthW -4 then
          World[i][j][k] = 1
        end

      end 
    end
  end
updateMesh()
  for i = 1, width do
    depthBuffer[i] = {}
    for j = 1, height do
      depthBuffer[i][j] = 0
    end
  end
  for i, value in pairs(mesh[1]) do
  log(value)
  end
  --[[

log(depthBuffer)
  local vertices = {}
  for i = 1, #avatar:getNBT().models.chld[1].chld[1].mesh_data.vtx , 3 do
    table.insert(vertices,vec(avatar:getNBT().models.chld[1].chld[1].mesh_data.vtx[i],avatar:getNBT().models.chld[1].chld[1].mesh_data.vtx[i+1],avatar:getNBT().models.chld[1].chld[1].mesh_data.vtx[i+2]))
  end

  local fac = avatar:getNBT().models.chld[1].chld[1].mesh_data.fac
  local curMesh = {}
  local num =1 
  local uv = avatar:getNBT().models.chld[1].chld[1].mesh_data.uvs
  for i , tex in pairs(avatar:getNBT().models.chld[1].chld[1].mesh_data.tex) do

    if tex == 20 then

      local tri = {}
 
        tri[3] = vertices[math.abs(fac[num]%255+1)]/16
        tri[8] = vec(uv[2*num-1],uv[2*num],1):div(texture:getDimensions().x,texture:getDimensions().y,1)
   
        tri[1] = vertices[math.abs(fac[num+1]%255+1)]/16
        tri[6] = vec(uv[2*num+1],uv[2*num+2],1):div(texture:getDimensions().x,texture:getDimensions().y,1)
    
        tri[2] = vertices[math.abs(fac[num+2]%255+1)]/16
        tri[7] = vec(uv[2*num+3],uv[2*num+4],1):div(texture:getDimensions().x,texture:getDimensions().y,1)

   
      table.insert(curMesh,tri)
      local tri = {}
      tri[1] = vertices[fac[num+3]%255+1]/16
      tri[6] = vec(uv[2*num+5],uv[2*num+6],1):div(texture:getDimensions().x,texture:getDimensions().y,1)
      tri[2] = vertices[fac[num]%255+1]/16
      tri[7] = vec(uv[2*num-1],uv[2*num],1):div(texture:getDimensions().x,texture:getDimensions().y,1)
      tri[3] = vertices[fac[num+2]%255+1]/16
      tri[8] = vec(uv[2*num+3],uv[2*num+4],1):div(texture:getDimensions().x,texture:getDimensions().y,1)
      table.insert(curMesh,tri)
      num = num +4
    end
    if tex == 19 then

      local tri = {}
      tri[3] = vertices[fac[num]%255+1]/16
      tri[1] = vertices[fac[num+1]%255+1]/16
      tri[2] = vertices[fac[num+2]%255+1]/16
      tri[6] = vec(0,0)
      tri[7] = vec(0,0)
      tri[8] = vec(0,0)
  
      table.insert(curMesh,tri)

      num = num +3
    end
  end
  for i , tex in pairs(avatar:getNBT().models.chld[1].chld[1].mesh_data.tex) do

    if tex == 4 then

      local tri = {}
 
        tri[3] = vertices[math.abs(fac[num]%255+1)]/16
   
   
        tri[1] = vertices[math.abs(fac[num+1]%255+1)]/16
   
    
        tri[2] = vertices[math.abs(fac[num+2]%255+1)]/16
        tri[6] = vec(0,0)
        tri[7] = vec(0,0)
        tri[8] = vec(0,0)
      table.insert(curMesh,tri)
      local tri = {}
      tri[1] = vertices[fac[num+3]%255+1]/16
      tri[2] = vertices[fac[num]%255+1]/16
      tri[3] = vertices[fac[num+2]%255+1]/16
      tri[6] = vec(0,0)
      tri[7] = vec(0,0)
      tri[8] = vec(0,0)
      table.insert(curMesh,tri)
      num = num +4
    end
    if tex == 3 then

      local tri = {}
      tri[3] = vertices[fac[num]%255+1]/16
      tri[1] = vertices[fac[num+1]%255+1]/16
      tri[2] = vertices[fac[num+2]%255+1]/16
      tri[6] = vec(0,0)
      tri[7] = vec(0,0)
      tri[8] = vec(0,0)
      table.insert(curMesh,tri)

      num = num +3
    end
  end
table.insert(mesh,curMesh)
]]


end
--Fov = field of view
local fov = 90
local fovRad = 1/math.tan(math.rad(fov)*0.5)
--aspect ratio
local aspectRatio = width/height
--Near = near clipping plane
local near = 0.1
--Far = far clipping plane
local far = 1000
--Projection Matrix
projectionMatrix = matrices.mat4()
projectionMatrix[1] = vec(aspectRatio*fovRad,0,0,0)
projectionMatrix[2] = vec(0,fovRad,0,0)
projectionMatrix[3] = vec(0,0,far/(far-near),1)
projectionMatrix[4] = vec(0,0,(-far*near)/(far-near),0)
s = 0


--[[
aspectRatio*fovRad 0 0 0
0 fovRad 0 0
0 0 far/(far-near) 1
0 0 (-far*near)/(far-near) 0
]]
local RotMat = matrices.mat4()

local timer = 180
local timer2 = 0

local cameraPos = vec(0,-5,0)
local lookDir = vec(0,0,1)

--rendering code
function events.tick()
  


  local triToRasterz = {}
local triToRaster = {}
local triProjectedtbl = {}
local triToRasterSortz = {}
timer2 = timer2 + 1
 clearScreen()
 local scale = 1

RotMat:rotate(vec(timer,0,0))
timer = 0

for i, tbl in pairs(mesh) do
  for j, triangle in pairs(tbl) do

  local triTranslated = {}
  local triRotatedX = {}
  local triViewed1 = {}
--rotation
  triRotatedX[1] = multMatrix(triangle[1],RotMat)
  triRotatedX[2] = multMatrix(triangle[2],RotMat)
  triRotatedX[3] = multMatrix(triangle[3],RotMat)

--translation
  triTranslated[1] = (triRotatedX[1])*scale
  triTranslated[2] = (triRotatedX[2])*scale
  triTranslated[3] = (triRotatedX[3])*scale


  --face normals
  --triangle cross product
  local line1 = triTranslated[2] - triTranslated[1]
  local line2 = triTranslated[3] - triTranslated[1]
  local normal = line1:crossed(line2):normalized()
--illumination
  local lightDirection = vec(-1.2,-1.9,-3):normalize()*1.8
  local illumination
  illumination = normal:dot(lightDirection)
  if illumination < 0.1 then
    illumination = 0.2
  end
  if illumination > 1 then
illumination = 1
  end  
  triViewed1[5] = illumination
  
  cameraPos = colSpherePos-vec(0,1,0)
  local up = vec(0,1,0)
  local target = vec(0,0,1)
  updateCameraOrientation(yaw, pitch)
  target = cameraPos+lookDir
  camMat = pointAtMatrix(cameraPos,target,up)
  viewMat = QuickInverse(camMat)


  triViewed1[1] = multMatrix(triTranslated[1],viewMat)
  triViewed1[2] = multMatrix(triTranslated[2],viewMat)
  triViewed1[3] = multMatrix(triTranslated[3],viewMat)


  triViewed1[6] = vec(triangle[6].x,triangle[6].y,triangle[6].z)
  triViewed1[7] = vec(triangle[7].x,triangle[7].y,triangle[7].z)
  triViewed1[8] = vec(triangle[8].x,triangle[8].y,triangle[8].z)
  triViewed1[9] = triangle[9]

  local clippedTriangles = {}
numClipped, clippedTriangles[1] , clippedTriangles[2] = triClipAgainstPlane(vec(0, 0, 0.3), vec(0, 0, 1), triViewed1)

--log(clippedTriangles)

--projection
--if normal.z < 0 then

for i, tri in pairs(clippedTriangles) do
  local triProjected = {}
if normal:dot(triTranslated[1]-cameraPos) < 0 then
  local w1 = 1
  local w2 = 1
  local w3 = 1
  local z1 = 0
  local z2 = 0
  local z3 = 0
  w1 = tri[1].z
  w2 = tri[2].z
  w3 = tri[3].z
  triProjected[1],z1 = multMatrix(tri[1],projectionMatrix)
  triProjected[2],z2 = multMatrix(tri[2],projectionMatrix)
  triProjected[3],z3 = multMatrix(tri[3],projectionMatrix)
  triProjected[4] = tri[4]
  triProjected[5]= tri[5]
  triProjected[6] = vec(tri[6].x,tri[6].y,tri[6].z)
  triProjected[7] = vec(tri[7].x,tri[7].y,tri[7].z)
  triProjected[8] = vec(tri[8].x,tri[8].y,tri[8].z)
  triProjected[9] = tri[9]
 

  triProjected[6].x = triProjected[6].x/w1
  triProjected[7].x = triProjected[7].x/w2
  triProjected[8].x = triProjected[8].x/w3

  triProjected[6].y = triProjected[6].y/w1
  triProjected[7].y = triProjected[7].y/w2
  triProjected[8].y = triProjected[8].y/w3

  triProjected[6].z = 1/w1
  triProjected[7].z = 1/w2
  triProjected[8].z = 1/w3

  triProjected[1] = triProjected[1]/z1
  triProjected[2] = triProjected[2]/z2
  triProjected[3] = triProjected[3]/z3

  triProjected[1].x = triProjected[1].x + 1
  triProjected[2].x = triProjected[2].x + 1
  triProjected[3].x = triProjected[3].x + 1
  triProjected[1].y = triProjected[1].y + 1
  triProjected[2].y = triProjected[2].y + 1
  triProjected[3].y = triProjected[3].y + 1

  triProjected[1].x = triProjected[1].x * 0.5 * width
  triProjected[1].y = triProjected[1].y * 0.5 * height
  triProjected[2].x = triProjected[2].x * 0.5 * width
  triProjected[2].y = triProjected[2].y * 0.5 * height
  triProjected[3].x = triProjected[3].x * 0.5 * width
  triProjected[3].y = triProjected[3].y * 0.5 * height
 table.insert(triToRaster,triProjected)
 --table.insert(triToRasterSortz,(triProjected[1].z + triProjected[2].z +triProjected[3].z)/3)
 --table.insert(triToRasterz,(triProjected[1].z + triProjected[2].z +triProjected[3].z)/3)

end
end
end

--ordering the triangles
table.sort(triToRasterSortz)
for i=0,#triToRasterSortz-1 do
  for j, zvalue2 in pairs(triToRasterz) do
  
    if triToRasterSortz[#triToRasterSortz-i] == zvalue2 then
      table.insert(triToRaster,triProjectedtbl[j])
      
    end
  end
end




if s < 99999999 then
  s = s + 1

  triToRasterDraw = clipTriangleAgainstAllPlanes(triToRaster)
for i, triProjectedDraw in pairs(triToRasterDraw) do

--





if triProjectedDraw[9] then
  drawTexturedTriangle(triProjectedDraw[1].xy:ceil(),triProjectedDraw[2].xy:ceil(),triProjectedDraw[3].xy:ceil(),triProjectedDraw[6],triProjectedDraw[7],triProjectedDraw[8],texturesBlocks[""..triProjectedDraw[9]],vec(0,0,triProjectedDraw[5]))
end
--[[  drawTriangle(triProjectedDraw[1].xy,triProjectedDraw[2].xy,triProjectedDraw[3].xy,vectors.hsvToRGB(vectors.rgbToHSV(triProjectedDraw[4])+vec(0,0,triProjectedDraw[5])))
]]
--[[
  drawLine(triProjectedDraw[1],triProjectedDraw[2],vectors.hsvToRGB(vectors.rgbToHSV(1,0,0)+vec(0,0,triProjectedDraw[5])))
drawLine(triProjectedDraw[3],triProjectedDraw[2],vectors.hsvToRGB(vectors.rgbToHSV(1,0,0)+vec(0,0,triProjectedDraw[5])))
drawLine(triProjectedDraw[1],triProjectedDraw[3],vectors.hsvToRGB(vectors.rgbToHSV(1,0,0)+vec(0,0,triProjectedDraw[5])))

drawPix(triProjectedDraw[1],vec(0,0,1))
drawPix(triProjectedDraw[2],vec(0,0,1))
drawPix(triProjectedDraw[3],vec(0,0,1))
]]


takeDebug = false



end
end
--fog I guess or something
--[[
for i = 1, width do
  for j = 1, height do

          Screens[1].screenText:setPixel(i-1,j-1,vectors.hsvToRGB(vectors.rgbToHSV(Screens[1].screenText:getPixel(i-1,j-1).xyz).xy_ + vec(0,0,math.clamp((vectors.rgbToHSV(Screens[1].screenText:getPixel(i-1,j-1).xyz).z*0.95 + depthBuffer[i][j]*0.2),0,0.9))))
  end
end]]
if takeDebug then

for i = 1, width do
  for j = 1, height do

    log(depthBuffer[j][i],i,j)
    end
  end
end
--depth buffer visualization
--[[
for i = 1, width do
  for j = 1, height do
    Screens[1].screenText:setPixel(i-1,j-1,vectors.hsvToRGB(0,0,1-depthBuffer[i][j]/1.5))
    end
  end]]
  if Screens[1].screenText then
Screens[1].screenText:update()  
  else
    createScreen(player:getPos(),nil,width,height)
  end  
takeDebug = false

end
for i = 1, width do
  for j = 1, height do
    depthBuffer[i][j] = 0
  end
end

Screens[1].screenText:setPixel(width/2,height/2,1,1,1)
Screens[1].screenText:setPixel(width/2,height/2+1,1,1,1)
Screens[1].screenText:setPixel(width/2+1,height/2+1,1,1,1)
Screens[1].screenText:setPixel(width/2+1,height/2,1,1,1)
end





texturesBlocks = {
grassUP = textures["blockss.grassUP"],
grassSIDE = textures["blockss.grassSIDE"],
dirt = textures["blockss.dirt"],
highlight = textures["blockss.highlight"],
stone = textures["blockss.stone"],
cobblestone = textures["blockss.cobblestone"],
oakPlanks = textures["blockss.oakPlanks"],
oakLogTop = textures["blockss.oakLogTop"],
oakLog = textures["blockss.oakLog"],
oakLeaves = textures["blockss.oakLeaves"],
diamond = textures["blockss.diamondBlock"],
sand = textures["blockss.sand"],
stoneBricks = textures["blockss.stoneBricks"],
copperBlock = textures["blockss.copperBlock"]
}



blocks = {
grass = {top = {{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"grassUP"},
                {vec(0,1,0),vec(1,1,1),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"grassUP"}},
         south = {{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"grassSIDE"},
                 {vec(0,0,0),vec(1,1,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"grassSIDE"}}, 
         north = {{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"grassSIDE"},
                 {vec(1,0,1),vec(0,1,1),vec(0,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"grassSIDE"}}, 
         west = {{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"grassSIDE"},
                {vec(0,0,1),vec(0,1,0),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"grassSIDE"}},
         east = {{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"grassSIDE"},
                {vec(1,0,0),vec(1,1,1),vec(1,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"grassSIDE"}},
         bottom ={{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"dirt"},
                  {vec(1,0,1),vec(0,0,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"dirt"}},
              },
highlight = {top = {{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"},{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"}},
             south = {{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"},{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"}},
             north = {{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"},{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"}},
             west = {{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"},{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"},},
             east = {{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"},{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"}},
             bottom ={{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"},{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),0,vec(0,1,1),vec(0,1,1),vec(0,1,1),"highlight"}},
            },
             
             stone = {top = {{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stone"},
             {vec(0,1,0),vec(1,1,1),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stone"}},
      south = {{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stone"},
              {vec(0,0,0),vec(1,1,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stone"}}, 
      north = {{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stone"},
              {vec(1,0,1),vec(0,1,1),vec(0,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stone"}}, 
      west = {{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stone"},
             {vec(0,0,1),vec(0,1,0),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stone"}},
      east = {{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stone"},
             {vec(1,0,0),vec(1,1,1),vec(1,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stone"}},
      bottom ={{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stone"},
               {vec(1,0,1),vec(0,0,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stone"}},
           },

           cobblestone = {top = {{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"cobblestone"},
           {vec(0,1,0),vec(1,1,1),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"cobblestone"}},
    south = {{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"cobblestone"},
            {vec(0,0,0),vec(1,1,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"cobblestone"}}, 
    north = {{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"cobblestone"},
            {vec(1,0,1),vec(0,1,1),vec(0,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"cobblestone"}}, 
    west = {{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"cobblestone"},
           {vec(0,0,1),vec(0,1,0),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"cobblestone"}},
    east = {{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"cobblestone"},
           {vec(1,0,0),vec(1,1,1),vec(1,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"cobblestone"}},
    bottom ={{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"cobblestone"},
             {vec(1,0,1),vec(0,0,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"cobblestone"}},
         },


         oakPlanks = {top = {{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakPlanks"},
         {vec(0,1,0),vec(1,1,1),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakPlanks"}},
  south = {{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakPlanks"},
          {vec(0,0,0),vec(1,1,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakPlanks"}}, 
  north = {{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakPlanks"},
          {vec(1,0,1),vec(0,1,1),vec(0,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakPlanks"}}, 
  west = {{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakPlanks"},
         {vec(0,0,1),vec(0,1,0),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakPlanks"}},
  east = {{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakPlanks"},
         {vec(1,0,0),vec(1,1,1),vec(1,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakPlanks"}},
  bottom ={{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakPlanks"},
           {vec(1,0,1),vec(0,0,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakPlanks"}},
       },




     oakLog = {top = {{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLogTop"},
     {vec(0,1,0),vec(1,1,1),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLogTop"}},
south = {{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLog"},
      {vec(0,0,0),vec(1,1,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLog"}}, 
north = {{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLog"},
      {vec(1,0,1),vec(0,1,1),vec(0,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLog"}}, 
west = {{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLog"},
     {vec(0,0,1),vec(0,1,0),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLog"}},
east = {{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLog"},
     {vec(1,0,0),vec(1,1,1),vec(1,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLog"}},
bottom ={{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLogTop"},
       {vec(1,0,1),vec(0,0,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLogTop"}},
   },


   oakLeaves = {top = {{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLeaves"},
   {vec(0,1,0),vec(1,1,1),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLeaves"}},
south = {{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLeaves"},
    {vec(0,0,0),vec(1,1,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLeaves"}}, 
north = {{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLeaves"},
    {vec(1,0,1),vec(0,1,1),vec(0,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLeaves"}}, 
west = {{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLeaves"},
   {vec(0,0,1),vec(0,1,0),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLeaves"}},
east = {{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLeaves"},
   {vec(1,0,0),vec(1,1,1),vec(1,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLeaves"}},
bottom ={{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"oakLeaves"},
     {vec(1,0,1),vec(0,0,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"oakLeaves"}},
 },
 stoneBricks = {top = {{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stoneBricks"},
 {vec(0,1,0),vec(1,1,1),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stoneBricks"}},
south = {{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stoneBricks"},
  {vec(0,0,0),vec(1,1,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stoneBricks"}}, 
north = {{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stoneBricks"},
  {vec(1,0,1),vec(0,1,1),vec(0,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stoneBricks"}}, 
west = {{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stoneBricks"},
 {vec(0,0,1),vec(0,1,0),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stoneBricks"}},
east = {{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stoneBricks"},
 {vec(1,0,0),vec(1,1,1),vec(1,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stoneBricks"}},
bottom ={{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"stoneBricks"},
   {vec(1,0,1),vec(0,0,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"stoneBricks"}},
},
diamondBlock = {top = {{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"diamond"},
{vec(0,1,0),vec(1,1,1),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"diamond"}},
south = {{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"diamond"},
 {vec(0,0,0),vec(1,1,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"diamond"}}, 
north = {{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"diamond"},
 {vec(1,0,1),vec(0,1,1),vec(0,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"diamond"}}, 
west = {{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"diamond"},
{vec(0,0,1),vec(0,1,0),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"diamond"}},
east = {{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"diamond"},
{vec(1,0,0),vec(1,1,1),vec(1,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"diamond"}},
bottom ={{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"diamond"},
  {vec(1,0,1),vec(0,0,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"diamond"}},
},
sand = {top = {{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"sand"},
{vec(0,1,0),vec(1,1,1),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"sand"}},
south = {{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"sand"},
 {vec(0,0,0),vec(1,1,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"sand"}}, 
north = {{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"sand"},
 {vec(1,0,1),vec(0,1,1),vec(0,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"sand"}}, 
west = {{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"sand"},
{vec(0,0,1),vec(0,1,0),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"sand"}},
east = {{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"sand"},
{vec(1,0,0),vec(1,1,1),vec(1,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"sand"}},
bottom ={{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"sand"},
  {vec(1,0,1),vec(0,0,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"sand"}},
},
copperBlock = {top = {{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"copperBlock"},
{vec(0,1,0),vec(1,1,1),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"copperBlock"}},
south = {{vec(0,0,0),vec(0,1,0),vec(1,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"copperBlock"},
 {vec(0,0,0),vec(1,1,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"copperBlock"}}, 
north = {{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"copperBlock"},
 {vec(1,0,1),vec(0,1,1),vec(0,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"copperBlock"}}, 
west = {{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"copperBlock"},
{vec(0,0,1),vec(0,1,0),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"copperBlock"}},
east = {{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"copperBlock"},
{vec(1,0,0),vec(1,1,1),vec(1,0,1),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"copperBlock"}},
bottom ={{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),1,vec(0,1,1),vec(0,0,1),vec(1,0,1),"copperBlock"},
  {vec(1,0,1),vec(0,0,0),vec(1,0,0),vec(1,1,1),1,vec(0,1,1),vec(1,0,1),vec(1,1,1),"copperBlock"}},
},
}





mesh = {{--[[blocks.grass.top[1],blocks.grass.top[2],blocks.grass.south[1],blocks.grass.south[2],blocks.grass.north[1],blocks.grass.north[2],blocks.grass.west[1],blocks.grass.west[2],blocks.grass.east[1],blocks.grass.east[2],blocks.grass.bottom[1],blocks.grass.bottom[2] ]]}

 --[[ {
  --cube
--south

--east
{vec(1,0,0),vec(1,1,0),vec(1,1,1),vec(1,1,1),0,vec(0,1,1),vec(0,0,1),vec(1,0,1)},
{vec(1,0,0),vec(1,1,1),vec(1,0,1),vec(1,1,1),0,vec(0,1,1),vec(1,0,1),vec(1,1,1)},
--north
{vec(1,0,1),vec(1,1,1),vec(0,1,1),vec(1,1,1),0,vec(0,1,1),vec(0,0,1),vec(1,0,1)},
{vec(1,0,1),vec(0,1,1),vec(0,0,1),vec(1,1,1),0,vec(0,1,1),vec(1,0,1),vec(1,1,1)},
--west
{vec(0,0,1),vec(0,1,1),vec(0,1,0),vec(1,1,1),0,vec(0,1,1),vec(0,0,1),vec(1,0,1)},
{vec(0,0,1),vec(0,1,0),vec(0,0,0),vec(1,1,1),0,vec(0,1,1),vec(1,0,1),vec(1,1,1)},
--top
{vec(0,1,0),vec(0,1,1),vec(1,1,1),vec(1,1,1),0,vec(0,1,1),vec(0,0,1),vec(1,0,1)},
{vec(0,1,0),vec(1,1,1),vec(1,1,0),vec(1,1,1),0,vec(0,1,1),vec(1,0,1),vec(1,1,1)},
--bottom
{vec(1,0,1),vec(0,0,1),vec(0,0,0),vec(1,1,1),0,vec(0,1,1),vec(0,0,1),vec(1,0,1)},
{vec(1,0,1),vec(0,0,0),vec(1,0,0),vec(1,1,1),0,vec(0,1,1),vec(1,0,1),vec(1,1,1)},
},
]]
}






















local keybindStatew = false
-- Here the keybindState is true, meaning the first press will swap it to false
-- If you wish the first press to swap to false, change the true to false above
--[[
local w = keybinds:newKeybind("Keybind Name", "key.keyboard.i")
w.press = function()
  pings.state(1,true)
end
w.release = function()
  pings.state(1,false)
end
local s = keybinds:newKeybind("Keybind Name", "key.keyboard.k")
s.press = function()
  pings.state(2,true)
end
s.release = function()
  pings.state(2,false)
end

local a = keybinds:newKeybind("Keybind Name", "key.keyboard.l")
a.press = function()
  pings.state(3,true)
end
a.release = function()
  pings.state(3,false)
end
local d = keybinds:newKeybind("Keybind Name", "key.keyboard.j")
d.press = function()
  pings.state(4,true)
end
d.release = function()
  pings.state(4,false)
end
]]
local forward = keybinds:fromVanilla("key.forward")
local right = keybinds:fromVanilla("key.right")
local left = keybinds:fromVanilla("key.left")
local backward = keybinds:fromVanilla("key.back")
local jump= keybinds:fromVanilla("key.jump")
local destroy= keybinds:fromVanilla("key.attack")
local place= keybinds:fromVanilla("key.use")
local sneak= keybinds:fromVanilla("key.sneak")
--entity init event, used for when the avatar entity is loaded for the first time

forward.press = function()
  pings.state(1,true)
  return true
end
forward.release = function()
  pings.state(1,false)
  return true
end
right.press = function()
  pings.state(3,true)
  return true
end
right.release = function()
  pings.state(3,false)
  return true
end
left.press = function()
  pings.state(4,true)
  return true
end
left.release = function()
  pings.state(4,false)
  return true
end
backward.press = function()
  pings.state(2,true)
  return true
end
backward.release = function()
  pings.state(2,false)
  return true
end
jump.press = function()
  pings.state(6,true)
  return true
end
jump.release = function()
  pings.state(6,false)
  return true
end
destroy.press = function()
  pings.destroy()
  return true
end

place.press = function()
pings.place()
  return true
end
sneak.press = function()
  host:setUnlockCursor(true)
  return true
  end
  sneak.release = function()
    host:setUnlockCursor(false)
    return true
    end
local up = keybinds:newKeybind("Keybind Name", "key.keyboard.z")
up.press = function()
  pings.state(5,true)
end
up.release = function()
  pings.state(5,false)
end
--[[
local down = keybinds:newKeybind("Keybind Name", "key.keyboard.x")
down.press = function()
  pings.state(6,true)
end
down.release = function()
  pings.state(6,false)
end
]]
local rot1 = keybinds:newKeybind("Keybind Name", "key.keyboard.m")
rot1.press = function()
  pings.state(7,true)
end
rot1.release = function()
  pings.state(7,false)
end
local rot2 = keybinds:newKeybind("Keybind Name", "key.keyboard.n")
rot2.press = function()
  pings.state(8,true)
end
rot2.release = function()
  pings.state(8,false)
end

local rot3 = keybinds:newKeybind("Keybind Name", "key.keyboard.b")
rot3.press = function()
  pings.state(9,true)
end
rot3.release = function()
  pings.state(9,false)
end
local down = keybinds:newKeybind("Keybind Name", "key.keyboard.v")
down.press = function()
  pings.state(10,true)
end
down.release = function()
  pings.state(10,false)
end
--[[]
local place = keybinds:newKeybind("Keybind Name", "key.keyboard.h")
place.press = function()
  pings.place()
--  takeDebug = true
end
local place = keybinds:newKeybind("Keybind Name", "key.keyboard.u")
place.press = function()
  pings.destroy()
--  takeDebug = true
end
]]
local curHighlight
local deg90rotmat = matrices.yRotation3(90)
local pitchLimit = 89 
local prevPos = vec(0,0,0)
local input = false
local grounded = true
function events.tick()

if keybindStatew then
  
playerVel= playerVel+ lookDir.x_z:normalized()*0.16
end  
if keybindStates then
  playerVel= playerVel- lookDir.x_z:normalized()*0.16
end  
if keybindStated then
playerVel= playerVel- (vec(lookDir.x,0,lookDir.z):normalized()*0.1*deg90rotmat)
end  
if keybindStatea then
  playerVel= playerVel+ (vec(lookDir.x,0,lookDir.z):normalized()*0.1*deg90rotmat)
end  

if keybindState2 and grounded then
  playerVel:add(0,-0.5,0)
end  
if keybindStaterot1 then
yaw = yaw-4
end
if keybindStaterot2 then
  yaw = yaw+4
  end  
  if keybindStaterot3 then
pitch = pitch-4
end
if keybindStaterot4 then
  pitch = pitch+4
  end 
  pitch = math.max(-pitchLimit, math.min(pitchLimit, pitch))

  updateCameraOrientation(yaw, pitch)
  playerVel=playerVel+gravity
  grounded = false
  for i=1, 4 do 
  colSpherePos = colSpherePos + playerVel/4


  for i, triangle in pairs(mesh[1]) do
    prevPos = colSpherePos:copy()
    colSpherePos = sphereTriangleCollision(colSpherePos,colSphereRadius,vec(triangle[1].x,-triangle[1].y,-triangle[1].z),vec(triangle[2].x,-triangle[2].y,-triangle[2].z),vec(triangle[3].x,-triangle[3].y,-triangle[3].z))

  end
  if grounded then
    playerVel.y = 0
  end
  if colSpherePos.y >5 then
    colSpherePos = vec(10,-6,-8)
  end
end
  playerVel:mul(friction,frictionY,friction)
    highlight()
end  


function pings.state(kb,state)
input = state
  if kb == 1 then
    keybindStatew = state
  end
  if kb == 2 then
    keybindStates = state
  end
  if kb == 3 then
    keybindStatea = state
  end
  if kb == 4 then
    keybindStated = state
  end
  if kb == 5 then
    keybindState1 = state
  end
  if kb == 6 then
    keybindState2 = state
  end
  if kb == 7 then
    keybindStaterot1 = state
  end
  if kb == 8 then
    keybindStaterot2 = state
  end
  if kb == 9 then
    keybindStaterot3 = state
  end
  if kb == 10 then
    keybindStaterot4 = state
  end
  if kb == 11 then
    pitch = 0
    yaw = 0
  end
end


function events.mouse_move(x, y)
  if player:isLoaded() then
    
    yaw = yaw-x/4

    pitch = pitch+y/4
    
    if pitch > 89 then 
      pitch = 89
    end
    if pitch < -89 then 
      pitch = -89
    end
    return true
  end
end


function updateCameraOrientation(yaw, pitch)
    local direction = vec(0, 0, 0)

    -- Calculate the forward direction based on yaw and pitch
    direction.x = math.cos(math.rad(yaw)) * math.cos(math.rad(pitch))
    direction.y = math.sin(math.rad(pitch))
    direction.z = math.sin(math.rad(yaw)) * math.cos(math.rad(pitch))

    -- Normalize the direction vector
    direction:normalize()

    -- Update camera orientation here, using your graphics engine's functions
    lookDir = direction
end


--[[       tri1.n = nil
tri1[1] = vec(i+tri1[1].x,j+tri1[1].y,k+tri1[1].z):sub(originPosy1.x,0,0)
tri1[2] = vec(i+tri1[2].x,j+tri1[2].y,k+tri1[2].z)
tri1[3] = vec(i+tri1[3].x,j+tri1[3].y,k+tri1[3].z)
table.insert(mesh[1],tri1)
  local tri2 

  tri2 = table.pack(table.unpack(blockdata.top[2]))

tri2.n = nil
tri1[1] = vec(i+tri1[1].x,j+tri1[1].y,k+tri1[1].z)
tri1[2] = vec(i+tri1[2].x,j+tri1[2].y,k+tri1[2].z):sub(originPosy1.x,0,0)
tri1[3] = vec(i+tri1[3].x,j+tri1[3].y,k+tri1[3].z):sub(originPosy1.x,0,0)
table.insert(mesh[1],tri2)]]





















local function like(a, b)
  return a == b or (a == "stone" and b == "stone_variant")
end


function updateMesh()
  mesh[1] = {}
local blocksPos = {}
local blockdata = {}






  local mergeBlocks = require("greedy_mesh")

  local meshes = mergeBlocks(World, like)

  for i, greedyMeshed in pairs(meshes) do 
    if tonumber(greedyMeshed.id) ~= 0 then

      local blockdata = {}
      if tonumber(greedyMeshed.id) == 1 then
        blockdata = blocks.grass
      end
      if tonumber(greedyMeshed.id) == 2 then
        blockdata = blocks.stone
      end
      if tonumber(greedyMeshed.id) == 3 then
        blockdata = blocks.cobblestone
      end
      if tonumber(greedyMeshed.id) == 4 then
        blockdata = blocks.oakPlanks
      end
      if tonumber(greedyMeshed.id) == 5 then
        blockdata = blocks.oakLog
      end
      if tonumber(greedyMeshed.id) == 6 then
        blockdata = blocks.oakLeaves
      end
      if tonumber(greedyMeshed.id) == 7 then
        blockdata = blocks.stoneBricks
      end
      if tonumber(greedyMeshed.id) == 8 then
        blockdata = blocks.sand
      end
      if tonumber(greedyMeshed.id) == 9 then
        blockdata = blocks.copperBlock
      end
      if tonumber(greedyMeshed.id) == 10 then
        blockdata = blocks.diamondBlock
      end

--up
local tri1 = table.pack(table.unpack(blockdata.top[1]))
      
      tri1.n = nil
      tri1[1] = vec(greedyMeshed.x+tri1[1].x,greedyMeshed.y+tri1[1].y+greedyMeshed.height-1,greedyMeshed.z+tri1[1].z)
      tri1[2] = vec(greedyMeshed.x+tri1[2].x,greedyMeshed.y+tri1[2].y+greedyMeshed.height-1,greedyMeshed.z+greedyMeshed.depth-1+tri1[2].z)
      tri1[3] = vec(greedyMeshed.x+greedyMeshed.width-1+tri1[3].x,greedyMeshed.y+tri1[3].y+greedyMeshed.height-1,greedyMeshed.z+greedyMeshed.depth-1+tri1[3].z)
      tri1[6] = vec(tri1[6].x,tri1[6].y,1)
      tri1[7] = vec(tri1[7].x,tri1[7].y+greedyMeshed.depth+1,1)
      tri1[8] = vec(tri1[8].x+greedyMeshed.width-1,tri1[8].y+greedyMeshed.depth+1,1)
      table.insert(mesh[1],tri1)

      local tri2 = table.pack(table.unpack(blockdata.top[2]))
      tri2.n = nil
      tri2[1] = vec(greedyMeshed.x+tri2[1].x,greedyMeshed.y+tri2[1].y+greedyMeshed.height-1,greedyMeshed.z+tri2[1].z)
      tri2[2] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[2].x,greedyMeshed.y+tri2[2].y+greedyMeshed.height-1,greedyMeshed.z+greedyMeshed.depth-1+tri2[2].z)
      tri2[3] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[3].x,greedyMeshed.y+tri2[3].y+greedyMeshed.height-1,greedyMeshed.z+tri2[3].z)
      tri2[6] = vec(tri2[6].x,tri2[6].y,1)
      tri2[7] = vec(tri2[7].x+greedyMeshed.width-1,tri2[7].y+greedyMeshed.depth+1,1)
      tri2[8] = vec(tri2[8].x+greedyMeshed.width-1,tri2[8].y,1)
      table.insert(mesh[1],tri2)



      

      local tri1 = table.pack(table.unpack(blockdata.south[1]))
      
      tri1.n = nil
      tri1[1] = vec(greedyMeshed.x+tri1[1].x,greedyMeshed.y+tri1[1].y,greedyMeshed.z+tri1[1].z)
      tri1[2] = vec(greedyMeshed.x+tri1[2].x,greedyMeshed.y+greedyMeshed.height-1+tri1[2].y,greedyMeshed.z+tri1[2].z)
      tri1[3] = vec(greedyMeshed.x+greedyMeshed.width-1+tri1[3].x,greedyMeshed.y+greedyMeshed.height-1+tri1[3].y,greedyMeshed.z+tri1[3].z)
      tri1[6] = vec(tri1[6].x,tri1[6].y,1)
      tri1[7] = vec(tri1[7].x,tri1[7].y+greedyMeshed.height+1,1)
      tri1[8] = vec(tri1[8].x+greedyMeshed.width-1,tri1[8].y+greedyMeshed.height+1,1)
      table.insert(mesh[1],tri1)

      local tri2 = table.pack(table.unpack(blockdata.south[2]))
      
      tri2.n = nil
      tri2[1] = vec(greedyMeshed.x+tri2[1].x,greedyMeshed.y+tri2[1].y,greedyMeshed.z+tri2[1].z)
      tri2[2] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[2].x,greedyMeshed.y+greedyMeshed.height-1+tri2[2].y,greedyMeshed.z+tri2[2].z)
      tri2[3] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[3].x,greedyMeshed.y+tri2[3].y,greedyMeshed.z+tri2[3].z)
      tri2[6] = vec(tri2[6].x,tri2[6].y,1)
      tri2[7] = vec(tri2[7].x+greedyMeshed.width-1,tri2[7].y+greedyMeshed.height+1,1)
      tri2[8] = vec(tri2[8].x+greedyMeshed.width-1,tri2[8].y,1)
      table.insert(mesh[1],tri2)


      
      local tri1 = table.pack(table.unpack(blockdata.north[1]))
      
      tri1.n = nil
      tri1[1] = vec(greedyMeshed.x+greedyMeshed.width-1+tri1[1].x,greedyMeshed.y+tri1[1].y,greedyMeshed.z+greedyMeshed.depth-1+tri1[1].z)
      tri1[2] = vec(greedyMeshed.x+greedyMeshed.width-1+tri1[2].x,greedyMeshed.y+greedyMeshed.height-1+tri1[2].y,greedyMeshed.z+greedyMeshed.depth-1+tri1[2].z)
      tri1[3] = vec(greedyMeshed.x+tri1[3].x,greedyMeshed.y+greedyMeshed.height-1+tri1[3].y,greedyMeshed.z+greedyMeshed.depth-1+tri1[3].z)
      tri1[6] = vec(tri1[6].x+greedyMeshed.width+1,tri1[6].y,1)
      tri1[7] = vec(tri1[7].x+greedyMeshed.width+1,tri1[7].y+greedyMeshed.height+1,1)
      tri1[8] = vec(tri1[8].x,tri1[8].y+greedyMeshed.height+1,1)
      table.insert(mesh[1],tri1)

      local tri2 = table.pack(table.unpack(blockdata.north[2]))
      
      tri2.n = nil
      tri2[1] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[1].x,greedyMeshed.y+tri2[1].y,greedyMeshed.z+greedyMeshed.depth-1+tri2[1].z)
      tri2[2] = vec(greedyMeshed.x+tri2[2].x,greedyMeshed.y+greedyMeshed.height-1+tri2[2].y,greedyMeshed.z+greedyMeshed.depth-1+tri2[2].z)
      tri2[3] = vec(greedyMeshed.x+tri2[3].x,greedyMeshed.y+tri2[3].y,greedyMeshed.z+greedyMeshed.depth-1+tri2[3].z)
      tri2[6] = vec(tri2[6].x+greedyMeshed.width+1,tri2[6].y,1)
      tri2[7] = vec(tri2[7].x,tri2[7].y+greedyMeshed.height+1,1)
      tri2[8] = vec(tri2[8].x,tri2[8].y,1)
      table.insert(mesh[1],tri2)




      local tri1 = table.pack(table.unpack(blockdata.west[1]))
      
      tri1.n = nil
      tri1[1] = vec(greedyMeshed.x+tri1[1].x,greedyMeshed.y+tri1[1].y,greedyMeshed.z+greedyMeshed.depth-1+tri1[1].z)
      tri1[2] = vec(greedyMeshed.x+tri1[2].x,greedyMeshed.y+greedyMeshed.height-1+tri1[2].y,greedyMeshed.z+greedyMeshed.depth-1+tri1[2].z)
      tri1[3] = vec(greedyMeshed.x+tri1[3].x,greedyMeshed.y+greedyMeshed.height-1+tri1[3].y,greedyMeshed.z+tri1[3].z)
      tri1[6] = vec(tri1[6].x+greedyMeshed.depth+1,tri1[6].y,1)
      tri1[7] = vec(tri1[7].x+greedyMeshed.depth+1,tri1[7].y+greedyMeshed.height+1,1)
      tri1[8] = vec(tri1[8].x,tri1[8].y+greedyMeshed.height+1,1)
      table.insert(mesh[1],tri1)

      local tri2 = table.pack(table.unpack(blockdata.west[2]))
      
      tri2.n = nil
      tri2[1] = vec(greedyMeshed.x+tri2[1].x,greedyMeshed.y+tri2[1].y,greedyMeshed.z+greedyMeshed.depth-1+tri2[1].z)
      tri2[2] = vec(greedyMeshed.x+tri2[2].x,greedyMeshed.y+greedyMeshed.height-1+tri2[2].y,greedyMeshed.z+tri2[2].z)
      tri2[3] = vec(greedyMeshed.x+tri2[3].x,greedyMeshed.y+tri2[3].y,greedyMeshed.z+tri2[3].z)
      tri2[6] = vec(tri2[6].x+greedyMeshed.depth+1,tri2[6].y,1)
      tri2[7] = vec(tri2[7].x,tri2[7].y+greedyMeshed.height+1,1)
      tri2[8] = vec(tri2[8].x,tri2[8].y,1)
      table.insert(mesh[1],tri2)



      local tri1 = table.pack(table.unpack(blockdata.east[1]))
      
      tri1.n = nil
      tri1[1] = vec(greedyMeshed.x+greedyMeshed.width-1+tri1[1].x,greedyMeshed.y+tri1[1].y,greedyMeshed.z+tri1[1].z)
      tri1[2] = vec(greedyMeshed.x+greedyMeshed.width-1+tri1[2].x,greedyMeshed.y+greedyMeshed.height-1+tri1[2].y,greedyMeshed.z+tri1[2].z)
      tri1[3] = vec(greedyMeshed.x+greedyMeshed.width-1+tri1[3].x,greedyMeshed.y+greedyMeshed.height-1+tri1[3].y,greedyMeshed.z+greedyMeshed.depth-1+tri1[3].z)
      tri1[6] = vec(tri1[6].x+greedyMeshed.depth+1,tri1[6].y,1)
      tri1[7] = vec(tri1[7].x+greedyMeshed.depth+1,tri1[7].y+greedyMeshed.height+1,1)
      tri1[8] = vec(tri1[8].x,tri1[8].y+greedyMeshed.height+1,1)
      table.insert(mesh[1],tri1)


      local tri2 = table.pack(table.unpack(blockdata.east[2]))
      
      tri2.n = nil
      tri2[1] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[1].x,greedyMeshed.y+tri2[1].y,greedyMeshed.z+tri2[1].z)
      tri2[2] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[2].x,greedyMeshed.y+greedyMeshed.height-1+tri2[2].y,greedyMeshed.z+greedyMeshed.depth-1+tri2[2].z)
      tri2[3] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[3].x,greedyMeshed.y+tri2[3].y,greedyMeshed.z+greedyMeshed.depth-1+tri2[3].z)
      tri2[6] = vec(tri2[6].x,tri2[6].y,1)
      tri2[7] = vec(tri2[7].x+greedyMeshed.depth-1,tri2[7].y+greedyMeshed.height+1,1)
      tri2[8] = vec(tri2[8].x+greedyMeshed.depth-1,tri2[8].y,1)
      table.insert(mesh[1],tri2)



      local tri1 = table.pack(table.unpack(blockdata.bottom[1]))
      
      tri1.n = nil
      tri1[1] = vec(greedyMeshed.x+greedyMeshed.width-1+tri1[1].x,greedyMeshed.y+tri1[1].y,greedyMeshed.z+greedyMeshed.depth-1+tri1[1].z)
      tri1[2] = vec(greedyMeshed.x+tri1[2].x,greedyMeshed.y+tri1[2].y,greedyMeshed.z+greedyMeshed.depth-1+tri1[2].z)
      tri1[3] = vec(greedyMeshed.x+tri1[3].x,greedyMeshed.y+tri1[3].y,greedyMeshed.z+tri1[3].z)
      tri1[6] = vec(tri1[6].x,tri1[6].y,1)
      tri1[7] = vec(tri1[7].x,tri1[7].y+greedyMeshed.width+1,1)
      tri1[8] = vec(tri1[8].x+greedyMeshed.depth-1,tri1[8].y+greedyMeshed.width+1,1)
      table.insert(mesh[1],tri1)


      local tri2 = table.pack(table.unpack(blockdata.bottom[2]))
      
      tri2.n = nil
      tri2[1] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[1].x,greedyMeshed.y+tri2[1].y,greedyMeshed.z+greedyMeshed.depth-1+tri2[1].z)
      tri2[2] = vec(greedyMeshed.x+tri2[2].x,greedyMeshed.y+tri2[2].y,greedyMeshed.z+tri2[2].z)
      tri2[3] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[3].x,greedyMeshed.y+tri2[3].y,greedyMeshed.z+tri2[3].z)--[[
      tri2.n = nil
      tri2[1] = vec(greedyMeshed.x+tri2[1].x,greedyMeshed.y+tri2[1].y+greedyMeshed.height-1,greedyMeshed.z+tri2[1].z)
      tri2[2] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[2].x,greedyMeshed.y+tri2[2].y+greedyMeshed.height-1,greedyMeshed.z+greedyMeshed.depth-1+tri2[2].z)
      tri2[3] = vec(greedyMeshed.x+greedyMeshed.width-1+tri2[3].x,greedyMeshed.y+tri2[3].y+greedyMeshed.height-1,greedyMeshed.z+tri2[3].z)]]
      tri2[6] = vec(tri2[6].x,tri2[6].y,1)
      tri2[7] = vec(tri2[7].x+greedyMeshed.depth-1,tri2[7].y+greedyMeshed.width+1,1)
      tri2[8] = vec(tri2[8].x+greedyMeshed.depth-1,tri2[8].y,1)
      table.insert(mesh[1],tri2)
  end
  end  











































  
  --[[
  local tableXplus = {}
  local tableXminus = {}
  local tableYplus = {}
  local tableYminus = {}
  local tableZplus = {}
  local tableZminus = {}
  --then we create 6 tables with only the topmost,bottommost,northmost,southmost,eastmost and westmost blocks
  --im programming this on autopilot so this impementation is prolly sub-par
  local curY = 0
  local lowestY = false
  local run = false
  for i = 0, widthW do

        for k = 0, breadthW do
          curY = 0
        while curY < heightW do


          if blocksPos[i] then
            if blocksPos[i][curY] then
              if blocksPos[i][curY][k] then
                log(i,k,"sadasfdjsadsasdjk")

                if not lowestY then
                  if not tableYminus[i] then
                    tableYminus[i] = {}
                  end

                  tableYminus[i][k] = {blocksPos[i][curY][k],true,curY}
                  lowestY = true
                end 
                
                if not tableYplus[i] then
                  tableYplus[i] = {}
                end


                  tableYplus[i][k] = {blocksPos[i][curY][k],true,curY}

              end  
            end
          end
          run = true
          curY = curY + 1
        end
      end
    run = false

      lowestY = false


  end




local scaleX = 0 
local scaleZ = 0 
local curPosToCheck = vec(0,0)
local originY 
local originBlockType 
local tblMarkForDeletion = {}
local curValsTbl = {}
local ValsTbl = {}
local runloop = true
local runX = true
local runZ = false
local runZ2 = false

    for x, tblx in pairs(tableYplus) do
      log(tblx,"asdasdasasdsaddassddsadssdaadsadsadd")

      for z, data in pairs(tblx) do
        log(x,data[3],z,data[2],"pos+state")
        if data[2] == true then
          log(x,z,"LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL")
          originBlockType = nil
          originY = nil
          runloop = true
          runX = true
        curPosToCheck = vec(x,z)
        while runloop == true do
          log("asdaddas")

          if runX then
  
            if tableYplus[curPosToCheck.x] and tableYplus[curPosToCheck.x][curPosToCheck.y] and ((tableYplus[curPosToCheck.x][curPosToCheck.y][1] == originBlockType and tableYplus[curPosToCheck.x][curPosToCheck.y][3] == originY) or originBlockType==nil) and tableYplus[curPosToCheck.x][curPosToCheck.y][2] then
              if not originBlockType then
              originY = tableYplus[curPosToCheck.x][curPosToCheck.y][3]
              originBlockType = tableYplus[curPosToCheck.x][curPosToCheck.y][1]
              tableYplus[curPosToCheck.x][curPosToCheck.y][2] = false
              log(tableYplus[curPosToCheck.x][curPosToCheck.y][2],curPosToCheck)
              end
              tableYplus[curPosToCheck.x][curPosToCheck.y][2] = false
              scaleX = scaleX + 1
              curPosToCheck.y = curPosToCheck.y +1
              log(scaleX,"scale",curPosToCheck)
            else
              runloop = false
              runX = false
       


            end  
          end
          if runZ then
            
          end

          blockdata = {}
          if data[1] == 1 then
            blockdata = blocks.grass
          end
        end
        if scaleX > 0 then
  local tri1 = table.pack(table.unpack(blockdata.top[1]))
          
          tri1.n = nil
          tri1[1] = vec(x+tri1[1].x,data[3]+tri1[1].y,z+tri1[1].z)
          tri1[2] = vec(x+tri1[2].x,data[3]+tri1[2].y,z+scaleX+tri1[2].z)
          tri1[3] = vec(x+tri1[3].x,data[3]+tri1[3].y,z+scaleX+tri1[3].z)
          tri1[6] = vec(tri1[6].x,tri1[6].y,1)
          tri1[7] = vec(tri1[7].x,scaleX+tri1[7].y,1)
          tri1[8] = vec(tri1[8].x,scaleX+tri1[8].y,1)
          table.insert(mesh[1],tri1)
          local tri2 = table.pack(table.unpack(blockdata.top[2]))
          
          tri2.n = nil
          tri2[1] = vec(x+tri2[1].x,data[3]+tri2[1].y,z+tri2[1].z)
          tri2[2] = vec(x+tri2[2].x,data[3]+tri2[2].y,z+scaleX+tri2[2].z)
          tri2[3] = vec(x+tri2[3].x,data[3]+tri2[3].y,z+tri2[3].z)
          tri2[6] = vec(tri2[6].x,tri2[6].y,1)
          tri2[7] = vec(tri2[7].x,scaleX+tri2[7].y,1)
          tri2[8] = vec(tri2[8].x,tri2[8].y,1)
          table.insert(mesh[1],tri2)
          

scaleX = 0

        end
      end
    end
    end



]]
end





local prevXYZ

function pings.place()
  _,hit = raycast3DGrid(World,vec(cameraPos.x,-cameraPos.y,-cameraPos.z),vec(lookDir.x,-lookDir.y,-lookDir.z),20)

      if hit and _ then
        x = math.ceil(hit.x) y = math.ceil(hit.y) z = math.ceil(hit.z)
        prevXYZ = vec(x,math.abs(y),math.abs(z))
        if World[prevXYZ.x] and World[prevXYZ.x][prevXYZ.y] and World[prevXYZ.x][prevXYZ.y][prevXYZ.z] then
        World[prevXYZ.x][prevXYZ.y][prevXYZ.z] = curBlock
        updateMesh()
        end

      end

end


function pings.destroy()
  hit = raycast3DGrid(World,vec(cameraPos.x,-cameraPos.y,-cameraPos.z),vec(lookDir.x,-lookDir.y,-lookDir.z),20)

      if hit then
        x = math.ceil(hit.x) y = math.ceil(hit.y) z = math.ceil(hit.z)
        prevXYZ = vec(x,math.abs(y),math.abs(z))
        World[hit.x][hit.y][hit.z] = 0
        updateMesh()
      end
end
local prevXYZ1
function highlight()
mesh[2] = {}
  prevXYZ1 = nil
  local tri1 = table.pack(table.unpack(blocks.highlight.top[1]))
  local tri2 = table.pack(table.unpack(blocks.highlight.south[1]))
  local tri3 = table.pack(table.unpack(blocks.highlight.north[1]))
  local tri4 = table.pack(table.unpack(blocks.highlight.west[1]))
  local tri5 = table.pack(table.unpack(blocks.highlight.east[1]))
  local tri6 = table.pack(table.unpack(blocks.highlight.bottom[1]))--vec(x+tri1[1].x,math.abs(y)+tri1[1].y,math.abs(z)+tri1[1].z)
  
hit = raycast3DGrid(World,vec(cameraPos.x,-cameraPos.y,-cameraPos.z),vec(lookDir.x,-lookDir.y,-lookDir.z),20)

    if hit then
      x = math.ceil(hit.x) y = math.ceil(hit.y) z = math.ceil(hit.z)


                prevXYZ1 = vec(x,math.abs(y),-math.abs(z))

          

                    tri1.n = nil
                    tri1[1] = vec(math.abs(prevXYZ1.x)+tri1[1].x*1.08,math.abs(prevXYZ1.y)+tri1[1].y*1.08,math.abs(prevXYZ1.z)+tri1[1].z*1.08):sub(0.04,0.04,0.04)
                    tri1[2] = vec(math.abs(prevXYZ1.x)+tri1[2].x*1.08,math.abs(prevXYZ1.y)+tri1[2].y*1.08,math.abs(prevXYZ1.z)+tri1[2].z*1.08):sub(0.04,0.04,0.04)
                    tri1[3] = vec(math.abs(prevXYZ1.x)+tri1[3].x*1.08,math.abs(prevXYZ1.y)+tri1[3].y*1.08,math.abs(prevXYZ1.z)+tri1[3].z*1.08):sub(0.04,0.04,0.04)
                    tri2.n = nil
                    tri2[1] = vec(math.abs(prevXYZ1.x)+tri2[1].x*1.08,math.abs(prevXYZ1.y)+tri2[1].y*1.08,math.abs(prevXYZ1.z)+tri2[1].z*1.08):sub(0.04,0.04,0.04)
                    tri2[2] = vec(math.abs(prevXYZ1.x)+tri2[2].x*1.08,math.abs(prevXYZ1.y)+tri2[2].y*1.08,math.abs(prevXYZ1.z)+tri2[2].z*1.08):sub(0.04,0.04,0.04)
                    tri2[3] = vec(math.abs(prevXYZ1.x)+tri2[3].x*1.08,math.abs(prevXYZ1.y)+tri2[3].y*1.08,math.abs(prevXYZ1.z)+tri2[3].z*1.08):sub(0.04,0.04,0.04)
                    tri3.n = nil
                    tri3[1] = vec(math.abs(prevXYZ1.x)+tri3[1].x*1.08,math.abs(prevXYZ1.y)+tri3[1].y*1.08,math.abs(prevXYZ1.z)+tri3[1].z*1.08):sub(0.04,0.04,0.04)
                    tri3[2] = vec(math.abs(prevXYZ1.x)+tri3[2].x*1.08,math.abs(prevXYZ1.y)+tri3[2].y*1.08,math.abs(prevXYZ1.z)+tri3[2].z*1.08):sub(0.04,0.04,0.04)
                    tri3[3] = vec(math.abs(prevXYZ1.x)+tri3[3].x*1.08,math.abs(prevXYZ1.y)+tri3[3].y*1.08,math.abs(prevXYZ1.z)+tri3[3].z*1.08):sub(0.04,0.04,0.04)
                    tri4.n = nil
                    tri4[1] = vec(math.abs(prevXYZ1.x)+tri4[1].x*1.08,math.abs(prevXYZ1.y)+tri4[1].y*1.08,math.abs(prevXYZ1.z)+tri4[1].z*1.08):sub(0.04,0.04,0.04)
                    tri4[2] = vec(math.abs(prevXYZ1.x)+tri4[2].x*1.08,math.abs(prevXYZ1.y)+tri4[2].y*1.08,math.abs(prevXYZ1.z)+tri4[2].z*1.08):sub(0.04,0.04,0.04)
                    tri4[3] = vec(math.abs(prevXYZ1.x)+tri4[3].x*1.08,math.abs(prevXYZ1.y)+tri4[3].y*1.08,math.abs(prevXYZ1.z)+tri4[3].z*1.08):sub(0.04,0.04,0.04)
                    tri5.n = nil
                    tri5[1] = vec(math.abs(prevXYZ1.x)+tri5[1].x*1.08,math.abs(prevXYZ1.y)+tri5[1].y*1.08,math.abs(prevXYZ1.z)+tri5[1].z*1.08):sub(0.04,0.04,0.04)
                    tri5[2] = vec(math.abs(prevXYZ1.x)+tri5[2].x*1.08,math.abs(prevXYZ1.y)+tri5[2].y*1.08,math.abs(prevXYZ1.z)+tri5[2].z*1.08):sub(0.04,0.04,0.04)
                    tri5[3] = vec(math.abs(prevXYZ1.x)+tri5[3].x*1.08,math.abs(prevXYZ1.y)+tri5[3].y*1.08,math.abs(prevXYZ1.z)+tri5[3].z*1.08):sub(0.04,0.04,0.04)
                    tri6.n = nil
                    tri6[1] = vec(math.abs(prevXYZ1.x)+tri6[1].x*1.08,math.abs(prevXYZ1.y)+tri6[1].y*1.08,math.abs(prevXYZ1.z)+tri6[1].z*1.08):sub(0.04,0.04,0.04)
                    tri6[2] = vec(math.abs(prevXYZ1.x)+tri6[2].x*1.08,math.abs(prevXYZ1.y)+tri6[2].y*1.08,math.abs(prevXYZ1.z)+tri6[2].z*1.08):sub(0.04,0.04,0.04)
                    tri6[3] = vec(math.abs(prevXYZ1.x)+tri6[3].x*1.08,math.abs(prevXYZ1.y)+tri6[3].y*1.08,math.abs(prevXYZ1.z)+tri6[3].z*1.08):sub(0.04,0.04,0.04)
                   mesh[2] = {tri1,tri2,tri3,tri4,tri5,tri6}

         

    end
      

end  



function bresenham3D(x1, y1, z1, x2, y2, z2, callback)
  local points = {}

  -- Calculate deltas
  local dx = math.abs(x2 - x1)
  local dy = math.abs(y2 - y1)
  local dz = math.abs(z2 - z1)

  -- Determine the direction of the line
  local sx = (x1 < x2) and 1 or -1
  local sy = (y1 < y2) and 1 or -1
  local sz = (z1 < z2) and 1 or -1

  -- Initialize the error values
  local err_x = dx / 2
  local err_y = dy / 2
  local err_z = dz / 2

  -- Start at the first point
  local x, y, z = x1, y1, z1

  -- Iterate over the points along the line
  while true do
      -- Run the inputted function (callback) with the current point
      -- If the callback returns false, stop the algorithm
      if callback and not callback(x, y, z) then
          break
      end

      -- Add the current point to the list
      table.insert(points, {x, y, z})

      -- If we've reached the end point, exit the loop
      if x == x2 and y == y2 and z == z2 then
          break
      end

      -- Compare errors and move along the axis with the largest error
      if err_x >= err_y and err_x >= err_z then
          -- Move along the X axis
          err_x = err_x - dx
          x = x + sx
      elseif err_y >= err_x and err_y >= err_z then
          -- Move along the Y axis
          err_y = err_y - dy
          y = y + sy
      else
          -- Move along the Z axis
          err_z = err_z - dz
          z = z + sz
      end

      -- Update the error terms
      err_x = err_x + dx
      err_y = err_y + dy
      err_z = err_z + dz
  end

  return points
end







local function projectPointOntoPlane(point, planeNormal, planePoint)
  local pointToPlane = point - planePoint
  local distanceToPlane = pointToPlane:dot( planeNormal)
  return (point- planeNormal* distanceToPlane)
end


-- Check if a point is inside a triangle using barycentric coordinates
local function pointInTriangle(point, v0, v1, v2)
  local v0v1 = v1 - v0
  local v0v2 = v2 - v0
  local v0p = point - v0

  local d00 = v0v1:dot(v0v1)
  local d01 = v0v1:dot(v0v2)
  local d11 = v0v2:dot( v0v2)
  local d20 = v0p:dot( v0v1)
  local d21 = v0p:dot( v0v2)

  local denom = d00 * d11 - d01 * d01
  local v = (d11 * d20 - d01 * d21) / denom
  local w = (d00 * d21 - d01 * d20) / denom
  local u = 1 - v - w

  return u >= 0 and v >= 0 and w >= 0
end

-- Sphere-Triangle collision and resolution function
function sphereTriangleCollision(sphereCenter, sphereRadius, v0, v1, v2)
  -- Step 1: Calculate triangle normal

  local edge1 = v1 - v0
  local edge2 = v2 - v0
  local triangleNormal = edge1:crossed(edge2):normalize()

  -- Step 2: Project the sphere's center onto the plane of the triangle
  local projectedPoint = projectPointOntoPlane(sphereCenter, triangleNormal, v0)

  -- Step 3: Check if the projected point is within the triangle using barycentric coordinates
  if pointInTriangle(projectedPoint, v0, v1, v2) then
      -- Step 4: Calculate the distance from the sphere's center to the plane
      local distanceToPlane = (sphereCenter- v0):dot(triangleNormal)

      -- Step 5: If the distance is less than the sphere's radius, resolve the collision
      if math.abs(distanceToPlane) < sphereRadius then

          -- Move the sphere along the normal of the triangle to push it out of the collision
          local penetrationDepth = sphereRadius - math.abs(distanceToPlane)
          local moveDirection = triangleNormal* penetrationDepth
          if distanceToPlane < 0 then
              moveDirection = moveDirection* -1 -- Adjust direction if sphere is below the triangle plane
          end
          -- Move the sphere's center out of the triangle plane
          sphereCenter = sphereCenter+ moveDirection

          if triangleNormal.y < -0.4 then  -- Arbitrary threshold, adjust based on your use case
            grounded = true
          end
          if triangleNormal.y > 0.4 then  -- Arbitrary threshold, adjust based on your use case
            grounded = true
          end
        end
  end

  -- Step 6: Return the adjusted sphere center
  return sphereCenter
end



-- Performs a raycast on a 3D grid and returns two values:
-- 1. The coordinates of the first non-zero block hit
-- 2. The coordinates of the last empty block (previous block) before the hit

function raycast3DGrid(tbl, origin, direction, maxDistance)
  -- Helper function to avoid division by zero
  local function safeDiv(a, b)
      return (b == 0 and math.huge or a / b)
  end
  
  -- Starting position in the grid (round to nearest integer)
  local x = math.floor(origin.x)
  local y = math.floor(origin.y)
  local z = math.floor(origin.z)
  
  -- Determine the step direction (either -1 or 1 for each axis)
  local stepX = direction.x > 0 and 1 or -1
  local stepY = direction.y > 0 and 1 or -1
  local stepZ = direction.z > 0 and 1 or -1
  
  -- Calculate initial tMax and tDelta for the ray
  local tMaxX = safeDiv((x + (stepX > 0 and 1 or 0) - origin.x), direction.x)
  local tMaxY = safeDiv((y + (stepY > 0 and 1 or 0) - origin.y), direction.y)
  local tMaxZ = safeDiv((z + (stepZ > 0 and 1 or 0) - origin.z), direction.z)
  
  local tDeltaX = safeDiv(stepX, direction.x)
  local tDeltaY = safeDiv(stepY, direction.y)
  local tDeltaZ = safeDiv(stepZ, direction.z)

  -- Initialize the previous block coordinates
  local previousBlock = {x = x, y = y, z = z}

  -- Traverse the grid
  local distanceTraveled = 0
  while distanceTraveled < maxDistance do
      -- Check if the current block is non-zero
      if tbl[x] and tbl[x][y] and tbl[x][y][z] and tbl[x][y][z] ~= 0 then
          -- Return the hit block and the previous empty block
          return {x = x, y = y, z = z}, previousBlock
      end
      
      -- Update the previous block (the current block before moving)
      previousBlock = {x = x, y = y, z = z}

      -- Move to the next block
      if tMaxX < tMaxY and tMaxX < tMaxZ then
          x = x + stepX
          distanceTraveled = tMaxX
          tMaxX = tMaxX + tDeltaX
      elseif tMaxY < tMaxZ then
          y = y + stepY
          distanceTraveled = tMaxY
          tMaxY = tMaxY + tDeltaY
      else
          z = z + stepZ
          distanceTraveled = tMaxZ
          tMaxZ = tMaxZ + tDeltaZ
      end
  end
  
  -- If no hit was found within the maximum distance, return nil for both
  return nil, previousBlock
end