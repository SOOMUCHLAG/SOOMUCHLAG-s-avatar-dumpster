
if host:isHost() then
    log("PPPPPAAAAANNNNNEEEELELLLLLSSSSS")
local panels = require('panels.main')
local page = panels.newPage('main')
panels.setPage(page)
do
    local obj = page:newText()
    obj:setText('Choose a block')
    obj:setSize(2, 2)
    obj:setMargin(4)
  end
  page:newSlider():setText(' :ping4: Set Delta t'):setColor(1, 1, 1):setMax(10):setMin(1):setValue(1):setStep(1, 1):allowWarping(false):onScroll(function(value, self) pings.block(value) if value == 1 then host:setActionbar("Grass Block") end 
  if value == 2 then host:setActionbar("Stone Block") end   if value == 3 then host:setActionbar("Cobblestone") end   if value == 4 then host:setActionbar("Oak Planks") end
  if value == 5 then host:setActionbar("Oak Log") end   if value == 6 then host:setActionbar("Oak Leaves") end  if value == 7 then host:setActionbar("Stone Bricks") end
  if value == 8 then host:setActionbar("Sand") end  if value == 9 then host:setActionbar("Copper Block") end  if value == 10 then host:setActionbar("Diamond Block") end
   end)
end


function pings.block(value)
curBlock = value
end
