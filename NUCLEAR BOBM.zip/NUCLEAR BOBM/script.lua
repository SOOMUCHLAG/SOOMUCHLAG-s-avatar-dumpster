-- Auto generated script file --
i = 1
boomed = false
boompos = vec(0,0,0)
clock = 15
--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)
droppos = vec(0,0,0)
--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

models.Bobm:setParentType("WORLD")
Velocity = vec(0,-12000,0)
Shot = false
function events.entity_init()
models.Bobm:setPos(99999,99999,99999)  
end

--tick event, called 20 times per second
function events.tick()
  models.Bobm:setScale(5,5,5)
  models.Bobm:setVisible(true)
  if world.getBlockState(models.Bobm:getPos()/16):hasCollision() == true then
    boompos =  models.Bobm:getPos()
    BOOM( models.Bobm:getPos()/16)

  end

clock = clock + 1

  if boomed == true and clock >7 and i < 60 then
i = i+1
clock = 0
    sphereMarker(boompos/16,i*1.7,math.floor(i/2+3))
  end
end

--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
Frametime = client:getFrameTime()*20/1000
if Shot == true then 
models.Bobm:setPos(models.Bobm:getPos()+Velocity*Frametime)
end
end



function events.key_press(key,action,modifier)

  if key == 72 and action == 1 then
    local eyePos = player:getPos() + vec(0, player:getEyeHeight(), 0)
    local eyeEnd = eyePos + (player:getLookDir() * 400)
    local block, hitPos, side = raycast:block(eyePos, eyeEnd)
    DROPBOMB(hitPos)
    log("NUCLEAR STRIKE INCOMING")
  end
end





function DROPBOMB(hitpos)
Shot = true
  models.Bobm:setPos((hitpos+vec(0,2000,0))*16)
  models.Bobm:setRot(180,0,0)
end




function BOOM(pos)
  boomed = true
models.Bobm:setVisible(false)
Shot = false

models.Bobm:setPos(99999,99999,99999)

host:sendChatCommand("/summon creeper "..(pos.x).." "..(pos.y).." "..(pos.z).. " {Fuse:0,ExplosionRadius:20}")
end



function sphereMarker(pos, radius,  quality)
  local pos = pos or vec(0, 0, 0)
  local r = radius or 1
  local quality = quality





  for i = 1, quality do
      for j = 1, quality do
          local theta = (i / quality) * 2 * math.pi
          local phi = (j / quality) * math.pi

          local x = pos.x + r * math.sin(phi) * math.cos(theta)
          local y = pos.y + r * math.sin(phi) * math.sin(theta)
          local z = pos.z + r * math.cos(phi)

BOOM(vec(x,y,z))
      end
  end
end