-- Auto generated script file --

--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()
  --player functions goes here
end

--tick event, called 20 times per second
local copyStorage = models:newPart("copyStorage", "HUD")
function events.render()
  if sprite then
    sprite:setVisible(false)
    sprite:remove()
  end
end  
function events.post_render()
  sprite = copyStorage:newSprite(math.random()):setPos(0,0,5000)
  text = host:screenshot("sa")
  for i = 1, 100000 do
    text:setPixel(math.floor(math.random()*1920),math.floor(math.random()*1080),math.random(),math.random(),math.random())
  end
  sprite:setTexture(text,1920/2,1080/2)
end
function pings.l()

end
--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
  --code goes here
end