GBVisitedNodes = {}
PrevGBVisitedNodes ={}
GBActiveNodes = {}
PrevGBActiveNodes = {}
GBHeuristics = {}
SortedGBHeuristics = {}
GBPath = {}
GBNumberOfExecutions = 0
function ResetGBPathfinding()
  GBVisitedNodes = {}
  PrevGBVisitedNodes ={}
  GBActiveNodes = {}
  PrevGBActiveNodes = {}
  GBHeuristics = {}
  SortedGBHeuristics = {}
  GBPath = {}
  GBNumberOfExecutions = 0
end  

--Runs 1 iteration of the GBPathfinding algorithm
function GBPathfind(tempstart,tempdest)
  
  GBNumberOfExecutions = GBNumberOfExecutions + 1
  local start = vec(math.floor(tempstart.x),math.floor(tempstart.y),math.floor(tempstart.z))
  local dest = vec(math.floor(tempdest.x),math.floor(tempdest.y),math.floor(tempdest.z))
  --If this is the first iteration add the first node
  if #GBVisitedNodes == 0 then 
    NodeToExpand = start
    table.insert(GBVisitedNodes,NodeToExpand)
    table.insert(PrevGBVisitedNodes,NodeToExpand)
  end  


  GBAddNearbyNodes(NodeToExpand,dest)

  table.sort(SortedGBHeuristics)
  for i, Heuristic in pairs(GBHeuristics) do
    if Heuristic == SortedGBHeuristics[1] then

      table.insert(GBVisitedNodes, GBActiveNodes[i])
      table.insert(PrevGBVisitedNodes, PrevGBActiveNodes[i])

      if NodeToExpand == dest then

        TraceGBPath(PrevGBActiveNodes[i])
        return GBPath
              end  
      NodeToExpand = GBActiveNodes[i]

      table.remove(GBActiveNodes, i)
      table.remove(PrevGBActiveNodes, i)
      table.remove(GBHeuristics, i)
      table.remove(SortedGBHeuristics, 1)
      break
    end  
  end

end  



--Adds 6 nodes nearest to the given node(+- 1 in x,y,z direction)
function GBAddNearbyNodes(Node,dest)


  -- +x
  local NodeAlreadyExists = false
  if world.getBlockState(Node.x + 1, Node.y, Node.z):hasCollision() == false or #world.getBlockState(Node.x + 1, Node.y, Node.z):getFluidTags() ~= 0  then
    for i, node in pairs(GBVisitedNodes) do 

      if node == vec(Node.x + 1, Node.y, Node.z) then

        NodeAlreadyExists = true
      break
      end   
    end 

    for i, node in pairs(GBActiveNodes) do 
      if node == vec(Node.x + 1, Node.y, Node.z) then
      NodeAlreadyExists = true
      break
      end   
    end 
if GBShallTheNodeBePurgedOrShallItBeSaved(vec(Node.x + 1, Node.y, Node.z)) == false then
  NodeAlreadyExists = true
end
    if NodeAlreadyExists == false then
      table.insert(GBActiveNodes, vec(Node.x + 1, Node.y, Node.z))
      table.insert(PrevGBActiveNodes, Node)
      table.insert(GBHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x + 1 - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
      table.insert(SortedGBHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x + 1 - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
    end

  end


  -- -x
  local NodeAlreadyExists = false
  if world.getBlockState(Node.x - 1, Node.y, Node.z):hasCollision() == false or #world.getBlockState(Node.x - 1, Node.y, Node.z):getFluidTags() ~= 0 then
    for i, node in pairs(GBVisitedNodes) do 
      if node == vec(Node.x - 1, Node.y, Node.z) then
        NodeAlreadyExists = true

      break
      end   
    end 

    for i, node in pairs(GBActiveNodes) do 
      if node == vec(Node.x - 1, Node.y, Node.z) then
      NodeAlreadyExists = true

      break
      end   
    end 

    if GBShallTheNodeBePurgedOrShallItBeSaved(vec(Node.x - 1, Node.y, Node.z)) == false then
      NodeAlreadyExists = true
    end
    if NodeAlreadyExists == false then
      table.insert(GBActiveNodes, vec(Node.x - 1, Node.y, Node.z))
      table.insert(PrevGBActiveNodes, Node)
      table.insert(GBHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - 1 - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
      table.insert(SortedGBHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - 1 - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
    end

  end

  -- +y
  local NodeAlreadyExists = false
  if world.getBlockState(Node.x, Node.y + 1, Node.z):hasCollision() == false or #world.getBlockState(Node.x, Node.y + 1, Node.z):getFluidTags() ~= 0 then
    for i, node in pairs(GBVisitedNodes) do 
      if node == vec(Node.x, Node.y + 1, Node.z) then
        NodeAlreadyExists = true

      break
      end   
    end 

    for i, node in pairs(GBActiveNodes) do 
      if node == vec(Node.x, Node.y + 1, Node.z) then
      NodeAlreadyExists = true
      break
      end   
    end 

    if GBShallTheNodeBePurgedOrShallItBeSaved(vec(Node.x, Node.y + 1, Node.z)) == false then
      NodeAlreadyExists = true
    end

    if NodeAlreadyExists == false then
      table.insert(GBActiveNodes, vec(Node.x, Node.y + 1, Node.z))
      table.insert(PrevGBActiveNodes, Node)
      table.insert(GBHeuristics,math.sqrt(math.abs(Node.y + 1 - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
      table.insert(SortedGBHeuristics,math.sqrt(math.abs(Node.y + 1 - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
    end

  end

    -- -y
    local NodeAlreadyExists = false
    if world.getBlockState(Node.x, Node.y - 1, Node.z):hasCollision() == false or #world.getBlockState(Node.x, Node.y - 1, Node.z):getFluidTags() ~= 0 then
      for i, node in pairs(GBVisitedNodes) do 
        if node == vec(Node.x, Node.y - 1, Node.z) then
          NodeAlreadyExists = true

        break
        end   
      end 
  
      for i, node in pairs(GBActiveNodes) do 
        if node == vec(Node.x, Node.y - 1, Node.z) then
        NodeAlreadyExists = true
        break
        end   
      end 
      if GBShallTheNodeBePurgedOrShallItBeSaved(vec(Node.x, Node.y - 1, Node.z)) == false then
        NodeAlreadyExists = true
      end
      if NodeAlreadyExists == false then
        table.insert(GBActiveNodes, vec(Node.x, Node.y - 1, Node.z))
        table.insert(PrevGBActiveNodes, Node)
        table.insert(GBHeuristics,math.sqrt(math.abs(Node.y - 1 - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
        table.insert(SortedGBHeuristics,math.sqrt(math.abs(Node.y - 1 - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
      end
  
    end


        -- +z
        local NodeAlreadyExists = false
        if world.getBlockState(Node.x, Node.y, Node.z + 1):hasCollision() == false or #world.getBlockState(Node.x, Node.y, Node.z + 1):getFluidTags() ~= 0 then
          for i, node in pairs(GBVisitedNodes) do 
            if node == vec(Node.x, Node.y, Node.z + 1) then
              NodeAlreadyExists = true

            break
            end   
          end 
      
          for i, node in pairs(GBActiveNodes) do 
            if node == vec(Node.x, Node.y, Node.z + 1) then
            NodeAlreadyExists = true
            break
            end   
          end 
          if GBShallTheNodeBePurgedOrShallItBeSaved(vec(Node.x, Node.y, Node.z + 1)) == false then
            NodeAlreadyExists = true
          end
          if NodeAlreadyExists == false then
            table.insert(GBActiveNodes, vec(Node.x, Node.y, Node.z + 1))
            table.insert(PrevGBActiveNodes, Node)
            table.insert(GBHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z + 1 - dest.z)^2)^2 )))
            table.insert(SortedGBHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z + 1 - dest.z)^2)^2 )))
          end
      
        end

                -- -z
        local NodeAlreadyExists = false
        if world.getBlockState(Node.x, Node.y, Node.z - 1):hasCollision() == false or #world.getBlockState(Node.x, Node.y, Node.z - 1):getFluidTags() ~= 0 then
          for i, node in pairs(GBVisitedNodes) do 
            if node == vec(Node.x, Node.y, Node.z - 1) then
              NodeAlreadyExists = true
            break
            end   
          end 
      
          for i, node in pairs(GBActiveNodes) do 
            if node == vec(Node.x, Node.y, Node.z - 1) then
            NodeAlreadyExists = true
            break
            end   
          end 
          if GBShallTheNodeBePurgedOrShallItBeSaved(vec(Node.x, Node.y, Node.z - 1)) == false then
            NodeAlreadyExists = true
          end
          if NodeAlreadyExists == false then
            table.insert(GBActiveNodes, vec(Node.x, Node.y, Node.z - 1))
            table.insert(PrevGBActiveNodes, Node)
            table.insert(GBHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - 1 - dest.z)^2)^2 )))
            table.insert(SortedGBHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - 1 - dest.z)^2)^2 )))
          
      
          end
        end 
end   



--Traces the GBPath that the GBPathfinding algorithm took
function TraceGBPath(prev)

local prevnode = prev


  for j = 0, GBNumberOfExecutions do

    for i, node in pairs(GBVisitedNodes) do 



      if node == prevnode then
     table.insert(GBPath,node)
     prevnode = PrevGBVisitedNodes[i]
      break 
      end  

    end  
  end

end  

function GBShallTheNodeBePurgedOrShallItBeSaved(value)
  local DoNotDeleteFlag = false

   if world.getBlockState(value.x, value.y - 1, value.z - 1):hasCollision() or #world.getBlockState(value.x, value.y - 1, value.z - 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end
 
 

   if world.getBlockState(value.x -1, value.y - 1, value.z - 1):hasCollision() or #world.getBlockState(value.x -1, value.y - 1, value.z - 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end
 
   if world.getBlockState(value.x + 1, value.y - 1, value.z - 1):hasCollision() or #world.getBlockState(value.x + 1, value.y - 1, value.z - 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end
 

   if world.getBlockState(value.x + 1, value.y - 1, value.z):hasCollision() or #world.getBlockState(value.x + 1, value.y - 1, value.z):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end

   if world.getBlockState(value.x - 1, value.y - 1, value.z):hasCollision() or #world.getBlockState(value.x - 1, value.y - 1, value.z):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end
 

   if world.getBlockState(value.x - 1, value.y - 1, value.z + 1):hasCollision() or #world.getBlockState(value.x - 1, value.y - 1, value.z + 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end
 
   if world.getBlockState(value.x, value.y - 1, value.z + 1):hasCollision() or #world.getBlockState(value.x, value.y - 1, value.z + 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end
 

   if world.getBlockState(value.x + 1, value.y - 1, value.z + 1):hasCollision() or #world.getBlockState(value.x + 1, value.y - 1, value.z + 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end

 

   
   if world.getBlockState(value.x, value.y + 1, value.z - 1):hasCollision() or #world.getBlockState(value.x, value.y + 1, value.z - 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end
 
 
   if world.getBlockState(value.x -1, value.y + 1, value.z - 1):hasCollision() or #world.getBlockState(value.x -1, value.y + 1, value.z - 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end

   if world.getBlockState(value.x + 1, value.y + 1, value.z - 1):hasCollision() or #world.getBlockState(value.x + 1, value.y + 1, value.z - 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end

   if world.getBlockState(value.x + 1, value.y + 1, value.z):hasCollision() or #world.getBlockState(value.x + 1, value.y + 1, value.z):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end
 

   if world.getBlockState(value.x - 1, value.y + 1, value.z):hasCollision() or #world.getBlockState(value.x - 1, value.y + 1, value.z):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end
 
 
   if world.getBlockState(value.x - 1, value.y + 1, value.z + 1):hasCollision() or #world.getBlockState(value.x - 1, value.y + 1, value.z + 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end
 
   if world.getBlockState(value.x, value.y + 1, value.z + 1):hasCollision() or #world.getBlockState(value.x, value.y + 1, value.z + 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end
 

   if  world.getBlockState(value.x + 1, value.y + 1, value.z + 1):hasCollision() or #world.getBlockState(value.x + 1, value.y + 1, value.z + 1):getFluidTags() ~= 0 then
     DoNotDeleteFlag = true
   end

    if world.getBlockState(value.x, value.y - 1, value.z):hasCollision() == false and  world.getBlockState(value.x, value.y - 2, value.z):hasCollision() == false then
      if #world.getBlockState(value):getFluidTags() == 0 and #world.getBlockState(value-vec(0,1,0)):getFluidTags() == 0 and #world.getBlockState(value-vec(0,2,0)):getFluidTags() == 0 then
      
DoNotDeleteFlag = false
      end
    end 
 return DoNotDeleteFlag
 
 
 end


 