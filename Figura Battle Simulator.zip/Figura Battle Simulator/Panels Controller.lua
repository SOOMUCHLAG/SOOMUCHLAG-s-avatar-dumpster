entityGravity = -1.6
GBPFiterations = 100
Friction = 1.2
Acceleration = 1
MaxVelocity = 15
JumpStrenth =0.48
AirFriction = 1.6
Buoyancy = 1.8
Amount = 0
Iframes=9
SpawnAmount = 1
MaxYVelocity = 15
Team = 0
Health = 20
Damage = 5
TempBattle = false
Battle = false
currentAnims = {walk = "walk", idle = "idle", hit = "hit"}
AI = "Melee Team"
if host:isHost() then
local panels = require('panels.main')
local page = panels.newPage('main')
local battle = panels.newPage('battle')
local spawner = panels.newPage('spawner')
local physics = panels.newPage('physics')
local miscellaneous = panels.newPage('Miscellaneous')
local ai = panels.newPage('ai')
local units = panels.newPage('units')
local Projectiles = panels.newPage('Projectiles')
panels.setPage(page)
do
    local obj = page:newText()
    obj:setText('Entities')
    obj:setSize(2, 2)
    obj:setMargin(4)
  end
page:newPageRedirect():setText(' :creeper: Units'):setPage('units')
page:newPageRedirect():setText(' :knife: Battle'):setPage('battle')
page:newPageRedirect():setText(' :minecraft: Entity Physics'):setPage('physics')
page:newPageRedirect():setText(' :folder: Miscellaneous'):setPage('Miscellaneous')
page:newPageRedirect():setText(' :folder: Projectiles[DEBUG]'):setPage('Projectiles')
do
    local obj = spawner:newText()
    obj:setText(' :terraria: Entity Spawner')
    obj:setSize(2, 2)
    obj:setMargin(4)
  end
units:newText():setText({text = ' :checkmark: Spawn Unit At Your Current Location'}):onPress(function(self) pings.SpawnAtPlayer() end)
units:newText():setText({text = ' :checkmark: Spawn Unit Where You Are Looking'}):onPress(function(self) pings.SpawnLook() end)
units:newSlider():setText(' :creeper: Spawn Amount'):setColor(1, 1, 1):setMax(10.00000001):setValue(1):setStep(1, 1):allowWarping(true):onScroll(function(value, self) pings.SpawnAmount(value) end)
units:newText():setText({text = ' :no_entry: Delete All Units'}):onPress(function(self) pings.DeleteAll() end)
units:newText():setText({text = ' :no_entry: Delete The Unit You Are Looking At'}):onPress(function(self) pings.DeleteLook() end)
units:newSlider():setText(' :pdn: Set Team'):setColor(1, 1, 1):setMax(3):setValue(Team):setStep(1, 1):allowWarping(false):onScroll(function(value, self) pings.setTeam(value) end)
units:newText():setText({text = ' :axe: Zombie(Melee)'}):onPress(function(self) pings.AIMeleeTeamZombie() end)
units:newText():setText({text = ' :axe: Skeleton(Melee)'}):onPress(function(self) pings.AIMeleeTeamSkeleton() end)
units:newText():setText({text = ' :gun: Skeleton(Ranged)'}):onPress(function(self) pings.AIRangedTeamSkeleton() end)
units:newReturnButton()
do
local obj = battle:newText()
obj:setText(' :knife: Battle')
obj:setSize(2, 2)
obj:setMargin(4)
end
battle:newText():setText({text = ' :knife: Start Battle'}):onPress(function(self) pings.BattleStart() end)
battle:newText():setText({text = ' :no_entry: End Battle'}):onPress(function(self) pings.BattleEnd() end)
battle:newReturnButton()
do
local obj = physics:newText()
obj:setText(' :minecraft: Entity Physics')
obj:setSize(2, 2)
obj:setMargin(4)
end
physics:newSlider():setText(' :ping4: Set Gravity B/S²'):setColor(1, 1, 1):setMax(10.00000001):setValue(-entityGravity):setStep(0.1, 0.1):allowWarping(true):onScroll(function(value, self) pings.setGravity(value) end)
physics:newSlider():setText(' :ping4: Set Max Y Velocity B/S'):setColor(1, 1, 1):setMax(1000.00000001):setValue(MaxYVelocity):setStep(1, 1):allowWarping(true):onScroll(function(value, self) pings.setMaxYVelocity(value) end)
physics:newSlider():setText(' :ping4: Set Friction'):setColor(1, 1, 1):setMax(10.00000001):setValue(Friction):setStep(0.01, 0.01):allowWarping(true):onScroll(function(value, self) pings.setFriction(value) end)
physics:newSlider():setText(' :ping4: Set Air Resistance'):setColor(1, 1, 1):setMax(10.00000001):setValue(AirFriction):setStep(0.01, 0.01):allowWarping(true):onScroll(function(value, self) pings.setAirFriction(value) end)
physics:newSlider():setText(' :ping4: Set Acceleration B/S²'):setColor(1, 1, 1):setMax(100.00000001):setValue(Acceleration):setStep(0.25, 0.25):allowWarping(true):onScroll(function(value, self) pings.setAcceleration(value) end)
physics:newSlider():setText(' :ping4: Max Velocity B/S'):setColor(1, 1, 1):setMax(1000.00000001):setValue(MaxVelocity):setStep(0.25, 0.25):allowWarping(true):onScroll(function(value, self) pings.setMaxVelocity(value) end)
physics:newSlider():setText(' :ping4: Set JumpStrenth B/S'):setColor(1, 1, 1):setMax(10.00000001):setValue(JumpStrenth):setStep(0.01, 0.01):allowWarping(true):onScroll(function(value, self) pings.setJumpStrength(value) end)
physics:newSlider():setText(' :ping4: Set Buoyancy B/S'):setColor(1, 1, 1):setMax(15.00000001):setValue(Buoyancy):setStep(0.1, 0.1):allowWarping(true):onScroll(function(value, self) pings.setBuoyancy(value) end)
physics:newReturnButton()
do
local obj = miscellaneous:newText()
obj:setText(' :folder: miscellaneous')
obj:setSize(2, 2)
obj:setMargin(4)
end
miscellaneous:newSlider():setText(' :ping4: Set Max PF Function Iterations'):setColor(1, 1, 1):setMax(1000.00000001):setValue(GBPFiterations):setStep(1, 1):allowWarping(true):onScroll(function(value, self) pings.setGBPFIterations(value) end)
miscellaneous:newReturnButton()

--[[ai:setTheme({
  render = function(model, time, _, pageZoom)
     local pos = client:getScaledWindowSize() * vec(0.5, 0)
     time = (1 - time) ^ 3
     pos.y = 64 - (1 - time) * 32
     model:setPos(-pos.xy_)
     local scale = 1 + pageZoom * 0.2
     model:setScale(scale * (1 - time * vec(0.5, 1, 1)))
  end,
  renderElements = function(elements, updateElement, selected)
     local currentHeight = 0
     local offset = math.floor(#elements / 8) * 32
     for i, v in pairs(elements) do
        local height = updateElement(i, v)
        v.renderData.pos = vec(offset - v.pos.x, currentHeight - v.pos.y)
        currentHeight = currentHeight - height
        if i % 8 == 0 then
           offset = offset - 64
           currentHeight = 0
        end
     end
  end,
})]]
ai:newText():setText({text = ' :ping4: Set AI To Follow Player'}):onPress(function(self) pings.AIFollow() end)
ai:newText():setText({text = ' :ping4: Set AI To Enemy Melee'}):onPress(function(self) pings.AIMelee() end)
ai:newText():setText({text = ' :ping4: Set AI To Team 1'}):onPress(function(self) pings.AIMeleeTeam1() end)
ai:newText():setText({text = ' :ping4: Set AI To Team 2'}):onPress(function(self) pings.AIMeleeTeam2() end)
ai:newReturnButton()


Projectiles:newText():setText({text = ' :gun: Shoot:Arrow'}):onPress(function(self) pings.createProjectile(models.arrow,true,player:getPos()) end)
Projectiles:newReturnButton()
end