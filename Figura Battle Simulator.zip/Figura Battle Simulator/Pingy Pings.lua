
modelToUse = models.zombie 
function pings.SpawnAmount(value)
SpawnAmount = value
end

function pings.SpawnAtPlayer()
  for i = 1,SpawnAmount do
    local entity = CreateEntity(modelToUse,player:getPos() + vec((math.random()-0.5)*0.2,0,(math.random()-0.5))*0.2,vec(0.47,0.47),0.5,currentAnims)
    table.insert(Entities,entity)
    Amount = Amount + 1
  end
  log("Entity count:", Amount)
end


function pings.SpawnLook()
  local eyePos = player:getPos() + vec(0, player:getEyeHeight(), 0)
local eyeEnd = eyePos + (player:getLookDir() * 20)
local block, hitPos, side = raycast:block(eyePos, eyeEnd)
for i =1 ,SpawnAmount do
  local entity = CreateEntity(modelToUse,hitPos + vec((math.random()-0.5)*0.2,0,(math.random()-0.5))*0.2,vec(0.47,0.47),0.5,currentAnims)
  table.insert(Entities,entity)
  Amount = Amount + 1
end
log("Entity count:", Amount)
end

function pings.DeleteAll()
  for i, entity in pairs(Entities) do
    entity.copy:remove()
    for j, thing in pairs(entity) do
      thing = nil
    end
    entity = nil
Entities[i]=nil
    Amount = Amount - 1
  end
end

function pings.DeleteLook()
  local AABBtable = {}
 
    for i, entity in pairs(Entities) do
    local tempvec = vec(entity.collisionoffset.x,0,entity.collisionoffset.y)+entity.currentPos
    local tempvec2 = vec(-entity.collisionoffset.x,2,-entity.collisionoffset.y)+entity.currentPos
    table.insert(AABBtable,{tempvec,tempvec2})
  end
  local eyePos = player:getPos() + vec(0, player:getEyeHeight(), 0)
  local eyeEnd = eyePos + (player:getLookDir() * 40)
  local aabb, hitPos, side, aabbHitIndex = raycast:aabb(eyePos, eyeEnd, AABBtable)
  if aabbHitIndex ~= nil and Entities[aabbHitIndex] ~= nil then
    Entities[aabbHitIndex].copy:remove()
    for j, thing in pairs(Entities[aabbHitIndex]) do
      thing = nil
    end
table.remove(Entities,aabbHitIndex)
    Amount = Amount - 1
  end
end

function pings.setGravity(value)
  entityGravity = -value
end
function pings.setMaxYVelocity(value)
  MaxYVelocity = value
end
function pings.setFriction(value)
  Friction = value
end
function pings.setAirFriction(value)
  AirFriction = value
end
function pings.setAcceleration(value)
  Acceleration = value
end
function pings.setMaxVelocity(value)
  MaxVelocity = value
end
function pings.setBuoyancy(value)
 Buoyancy = value
end
function pings.setJumpStrength(value)
  JumpStrenth = value
end
function pings.AIFollow()
AI = "Follow Player"
Team = 0
end
function pings.AIMelee()
  AI = "Enemy Melee"
Team = 0
end

function pings.AIMeleeTeamZombie()
  AI = "Melee Team"
  modelToUse = models.zombie
  currentAnims = {walk = "walk", idle = "idle", hit = "hit"}
  Health = 20
Damage = 5
Friction = 1.2
Acceleration = 1
MaxVelocity = 15
JumpStrenth =0.48
AirFriction = 1.6
Buoyancy = 1.8
end
function pings.AIMeleeTeamSkeleton()
  AI = "Melee Team"
  modelToUse = models.skeleton
  currentAnims = {walk = "walkskel", idle = "idleskel", hit = "hitskel"}
  Health = 12
Damage = 6
Friction = 1.2
Acceleration = 1.75
MaxVelocity = 15
JumpStrenth =0.48
AirFriction = 1.6
Buoyancy = 1.8
end
function pings.AIRangedTeamSkeleton()
  AI = "Ranged Team"
  modelToUse = models.skeletonranged
  currentAnims = {walk = "walkskelranged", idle = "idleskelranged", hit = "hitskelranged"}
  Health = 12
Damage = 6
Friction = 1.2
Acceleration = 0.8
MaxVelocity = 15
JumpStrenth =0.48
AirFriction = 1.6
Buoyancy = 1.8
Range = 15
ProjectileModel = models.arrow
ProjectileVelocity = 3.5
end
function pings.setGBPFIterations(value)
    GBPFiterations = value
end
function pings.setTeam(value)
  Team = value
end

function pings.createProjectile()
CreateProjectile(models.arrow,player:getPos():add(0,1.6,0),(player:getLookDir():normalize()*3),4,1.6,100,0)
end  
function pings.BattleEnd()
Battle = false
end
function pings.BattleStart()
Battle = true
end