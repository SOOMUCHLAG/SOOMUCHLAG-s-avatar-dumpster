function VectorToAngles(dir)
  dir:normalize()
  local yaw = math.deg(math.atan(dir.z, dir.x)) -- Yaw: rotation around y-axis
  local pitch = math.deg(math.asin(-dir.y))   -- Pitch: rotation around x-axis
  -- Roll is typically not needed for this example, assuming projectiles align with direction of travel.
  return yaw, pitch
end

  

local copyStorage2 = models:newPart("copyStorage2", "WORLD")
Projectiles = {}
function CreateProjectile(model,pos,velocity,dmg,gravity,lifetime,team)
  local copy = model:copy(model:getName())
  copyStorage2:addChild(copy)
  copy:setVisible(true)
  copy:setPos(pos*16)
  copy:setPrimaryRenderType("TRANSLUCENT_CULL")

  table.insert(Projectiles,{
    currentPos = pos,
    previousPos = pos,
    velocity = velocity,
    copy = copy,
    dmg = dmg,
    lifetime = lifetime or 40,
    gravity = gravity or 1.6,
    currentrotation = vec(0,0,0),
    previousrotation = vec(0,0,0),
    team = team
      })
end


function ItarateProjectile(projectile, index,aabbTable)
projectile.previousPos = projectile.currentPos
projectile.lifetime = projectile.lifetime - 1
projectile.velocity:sub(0,projectile.gravity*0.05,0)
projectile.previousrotation = projectile.currentrotation
local xRot, yRot = VectorToAngles(vec(projectile.velocity.x,projectile.velocity.y,projectile.velocity.z))
projectile.currentrotation = vec(270-yRot, -xRot, 0)


projectile.currentPos = projectile.currentPos+projectile.velocity
local startPos = projectile.currentPos
local endPos = projectile.previousPos
local aabb, hitPos, side, aabbHitIndex = raycast:aabb(startPos, endPos, aabbTable)
if aabbHitIndex ~= nil and Entities[aabbHitIndex].team ~= projectile.team then
local  entity = Entities[aabbHitIndex]
  if entity.Iframes <= 0 then
    entity.Iframes = Iframes
    entity.Redness = Iframes

  entity.velocity.y = 0.3
entity.velocity = entity.velocity+projectile.velocity:normalize().x_z 
entity.health = entity.health - projectile.dmg
end
end

  
if projectile ~= nil and projectile.lifetime <= 0 or world.getBlockState(projectile.currentPos):hasCollision() or (aabbHitIndex ~= nil and projectile.team ~= Entities[aabbHitIndex].team) then
  projectile.copy:remove()
  for i, thing in pairs(projectile) do
    thing = nil
  end

  projectile = nil
  table.remove(Projectiles,index)
end  

end