--I swear if someone tells me that I am stupid for not using the "self" or "example:examplefunction" well... I [REDACTED] KNOW AND I DO NOT CARE I USED WHAT I USED SO WHAT
--MADE BY SOOMUCHLAG

---@param entity table
---@return entity table
---Applies gravity
local function entityGravityFunc(entity)
  entity.velocity = entity.velocity + vec(0,entityGravity*0.05,0)
  if entity.velocity.y <-MaxYVelocity then 
  entity.velocity.y = 15
  end 
return entity
end  


---@param entity table
---@param entity Maxdistance
---@return entity table
---Calls the pathfinding function if the player is Maxdistance blocks from the entity

local function entityPathfindToPlayer(entity,MaxDistance)
  if entity.aiclock >=17 and math.sqrt(math.abs(player:getPos().y - entity.currentPos.y)^2 + math.sqrt( (math.abs(player:getPos().x - entity.currentPos.x)^2 + math.abs(player:getPos().z - entity.currentPos.z)^2)^2 )) > MaxDistance then


    if (world.getBlockState(entity.currentPos+vec(0,-0.5,0)):hasCollision() or world.getBlockState(entity.currentPos+vec(0,-1.5,0)):hasCollision() or #world.getBlockState(entity.currentPos+vec(0,-0.5,0)):getFluidTags() ~= 0) and (world.getBlockState(player:getPos():sub(0,0.9999,0)):getFluidTags() ~= 0 or world.getBlockState(player:getPos():sub(0,0.9999,0)):hasCollision()) and not world.getBlockState(entity.currentPos):hasCollision() then
  entity.aiclock = 0
  ResetGBPathfinding()
  
    end
  for i = 0, GBPFiterations do 
    if #GBPath == 0 and (world.getBlockState(entity.currentPos+vec(0,-0.5,0)):hasCollision() or world.getBlockState(entity.currentPos+vec(0,-1.5,0)):hasCollision() or #world.getBlockState(entity.currentPos+vec(0,-0.5,0)):getFluidTags() ~= 0) and (#world.getBlockState(player:getPos():sub(0,0,0)):getFluidTags() ~= 0 or world.getBlockState(player:getPos():sub(0,0.9999,0)):hasCollision()) and not world.getBlockState(entity.currentPos):hasCollision() then
  
    entity.path = GBPathfind(player:getPos(),entity.currentPos)
    entity.nextpathnode = 1
    else
  
  
      break
  end
  end
  end
  return entity
end
local function entityGetClosestEntity(entity)
  local distance = {}

  for j, SecondEntity in pairs(Entities) do

    if SecondEntity.team ~= entity.team then
    table.insert(distance,{math.sqrt(math.abs(SecondEntity.currentPos.y - entity.currentPos.y)^2 + math.sqrt( (math.abs(SecondEntity.currentPos.x - entity.currentPos.x)^2 + math.abs(SecondEntity.currentPos.z - entity.currentPos.z)^2)^2 )),SecondEntity.currentPos})
    end
  end
  local lowestDistance = nil
  if distance ~= {} then
  for k, dist in pairs(distance) do
    if lowestDistance == nil then
      lowestDistance = dist
    end 
    if lowestDistance[1] > dist[1] then
      lowestDistance = dist
    end
  end
  end
  if lowestDistance ~= nil then
  return entity,lowestDistance[2]
  end
  return entity
end
local function entityPathfindToPoint(entity,MaxDistance,lowestDistance)


  if entity.aiclock >=17 and math.sqrt(math.abs(lowestDistance.y - entity.currentPos.y)^2 + math.sqrt( (math.abs(lowestDistance.x - entity.currentPos.x)^2 + math.abs(lowestDistance.z - entity.currentPos.z)^2)^2 )) > MaxDistance then


    if (world.getBlockState(entity.currentPos+vec(0,-0.5,0)):hasCollision() or world.getBlockState(entity.currentPos+vec(0,-1.5,0)):hasCollision() or #world.getBlockState(entity.currentPos+vec(0,-0.5,0)):getFluidTags() ~= 0) and (world.getBlockState(lowestDistance-vec(0,0.9999,0)):getFluidTags() ~= 0 or world.getBlockState(lowestDistance-vec(0,0.9999,0)):hasCollision()) and not world.getBlockState(entity.currentPos):hasCollision() then
  entity.aiclock = 0
  ResetGBPathfinding()
  
    end
  for i = 0, GBPFiterations do 
    if #GBPath == 0 and (world.getBlockState(entity.currentPos+vec(0,-0.5,0)):hasCollision() or world.getBlockState(entity.currentPos+vec(0,-1.5,0)):hasCollision() or #world.getBlockState(entity.currentPos+vec(0,-0.5,0)):getFluidTags() ~= 0) and (#world.getBlockState(lowestDistance-vec(0,0,0)):getFluidTags() ~= 0 or world.getBlockState(lowestDistance-vec(0,0.9999,0)):hasCollision()) and not world.getBlockState(entity.currentPos):hasCollision() then
  
    entity.path = GBPathfind(lowestDistance,entity.currentPos)
    entity.nextpathnode = 1
    else
  
  
      break
  end
  end
end
  return entity
end



---@param entity table
---@return entity table, isWalking boolean, velocityToRotateTo vector
---Changes the next note in the path to move to and adds velocity in the direction of the next node of the path
local function entityMovement(entity)
  local isWalking = false
  local velocityToRotateTo = nil
  if entity.path ~= nil and entity.nextpathnode <= #entity.path then
    entity.curNode = entity.path[entity.nextpathnode]
  end
  if entity.path ~= nil and entity.nextpathnode <= #entity.path and entity.curNode ~= nil then
    if math.abs(entity.currentPos.x-entity.curNode.x) <= 0.65 and math.abs(entity.currentPos.y-entity.curNode.y) <= 1.3 and math.abs(entity.currentPos.z-entity.curNode.z) <= 0.65 then
      entity.nextpathnode = entity.nextpathnode + 2
      if entity.nextpathnode <= #entity.path then
      entity.curNode = entity.path[entity.nextpathnode]
      end
    end
velocityToRotateTo = (vec(-entity.currentPos.x,0,-entity.currentPos.z)+vec(entity.curNode.x+0.5,0,entity.curNode.z+0.5)):normalize()*0.05*entity.Acceleration
    entity.velocity = entity.velocity + (vec(-entity.currentPos.x,0,-entity.currentPos.z)+vec(entity.curNode.x+0.5,0,entity.curNode.z+0.5)):normalize()*0.05*entity.Acceleration
isWalking = true
  
  end  
  if entity.velocity.x > entity.MaxVelocity then
    entity.velocity.x = entity.MaxVelocity
  end
  if entity.velocity.z > entity.MaxVelocity then
    entity.velocity.z = entity.MaxVelocity
  end
  return entity, isWalking, velocityToRotateTo
end

---@param entity table
---@return entity table
---Rotates the entity according to its velocity and the velocity added this tick
local function entityRotate(entity)
  entity.previousrotation = entity.currentrotation
if math.abs(entity.velocity.x ) >= 0.005 or math.abs(entity.velocity.z ) >= 0.005 and velocityToRotateTo == nil then
  entity.currentrotation =  rotateEntityAccordingToVelocity((entity.velocity))
end
if velocityToRotateTo ~= nil then
  entity.currentrotation =  rotateEntityAccordingToVelocity(((velocityToRotateTo+entity.velocity):normalize()))
end
return entity
end

---@param entity table
---@return entity table, isInWater boolean
---Adds upwards velocity to the entity when in water and changes the isInWater flag to true
local function entityWater(entity)
  local isInWater = false
  if #world.getBlockState(entity.currentPos):getFluidTags() ~= 0 then 
    isInWater = true
    entity.velocity.y = entity.velocity.y/1.04
    entity.velocity:add(0,entity.Buoyancy*0.05+((math.random()+0.1)*0.05)*0.05,0)
    end  
    return entity, isInWater
end

---@param entity table
---@param isWalking boolean
---@return entity table
---Plays idle and walking animations
local function entityWalkAnim(entity,isWalking)
  if isWalking == true then
    entity.anims.idle:stop()
    entity.anims.idle:clean()
  entity.anims.walk:play()
  else
    entity.anims.walk:stop()
    entity.anims.walk:clean()
    entity.anims.idle:play()
  end  
  return entity
end

local function entityHealthCheck(entity,index)
  if entity.health <= 0 then
    entity.copy:remove()
  
  for i, thing in pairs(entity) do
    thing = nil
  end
  
  entity = nil
  table.remove(Entities,index)
  Amount = Amount - 1
  end  
  return entity
end 
---@param entity table
---@return entity table
---Check for the collisions with other nearby entities
local function entityCollision(entity)
  for i, SecondEntity in pairs(Entities) do
    if math.sqrt((entity.currentPos.x - SecondEntity.currentPos.x)^2 + (entity.currentPos.z- SecondEntity.currentPos.z)^2) < entity.entitytoentitycolloff then
      local temp = (entity.currentPos - SecondEntity.currentPos)*0.05
      entity.velocity = entity.velocity + temp.x_z
    end 
  end
  return entity
end

---@param entity table
---@param temppos vector
---@return entity table
---Does raycast collision for the entity
local function entityRaycastCollision(entity,temppos)
  local block, hitPos1, side = raycast:block(vec(temppos.x,temppos.y,temppos.z), vec(temppos.x ,entity.currentPos.y,temppos.z))
if hitPos1.y ~= entity.currentPos.y then
entity.currentPos.y = hitPos1.y-0.5
temppos.y = hitPos1.y+0.1
end
local block, hitPos2, side = raycast:block(vec(temppos.x,temppos.y,temppos.z), vec(entity.currentPos.x,temppos.y,temppos.z))

if hitPos2.x ~= entity.currentPos.x then
entity.currentPos.x = hitPos2.x- math.sign(entity.currentPos.x - entity.previousPos.x)*entity.collisionoffset.x
temppos.x = hitPos2.x

end
local block, hitPos3, side = raycast:block(vec(temppos.x ,temppos.y,temppos.z), vec(temppos.x ,temppos.y,entity.currentPos.z))
if hitPos3.z ~= entity.currentPos.z then
entity.currentPos.z = hitPos3.z- math.sign(entity.currentPos.z - entity.previousPos.z)*entity.collisionoffset.y
temppos.z = hitPos3.z
end
return entity
end
---@param entity table
---@return entity table, isColliding boolean
---Does Y collision
local function entityYCollision(entity)
  local isColliding = false
  if world.getBlockState(entity.currentPos+vec(entity.collisionoffset.x-0.1,-0.01,entity.collisionoffset.y-0.1)):hasCollision() then
    entity.velocity.y = 0
    entity.velocity = entity.velocity/entity.Friction
    entity.currentPos.y = math.ceil(entity.currentPos.y-0.0003)
    isColliding = true
  end
  if world.getBlockState(entity.currentPos+vec(-entity.collisionoffset.x+0.1,-0.0001,entity.collisionoffset.y-0.1)):hasCollision() then
    entity.velocity.y = 0
    entity.velocity = entity.velocity/entity.Friction
   
    entity.currentPos.y = math.ceil(entity.currentPos.y-0.0003)
    isColliding = true
  end
  if world.getBlockState(entity.currentPos+vec(entity.collisionoffset.x-0.1,-0.0001,-entity.collisionoffset.y+0.1)):hasCollision() then
    entity.velocity.y = 0
    entity.velocity = entity.velocity/entity.Friction
    
    entity.currentPos.y = math.ceil(entity.currentPos.y-0.0003)
    isColliding = true
  end
  if world.getBlockState(entity.currentPos+vec(-entity.collisionoffset.x+0.1,-0.0001,-entity.collisionoffset.y+0.1)):hasCollision() then
    entity.velocity.y = 0
    entity.velocity = entity.velocity/entity.Friction
    
  
  entity.currentPos.y = math.ceil(entity.currentPos.y-0.0003)
  
    isColliding = true
  end
  return entity,isColliding
end
---@param entity table
---@return entity table
---Does X and Z collision
local function entityXZcollision(entity)
  if world.getBlockState(vec(entity.currentPos.x,entity.currentPos.y ,entity.currentPos.z - entity.collisionoffset.y - 0.1 )):hasCollision() == true or world.getBlockState(vec(entity.currentPos.x,entity.currentPos.y ,entity.currentPos.z + entity.collisionoffset.y + 0.1)):hasCollision() == true then
    --z collision
    if world.getBlockState(vec(entity.currentPos.x + entity.collisionoffset.x,entity.currentPos.y ,entity.currentPos.z - entity.collisionoffset.y)):hasCollision() == true then
      entity.velocity = vec(entity.velocity.x,entity.velocity.y,0)
      entity.currentPos = vec(entity.currentPos.x, (entity.currentPos.y) , math.ceil(entity.currentPos.z)-entity.collisionoffset.y+0)
    end
    if world.getBlockState(vec(entity.currentPos.x - entity.collisionoffset.x,entity.currentPos.y ,entity.currentPos.z - entity.collisionoffset.y)):hasCollision() == true then
      entity.velocity = vec(entity.velocity.x,entity.velocity.y,0)
      entity.currentPos = vec(entity.currentPos.x, (entity.currentPos.y) , math.ceil(entity.currentPos.z)-entity.collisionoffset.y+0)
    end
    if world.getBlockState(vec(entity.currentPos.x + entity.collisionoffset.x,entity.currentPos.y ,entity.currentPos.z + entity.collisionoffset.y)):hasCollision() == true then
      entity.velocity = vec(entity.velocity.x,entity.velocity.y,0)
      entity.currentPos = vec(entity.currentPos.x, (entity.currentPos.y) , math.floor(entity.currentPos.z)+entity.collisionoffset.y+0)
    end
    if world.getBlockState(vec(entity.currentPos.x - entity.collisionoffset.x,entity.currentPos.y ,entity.currentPos.z + entity.collisionoffset.y)):hasCollision() == true then
      entity.velocity = vec(entity.velocity.x,entity.velocity.y,0)
      entity.currentPos = vec(entity.currentPos.x, (entity.currentPos.y) , math.floor(entity.currentPos.z)+entity.collisionoffset.y+0)
    end
    end
    --x collision
    if world.getBlockState(vec(entity.currentPos.x- entity.collisionoffset.x - 0.1 ,entity.currentPos.y ,entity.currentPos.z )):hasCollision() == true or world.getBlockState(vec(entity.currentPos.x + entity.collisionoffset.x + 0.1,entity.currentPos.y ,entity.currentPos.z)):hasCollision() == true then
    if world.getBlockState(vec(entity.currentPos.x - entity.collisionoffset.x ,entity.currentPos.y ,entity.currentPos.z + entity.collisionoffset.y)):hasCollision() == true then
      entity.velocity = vec(0,entity.velocity.y,entity.velocity.z)
      entity.currentPos = vec(math.ceil(entity.currentPos.x)-entity.collisionoffset.x-0, (entity.currentPos.y) , entity.currentPos.z)
    end
    if world.getBlockState(vec(entity.currentPos.x - entity.collisionoffset.x,entity.currentPos.y ,entity.currentPos.z - entity.collisionoffset.y)):hasCollision() == true then
      entity.velocity = vec(0,entity.velocity.y,entity.velocity.z)
      entity.currentPos = vec(math.ceil(entity.currentPos.x)-entity.collisionoffset.x-0, (entity.currentPos.y) , entity.currentPos.z)
    end
    if world.getBlockState(vec(entity.currentPos.x + entity.collisionoffset.x,entity.currentPos.y ,entity.currentPos.z + entity.collisionoffset.y)):hasCollision() == true then
      entity.velocity = vec(0,entity.velocity.y,entity.velocity.z)
      entity.currentPos = vec(math.floor(entity.currentPos.x)+entity.collisionoffset.x-0, (entity.currentPos.y) , entity.currentPos.z)
    end
    if world.getBlockState(vec(entity.currentPos.x + entity.collisionoffset.x,entity.currentPos.y ,entity.currentPos.z - entity.collisionoffset.y)):hasCollision() == true then
      entity.velocity = vec(0,entity.velocity.y,entity.velocity.z)
      entity.currentPos = vec(math.floor(entity.currentPos.x)+entity.collisionoffset.x-0, (entity.currentPos.y) , entity.currentPos.z)
    end
    end
    return entity
  end

---@param entity table
---@return entity table
---Makes an entity jump
local function entityJump(entity,isColliding)
  if  entity.curNode ~= nil and -entity.currentPos.y + entity.curNode.y >= 1 and isColliding == true then
    entity.velocity.y = entity.velocity.y+entity.JumpStrenth
  end
  return entity
end

---@param entity table
---@param isColliding boolean
---@return entity table
---Applies air resistance(friction) to an entity
local function entityAirFriction(entity,isColliding)
  if isColliding == false then
    entity.velocity.x = entity.velocity.x/entity.AirFriction
    entity.velocity.z = entity.velocity.z/entity.AirFriction
  end
  return entity
end

---@param entity table
---@return entity table
---Sets the redness of an entity after it was hit
local function entityRedness(entity)
  if entity.Redness >= 0 then
    entity.copy:setColor(1,1/(entity.Redness/2),1/(entity.Redness/2))
 
  else 
    if entity.team == 0 then 
      entity.copy:setColor(1,0.4,0.4)
    end
    if entity.team == 1 then 
      entity.copy:setColor(0.4,0.4,1)
    end
    if entity.team == 2 then 
      entity.copy:setColor(0.4,1,0.4)
    end
    if entity.team == 3 then 
      entity.copy:setColor(1,1,1)
    end
    end
    return entity  
end

---@param entity table
---@return entity table
---Deals damage to a player when the entity is close enough
local function entityHit(entity)
  
  if entity.hitclock >= 40 and math.sqrt(math.abs(player:getPos().y - entity.currentPos.y)^2 + math.sqrt( (math.abs(player:getPos().x - entity.currentPos.x)^2 + math.abs(player:getPos().z - entity.currentPos.z)^2)^2 )) <= 1.3 then
    entity.hitclock = 0
  --host:sendChatCommand("/summon creeper ~ ~ ~ {Fuse:0,ExplosionRadius:20}") -- trampoline!
  entity.anims.hit:play()
  host:sendChatCommand("/damage @p 4.5")

    end
    return entity
end

local function entityHitEntity(entity,pos)
  local SecondEntity = nil
  for i, entity2 in pairs(Entities) do
    if entity2.currentPos == pos then
      if entity.hitclock >= 40 and math.sqrt(math.abs(pos.y - entity.currentPos.y)^2 + math.sqrt( (math.abs(pos.x - entity.currentPos.x)^2 + math.abs(pos.z - entity.currentPos.z)^2)^2 )) <= 1.6 then
        entity.hitclock = 0
        entity2.velocity.y = 0
        entity2.velocity = entity2.velocity-(entity.currentPos-pos):normalize().x_z*0.6+vec(0,0.35,0)
        entity2.Iframes = Iframes
        entity2.Redness = Iframes
        entity2.health = entity2.health - entity.damage
        entity.anims.hit:play() 
      end
    end
  end

    return entity
end


local function entityShoot(entity, closestEntityPos,block)
  if entity.Iframes<=0 then
  entity.currentrotation = rotateEntityAccordingToVelocity(closestEntityPos-entity.currentPos)
  end
if block.id == "minecraft:air" and entity.hitclock >= 40 then
entity.hitclock = 0
entity.anims.hit:play() 
CreateProjectile(entity.projectilemodel,entity.currentPos+vec(0,1.6,0),-(entity.currentPos-closestEntityPos):normalize()*entity.projectilevelocity+vec(0,0.2,0),4,1.6,60,entity.team)
end 
  return entity
end
---Iterates the AI
function IterateAi(entity,index)
  if Battle == true or TempBattle == true then
    TempBattle = false
  if entity.ai == "Follow Player" then
    local blockLight = world.getBlockLightLevel(entity.currentPos+vec(0,.2,0))
    local skyLight = world.getSkyLightLevel(entity.currentPos+vec(0,.2,0))
    entity.copy:setLight(blockLight,skyLight)
    entity.previousPos = entity.currentPos
    entity.aiclock = entity.aiclock + 1
entity = entityGravityFunc(entity)
entity = entityPathfindToPlayer(entity,4)
  local isWalking = nil
  local isInWater = nil
  local velocityToRotateTo = nil
entity, isWalking, velocityToRotateTo = entityMovement(entity)

entity = entityRotate(entity,velocityToRotateTo)
entity, isInWater = entityWater(entity)
entity = entityWalkAnim(entity,isWalking)
entity = entityCollision(entity)
entity.currentPos = entity.currentPos + entity.velocity
  local isColliding = false
  local temppos = vec(entity.previousPos.x,entity.previousPos.y,entity.previousPos.z)
entity = entityRaycastCollision(entity,temppos)
entity, isColliding = entityYCollision(entity)
entity = entityJump(entity,isColliding)
entity = entityAirFriction(entity,isColliding)
entity = entityXZcollision(entity)
if world.getBlockState(entity.currentPos + vec(0,0.25,0)):hasCollision() then
  entity.currentPos.y = math.ceil(entity.currentPos.y+0.2) 
end
end













if entity.ai == "Enemy Melee" then
entity = entityRedness(entity)
  local blockLight = world.getBlockLightLevel(entity.currentPos+vec(0,.2,0))
  local skyLight = world.getSkyLightLevel(entity.currentPos+vec(0,.2,0))
  entity.copy:setLight(blockLight,skyLight)
entity.Redness = entity.Redness - 1
entity.Iframes = entity.Iframes - 1
entity.aiclock = entity.aiclock + 1
entity.hitclock = entity.hitclock + 1
entity.previousPos = entity.currentPos
entity = entityGravityFunc(entity)
entity = entityPathfindToPoint(entity,0.7)
  local isWalking = nil
  local isInWater = nil
  local velocityToRotateTo = nil
entity,isWalking,velocityToRotateTo = entityMovement(entity)
entity = entityRotate(entity,velocityToRotateTo)
entity ,isInWater = entityWater(entity)
  if entity.hitclock >=10 then
    entity = entityWalkAnim(entity,isWalking)
  end
entity = entityCollision(entity)
  entity.currentPos = entity.currentPos + entity.velocity
  local isColliding = false
  local temppos = vec(entity.previousPos.x,entity.previousPos.y,entity.previousPos.z)
entity = entityRaycastCollision(entity,temppos)
entity,isColliding = entityYCollision(entity)
entity = entityJump(entity,isColliding)
entity = entityAirFriction(entity,isColliding)
entity = entityXZcollision(entity)
entity = entityHit(entity)
  if world.getBlockState(entity.currentPos + vec(0,0.25,0)):hasCollision() then
    entity.currentPos.y = math.ceil(entity.currentPos.y+0.2) 
  end
end






if entity ~= nil and entity.ai == "Melee Team" then
  entity = entityRedness(entity)
  local blockLight = world.getBlockLightLevel(entity.currentPos+vec(0,.2,0))
  local skyLight = world.getSkyLightLevel(entity.currentPos+vec(0,.2,0))
  entity.copy:setLight(blockLight,skyLight)
  entity.previousPos = entity.currentPos
  entity.aiclock = entity.aiclock + 1
  entity.Redness = entity.Redness - 1
entity.Iframes = entity.Iframes - 1
entity.hitclock = entity.hitclock + 1
  entity = entityGravityFunc(entity)
  entity, closestEntityPos = entityGetClosestEntity(entity)
  if closestEntityPos ~= nil then
entity = entityPathfindToPoint(entity,0.6,closestEntityPos)
  end
local isWalking = nil
local isInWater = nil
local velocityToRotateTo = nil
entity, isWalking, velocityToRotateTo = entityMovement(entity)

entity = entityRotate(entity,velocityToRotateTo)
entity, isInWater = entityWater(entity)
entity = entityWalkAnim(entity,isWalking)
entity = entityCollision(entity)
entity.currentPos = entity.currentPos + entity.velocity
local isColliding = false
local temppos = vec(entity.previousPos.x,entity.previousPos.y,entity.previousPos.z)
entity = entityRaycastCollision(entity,temppos)
entity, isColliding = entityYCollision(entity)
entity = entityJump(entity,isColliding)
entity = entityAirFriction(entity,isColliding)
entity = entityXZcollision(entity)
entity = entityHitEntity(entity,closestEntityPos)

if world.getBlockState(entity.currentPos + vec(0,0.25,0)):hasCollision() then
entity.currentPos.y = math.ceil(entity.currentPos.y+0.2) 
end

entity = entityHealthCheck(entity,index)
end

if entity ~= nil and entity.ai == "Ranged Team" then
  entity = entityRedness(entity)
  local blockLight = world.getBlockLightLevel(entity.currentPos+vec(0,.2,0))
  local skyLight = world.getSkyLightLevel(entity.currentPos+vec(0,.2,0))
  entity.copy:setLight(blockLight,skyLight)
  entity.previousPos = entity.currentPos
  entity.aiclock = entity.aiclock + 1
  entity.Redness = entity.Redness - 1
entity.Iframes = entity.Iframes - 1
entity.hitclock = entity.hitclock + 1
  entity = entityGravityFunc(entity)
  entity, closestEntityPos = entityGetClosestEntity(entity)
  local block, hitPos, side
  if closestEntityPos ~= nil then
     block, hitPos, side = raycast:block(entity.currentPos+vec(0,2,0), closestEntityPos+vec(0,2,0))
  end

  if closestEntityPos ~= nil and math.abs((closestEntityPos - entity.currentPos).x) +math.abs((closestEntityPos - entity.currentPos).z) > entity.range or (block ~= nil and block.id ~= "minecraft:air") then
entity = entityPathfindToPoint(entity,0.6,closestEntityPos)
  end
local isWalking = nil
local isInWater = nil
local velocityToRotateTo = nil
if closestEntityPos ~= nil and math.abs((closestEntityPos - entity.currentPos).x) +math.abs((closestEntityPos - entity.currentPos).z) > entity.range or (block ~= nil and block.id ~= "minecraft:air") then
entity, isWalking, velocityToRotateTo = entityMovement(entity)
end
if closestEntityPos ~= nil and math.abs((closestEntityPos - entity.currentPos).x) +math.abs((closestEntityPos - entity.currentPos).z) <= entity.range and (block ~= nil and block.id == "minecraft:air") then
entity = entityShoot(entity,closestEntityPos,block) 
end  
entity = entityRotate(entity,velocityToRotateTo)
entity, isInWater = entityWater(entity)
entity = entityWalkAnim(entity,isWalking)
entity = entityCollision(entity)
entity.currentPos = entity.currentPos + entity.velocity
local isColliding = false
local temppos = vec(entity.previousPos.x,entity.previousPos.y,entity.previousPos.z)
entity = entityRaycastCollision(entity,temppos)
entity, isColliding = entityYCollision(entity)
entity = entityJump(entity,isColliding)
entity = entityAirFriction(entity,isColliding)
entity = entityXZcollision(entity)
entity = entityHitEntity(entity,closestEntityPos)

if world.getBlockState(entity.currentPos + vec(0,0.25,0)):hasCollision() then
entity.currentPos.y = math.ceil(entity.currentPos.y+0.2) 
end

entity = entityHealthCheck(entity,index)
end


end
end


function rotateEntityAccordingToVelocity(velocity)

  dir = vec(velocity.x, velocity.y, velocity.z):normalize()
  

  local yaw, pitch = directionToEulerAngles(dir.x, dir.y, dir.z)

  local yawDeg = math.deg(yaw)
  local pitchDeg = math.deg(pitch)

return yawDeg, pitchDeg
end


function directionToEulerAngles(dirX, dirY, dirZ)
  local yaw = math.atan(dirZ, dirX) 
  local pitch = math.asin(-dirY)   

  return yaw, pitch
end




--[[ 
local block, hitPos1, side = raycast:block(vec(temppos.x+ entity.collisionoffset.x,temppos.y,temppos.z+ entity.collisionoffset.y), vec(temppos.x+ entity.collisionoffset.x ,entity.currentPos.y,temppos.z+entity.collisionoffset.y))
if hitPos1.y ~= entity.currentPos.y then
entity.velocity.y = 0
if highestY<hitPos1.y then
entity.currentPos.y = hitPos1.y + 0.0002
highestY = hitPos1.y
end
isColliding = true
end
local block, hitPos2, side = raycast:block(vec(temppos.x- entity.collisionoffset.x,temppos.y,temppos.z+ entity.collisionoffset.y), vec(temppos.x- entity.collisionoffset.x ,entity.currentPos.y,temppos.z+entity.collisionoffset.y))
if hitPos2.y ~= entity.currentPos.y then
entity.velocity.y = 0
if highestY<hitPos2.y then
  entity.currentPos.y = hitPos2.y + 0.0002
  highestY = hitPos2.y
  end
  isColliding = true
end
  local block, hitPos3, side = raycast:block(vec(temppos.x- entity.collisionoffset.x,temppos.y,temppos.z- entity.collisionoffset.y), vec(temppos.x- entity.collisionoffset.x ,entity.currentPos.y,temppos.z-entity.collisionoffset.y))
  if hitPos3.y ~= entity.currentPos.y then
  entity.velocity.y = 0
  if highestY<hitPos3.y then
    entity.currentPos.y = hitPos3.y + 0.0002
    highestY = hitPos3.y
    end
    isColliding = true
  end
    local block, hitPos4, side = raycast:block(vec(temppos.x+ entity.collisionoffset.x,temppos.y,temppos.z- entity.collisionoffset.y), vec(temppos.x+ entity.collisionoffset.x ,entity.currentPos.y,temppos.z-entity.collisionoffset.y))
if hitPos4.y ~= entity.currentPos.y then
entity.velocity.y = 0
if highestY<hitPos4.y then
  entity.currentPos.y = hitPos4.y + 0.0002
  highestY = hitPos4.y
  end
isColliding = true
end
]]