
 
 local particleModel = require('particle_model')
models.skeletonranged:setVisible(false)
models.skeleton:setVisible(false)
models.arrow:setVisible(false)
 local key = keybinds:newKeybind('', 'key.keyboard.z')
 key.press = function()
    particleModel.render(
       models,8,4, function (pos,color)
     if color.a < 0.1 then return end
     local point = player:getPos():add(0,1,0)
     local vel = (pos - point)*0.3+vec(math.random()-0.5,math.random()-0.5,math.random()-0.5)*0.8
       particles['end_rod']
          :pos(pos)
          :lifetime(50)
          :gravity(0)
          :size(0.5)
          :color(color)
          :velocity(vel)
          :spawn()
    end
    )
    models:visible(false)
 end
 
 key.release = function()
    models:visible(true)
 end
 
 -- Auto generated script file --
 local copyStorage = models:newPart("copyStorage", "WORLD")
Anim = require('Anim')
 models.block:setParentType("WORLD")
 Entities = {}
 Copies = {}
 models.zombie:setParentType("WORLD")
 local function deepCopy(model)
  local copy = model:copy(model:getName())
  for _, child in pairs(copy:getChildren()) do
      copy:removeChild(child):addChild(deepCopy(child))
  end
  
  return copy
end
 
function events.key_press(key, action, modifier)

if key == 72 and action == 1 then

end
end
 


 
 function events.entity_init()



 end
 
 function events.world_tick()

 
  Hidepath()

   for i, entity in pairs(Entities) do
     IterateAi(entity,i)
   --Showpath(entity)
   end
   local AABBtable = {}
   for i, entity in pairs(Entities) do
     local tempvec = vec(entity.collisionoffset.x,0,entity.collisionoffset.y)+entity.currentPos
     local tempvec2 = vec(-entity.collisionoffset.x,2,-entity.collisionoffset.y)+entity.currentPos
     table.insert(AABBtable,{tempvec,tempvec2})
   end
   for i, projectile in pairs(Projectiles) do
    ItarateProjectile(projectile,i,AABBtable)
   end
 end
 
 
 function events.render(delta, context)
   for i, entity in pairs(Entities) do
 entity.copy:setPos(vec(math.lerp(entity.previousPos.x,entity.currentPos.x,delta),math.lerp(entity.previousPos.y,entity.currentPos.y,delta),math.lerp(entity.previousPos.z,entity.currentPos.z,delta))*16)
 entity.copy:setRot(vec(0,270-math.lerp(entity.previousrotation,entity.currentrotation,delta),0))
end
for i, projectile in pairs(Projectiles) do 
  projectile.copy:setPos(vec(math.lerp(projectile.previousPos.x,projectile.currentPos.x,delta),math.lerp(projectile.previousPos.y,projectile.currentPos.y,delta),math.lerp(projectile.previousPos.z,projectile.currentPos.z,delta))*16)
  projectile.copy:setRot(vec(math.lerp(projectile.previousrotation.y,projectile.currentrotation.y,delta),math.lerp(projectile.previousrotation.x,projectile.currentrotation.x,delta),0))

end
end
 
 
 function CreateEntity(model,pos,colloff,entitycolloff,animations)

    local copy = deepCopy(model)
    copyStorage:addChild(copy)
    copy:setVisible(true)
    copy:setPos(player:getPos()*16)

local walk = nil
local idle = nil
local hit = nil

if type(animations.walk) == "string" then
    walk = Anim.new(copy, animations.walk)
else
  error("Animation name is not a string")
 end
 if type(animations.idle) == "string" then
    idle = Anim.new(copy, animations.idle)
 else
    error("Animation name is not a string")
 end
 if type(animations.hit) == "string" then
  hit = Anim.new(copy, animations.hit)
 else
  error("Animation name is not a string")
end
   local prevpos = pos
   local curpos = pos
   local entity = { 
     copy = copy,
     previousPos = prevpos,
     currentPos = curpos,
     velocity = vec(0,0,0),
     ai = AI,
     path = {}, 
     nextpathnode = 1,
     aiclock = 0,
     hitclock = 20,
     collisionoffset = colloff,
     entitytoentitycolloff = entitycolloff,
     currentrotation = 0,
     previousrotation = 0,
    anims = {walk=walk,idle=idle,hit = hit},
    curNode = nil,
    health = Health,
    Iframes = 0,
    Redness = 0,
    team = Team,
    damage = Damage,
    Friction = Friction,
Acceleration = Acceleration,
MaxVelocity = MaxVelocity,
JumpStrenth = JumpStrenth,
AirFriction = AirFriction,
Buoyancy = Buoyancy,
Projectile = Projectile,
range = Range,
projectilemodel = ProjectileModel,
projectilevelocity = ProjectileVelocity
   }
   if entity.team == 0 then 
    entity.copy:setColor(1,0.4,0.4)
  end
  if entity.team == 1 then 
    entity.copy:setColor(0.4,0.4,1)
  end
  if entity.team == 2 then 
    entity.copy:setColor(0.4,1,0.4)
  end
  if entity.team == 3 then 
    entity.copy:setColor(1,1,1)
  end
   return entity
 end


function Showpath(entity)
  if entity.path ~= nil then
  for i, value in pairs(entity.path) do
if i%2 == 0 then
    local copy = models.block.bone:copy("block")
    models.block.bone2:addChild(copy)
    copy:setVisible(true)
    copy:setColor(0,1,0)
    copy:setPos(((value.x+0.5)*16),((value.y+0.5)*16),((value.z+0.5)*16))
    table.insert(Copies, copy)
end
  end
end
end
function Hidepath()
  if Copies ~= {} then
    for k ,copy in pairs(Copies) do
    copy:getParent():removeChild(copy)
    end
    Copies = {}

  end
end



