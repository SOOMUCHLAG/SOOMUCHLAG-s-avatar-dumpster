VisitedNodes = {}
PrevVisitedNodes ={}
ActiveNodes = {}
PrevActiveNodes = {}
Heuristics = {}
SortedHeuristics = {}
Path = {}
NumberOfExecutions = 0
function ResetPathfinding()
  VisitedNodes = {}
  PrevVisitedNodes ={}
  ActiveNodes = {}
  PrevActiveNodes = {}
  Heuristics = {}
  SortedHeuristics = {}
  Path = {}
  NumberOfExecutions = 0
end  

--Runs 1 iteration of the Pathfinding algorithm
function Pathfind(tempstart,tempdest)
  
  NumberOfExecutions = NumberOfExecutions + 1
  local start = vec(math.floor(tempstart.x),math.floor(tempstart.y),math.floor(tempstart.z))
  local dest = vec(math.floor(tempdest.x),math.floor(tempdest.y),math.floor(tempdest.z))
  --If this is the first iteration add the first node
  if #VisitedNodes == 0 then 
    NodeToExpand = start
    table.insert(VisitedNodes,NodeToExpand)
    table.insert(PrevVisitedNodes,NodeToExpand)
  end  




  AddNearbyNodes(NodeToExpand,dest)

  table.sort(SortedHeuristics)
  for i, Heuristic in pairs(Heuristics) do
    if Heuristic == SortedHeuristics[1] then

      table.insert(VisitedNodes, ActiveNodes[i])
      table.insert(PrevVisitedNodes, PrevActiveNodes[i])

      if NodeToExpand == dest then

        TracePath(PrevActiveNodes[i])
        return Path
              end  
      NodeToExpand = ActiveNodes[i]

      table.remove(ActiveNodes, i)
      table.remove(PrevActiveNodes, i)
      table.remove(Heuristics, i)
      table.remove(SortedHeuristics, 1)
      break
    end  
  end

end  



--Adds 6 nodes nearest to the given node(+- 1 in x,y,z direction)
function AddNearbyNodes(Node,dest)


  -- +x
  local NodeAlreadyExists = false
  if world.getBlockState(Node.x + 1, Node.y, Node.z):hasCollision() == false then
    for i, node in pairs(VisitedNodes) do 

      if node == vec(Node.x + 1, Node.y, Node.z) then

        NodeAlreadyExists = true
      break
      end   
    end 

    for i, node in pairs(ActiveNodes) do 
      if node == vec(Node.x + 1, Node.y, Node.z) then
      NodeAlreadyExists = true
      break
      end   
    end 

    if NodeAlreadyExists == false then
      table.insert(ActiveNodes, vec(Node.x + 1, Node.y, Node.z))
      table.insert(PrevActiveNodes, Node)
      table.insert(Heuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x + 1 - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
      table.insert(SortedHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x + 1 - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
    end

  end


  -- -x
  local NodeAlreadyExists = false
  if world.getBlockState(Node.x - 1, Node.y, Node.z):hasCollision() == false then
    for i, node in pairs(VisitedNodes) do 
      if node == vec(Node.x - 1, Node.y, Node.z) then
        NodeAlreadyExists = true

      break
      end   
    end 

    for i, node in pairs(ActiveNodes) do 
      if node == vec(Node.x - 1, Node.y, Node.z) then
      NodeAlreadyExists = true

      break
      end   
    end 

    if NodeAlreadyExists == false then
      table.insert(ActiveNodes, vec(Node.x - 1, Node.y, Node.z))
      table.insert(PrevActiveNodes, Node)
      table.insert(Heuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - 1 - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
      table.insert(SortedHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - 1 - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
    end

  end

  -- +y
  local NodeAlreadyExists = false
  if world.getBlockState(Node.x, Node.y + 1, Node.z):hasCollision() == false then
    for i, node in pairs(VisitedNodes) do 
      if node == vec(Node.x, Node.y + 1, Node.z) then
        NodeAlreadyExists = true

      break
      end   
    end 

    for i, node in pairs(ActiveNodes) do 
      if node == vec(Node.x, Node.y + 1, Node.z) then
      NodeAlreadyExists = true
      break
      end   
    end 

    if NodeAlreadyExists == false then
      table.insert(ActiveNodes, vec(Node.x, Node.y + 1, Node.z))
      table.insert(PrevActiveNodes, Node)
      table.insert(Heuristics,math.sqrt(math.abs(Node.y + 1 - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
      table.insert(SortedHeuristics,math.sqrt(math.abs(Node.y + 1 - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
    end

  end

    -- -y
    local NodeAlreadyExists = false
    if world.getBlockState(Node.x, Node.y - 1, Node.z):hasCollision() == false then
      for i, node in pairs(VisitedNodes) do 
        if node == vec(Node.x, Node.y - 1, Node.z) then
          NodeAlreadyExists = true

        break
        end   
      end 
  
      for i, node in pairs(ActiveNodes) do 
        if node == vec(Node.x, Node.y - 1, Node.z) then
        NodeAlreadyExists = true
        break
        end   
      end 
  
      if NodeAlreadyExists == false then
        table.insert(ActiveNodes, vec(Node.x, Node.y - 1, Node.z))
        table.insert(PrevActiveNodes, Node)
        table.insert(Heuristics,math.sqrt(math.abs(Node.y - 1 - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
        table.insert(SortedHeuristics,math.sqrt(math.abs(Node.y - 1 - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - dest.z)^2)^2 )))
      end
  
    end


        -- +z
        local NodeAlreadyExists = false
        if world.getBlockState(Node.x, Node.y, Node.z + 1):hasCollision() == false then
          for i, node in pairs(VisitedNodes) do 
            if node == vec(Node.x, Node.y, Node.z + 1) then
              NodeAlreadyExists = true

            break
            end   
          end 
      
          for i, node in pairs(ActiveNodes) do 
            if node == vec(Node.x, Node.y, Node.z + 1) then
            NodeAlreadyExists = true
            break
            end   
          end 
      
          if NodeAlreadyExists == false then
            table.insert(ActiveNodes, vec(Node.x, Node.y, Node.z + 1))
            table.insert(PrevActiveNodes, Node)
            table.insert(Heuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z + 1 - dest.z)^2)^2 )))
            table.insert(SortedHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z + 1 - dest.z)^2)^2 )))
          end
      
        end

                -- -z
        local NodeAlreadyExists = false
        if world.getBlockState(Node.x, Node.y, Node.z - 1):hasCollision() == false then
          for i, node in pairs(VisitedNodes) do 
            if node == vec(Node.x, Node.y, Node.z - 1) then
              NodeAlreadyExists = true
            break
            end   
          end 
      
          for i, node in pairs(ActiveNodes) do 
            if node == vec(Node.x, Node.y, Node.z - 1) then
            NodeAlreadyExists = true
            break
            end   
          end 
      
          if NodeAlreadyExists == false then
            table.insert(ActiveNodes, vec(Node.x, Node.y, Node.z - 1))
            table.insert(PrevActiveNodes, Node)
            table.insert(Heuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - 1 - dest.z)^2)^2 )))
            table.insert(SortedHeuristics,math.sqrt(math.abs(Node.y - dest.y)^2 + math.sqrt( (math.abs(Node.x - dest.x)^2 + math.abs(Node.z - 1 - dest.z)^2)^2 )))
          
      
          end
        end 
end   



--Traces the path that the pathfinding algorithm took
function TracePath(prev)

local prevnode = prev


  for j = 0, NumberOfExecutions do

    for i, node in pairs(VisitedNodes) do 



      if node == prevnode then
     table.insert(Path,node)
     prevnode = PrevVisitedNodes[i]
      break 
      end  

    end  
  end

end  