particles = require("ParticleEngine")
models.model.bone:setParentType("WORLD")
function events.entity_init()
pos = player:getPos():floor():add(0.5,0.6,0.5)
models.model.bone:setPos(player:getPos():floor():add(0.5,0,0.5)*16):setScale(2)
end  
function events.tick()
    particles.createParticle({
      position = pos+vec(0,0.3,0),
      color = vec(1,1,1),
      opacity = 0.9,
      scale = vec(2,2,2)*1.2,
      velocity = player:getLookDir()*00+vec(math.random()-0.5,math.random()-0.5,math.random()-0.5):normalize()*0.5,
      friction = 0.9,
      gravity = vec(0,5,0),
      grid = 8,
      renderType = "NONE",
      texture = "model.fire2",
      lifetime = 20+math.random(0,10)
      }
      )
      for i = 1, 1 do 
      particles.createParticle({
        position = pos+vec(0,0.3,0),
        color = vec(1,1,1),
        opacity = 0.9,
        scale = vec(2,2,2)*1.4,
        velocity = player:getLookDir()*00+vec(math.random()-0.5,math.random()-0.5,math.random()-0.5):normalize()*2,
        friction = 0.85,
        gravity = vec(0,4,0),
        grid = 8,
        renderType = "NONE",
        texture = "model.fire3",
        lifetime = 10+math.random(0,10)
        }
        )
      end
      for i = 1, 1 do
        particles.createParticle({
          position = pos+vec(0,1.7+(math.random()-0.5),0),
          color = vec(1,1,1),
          opacity = 0.9,
          scale = vec(1,1,1)*2.5,
          velocity = player:getLookDir()*00+vec(math.random()-0.5,math.random()-0.5,math.random()-0.5):normalize()*0.6,
          friction = 0.92,
          gravity = vec(0,3.5,0),
          grid = 8,
          renderType = "NONE",
          texture = "model.smoke",
          lifetime = 50+math.random(0,10),
          opacityovt = true
          }
          )
        end
end