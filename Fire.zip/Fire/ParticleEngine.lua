copyStorage = models:newPart("copyStorage", "WORLD")
--[[
particleData template
tbl = {
position = vec3
color = vec3
opacity = 0-1
scale = vec3
parentType = string OPTIONAL default world
velocity = vec3
friction = value
gravity = vec3
grid = value
renderType = string OPTIONAL default emissive_solid
lifetime = value
}
]]
local Functions = {}
local Particles = {}
function VectorToAngles(dir)
  dir:normalize()
    return vec(-math.deg(math.atan2(dir.y, math.sqrt(dir.x * dir.x + dir.z * dir.z))), math.deg(math.atan2(dir.x, dir.z)), 0)
end
local function createParticle(particleData)
local copy = models.model.plane:copy(":skull:")
copyStorage:addChild(copy)
copy:setPos(particleData.position*16)
copy:setColor(particleData.color)
copy:setOpacity(particleData.opacity)
copy:setScale(particleData.scale)
copy:setRot(VectorToAngles(copy:getPos()/16+client:getCameraPos())+vec(90,0,0))
copy:setParentType(particleData.parentType or "WORLD")
copy:setPrimaryTexture("CUSTOM", textures[particleData.texture])
copy:setLight(15)
for i, vertextbl in pairs(copy.plane:getAllVertices()) do
  for i, vertex in pairs(vertextbl) do
  vertex:setNormal(1,1,1)
  end
end
table.insert(Particles,{copy = copy,velocity = particleData.velocity,friction = particleData.friction,gravity = particleData.gravity,position = particleData.position,previousPosition = particleData.position,grid = particleData.grid,lifetime = particleData.lifetime,maxLifetime = particleData.lifetime,scale = particleData.scale,opacityovt = particleData.opacityovt})
end
function events.tick()
  for i, particle in pairs(Particles) do
    particle.previousPosition = particle.position
    particle.position = particle.position+particle.velocity*0.05
    particle.velocity = particle.velocity + particle.gravity*0.05
    particle.velocity = particle.velocity*particle.friction
    particle.lifetime = particle.lifetime - 1
    particle.copy:setScale(particle.lifetime*particle.scale/particle.maxLifetime)
    if particle.opacityovt then
    particle.copy:setOpacity(particle.lifetime/particle.maxLifetime)
    end
    if particle.lifetime <= 0 then
      particle.copy:getParent():removeChild(particle.copy)
      particle.copy:setVisible(false)
      particle.copy:remove()
      particle.copy = nil
      Particles[i] = nil
    end
  end
end
function events.render(delta)
  for i, particle in pairs(Particles) do
  local temp = math.lerp(particle.previousPosition,particle.position,delta)
  particle.copy:setPos(vec(temp.x-0.001,temp.y-0.001,temp.z-0.001)*16)
  particle.copy:setRot(VectorToAngles(-particle.copy:getPos()/16+client:getCameraPos())+vec(90,0,0))
  end
end
Functions.createParticle = createParticle
return Functions