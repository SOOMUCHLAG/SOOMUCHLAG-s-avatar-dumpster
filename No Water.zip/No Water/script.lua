Copies = {}
models.BBB:setParentType("World")
--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()

end

--tick event, called 20 times per second
function events.tick()


end

--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
  if host:isHost() then 
  Dematerialize()
  PlaceBlock(player:getPos(delta)+vec(0,player:getEyeHeight()-3.5,0),7)
  PlaceBlock(player:getPos(delta)+vec(0,player:getEyeHeight()-3,0),6)
  PlaceBlock(player:getPos(delta)+vec(0,player:getEyeHeight()-2,0),4)
  PlaceBlock(player:getPos(delta)+vec(0,player:getEyeHeight()-1,0),2)
  PlaceBlock(player:getPos(delta)+vec(0,player:getEyeHeight()-0.5,0),1)
  PlaceBlock(player:getPos(delta)+vec(0,player:getEyeHeight()-0.25,0),0.5)
  PlaceBlock(player:getPos(delta)+vec(0,player:getEyeHeight()-0.125,0),0.25)
  PlaceBlock(player:getPos(delta)+vec(0,player:getEyeHeight()-0.0625,0),0.125)
  PlaceBlock(player:getPos(delta)+vec(0,player:getEyeHeight()-0.05,0),0.1)

  end
end


function PlaceBlock(pos,scale)
  local copy = models.BBB.bone:copy("block")
  models.BBB.bone2:addChild(copy)
  copy:setVisible(true)
  copy:setPos((pos.x*16),(pos.y*16),(pos.z*16))
  copy:setScale(scale)
  copy:setLight(16)
  copy:setColor(0,0,0,1)

  table.insert(Copies, copy)
  
end  


function Dematerialize()
  if Copies ~= {} then
    for k ,copy in pairs(Copies) do
    copy:getParent():removeChild(copy)
    end
    Copies = {}
  end
end