local Atoms = {}
local Timer = 0
local copyStorage = models:newPart("copyStorage", "WORLD")
function createParticle(particleData)
 
  if Atoms[particleData.position.x*8] == nil then
    Atoms[particleData.position.x*8] = {}
  end
  if Atoms[particleData.position.x*8][particleData.position.y*8] == nil then
    Atoms[particleData.position.x*8][particleData.position.y*8] = {}
  end
  if Atoms[particleData.position.x*8][particleData.position.y*8][particleData.position.z*8] == nil then
    local copy = models.model:copy(":skull:")
    copyStorage:addChild(copy)
    copy:setPos(particleData.position*16)
    if particleData.particle == 1 then
      copy:setColor(0.8+(math.random()-0.5)*0.1,0.8+(math.random()-0.5)*0.1,0.1+(math.random()-0.5)*0.1)
    end
    if particleData.particle == 2 then
      copy:setColor(0.2+(math.random()-0.5)*0.1,0.2+(math.random()-0.5)*0.1,0.8+(math.random()-0.5)*0.1)
    end
    copy:setScale(2)
    copy:setParentType("WORLD")
    copy:setPrimaryRenderType("EMISSIVE_SOLID")
    Atoms[particleData.position.x*8][particleData.position.y*8][particleData.position.z*8] =  {copy,particleData.position,particleData.particle}
  end
end
function events.entity_init()

end
local trigger
function events.tick()
  Timer = Timer + 1
  if Timer%4 == 0 then
    collectGarbage()
  end
iterate()


trigger = false
end


function events.render(delta, context)
if delta > 0.5 and not trigger then
  iterate()

  trigger = true
end  
end


local num = 0
function events.mouse_press(button, action, modifier)
if button == 1 and action == 1 and host:isChatOpen() then
pings.atomCube(2.5,1)
end  
if button == 0 and action == 1 and host:isChatOpen() then
  pings.atomCube(4.5 ,2)
  end 
end
function pings.atomSphere(radius,particle)
  local x,y,z = -radius,-radius,-radius
  for i= 1, (radius*2)^3 do

    if vec(x,y,z):length() <= radius and not world.getBlockState((vec(x,y,z)/8)+(player:getPos()*4):floor()/4):hasCollision() then
      createParticle({position = (vec(x,y,z)/8)+(player:getPos()*4):floor()/4,particle = particle})
      num = num + 1
    end
    x = x + 1
    if x == radius then
      y = y + 1
      x = -radius
    end
    if y == radius then
      z = z + 1
      y = -radius  
    end
  end

end

function pings.atomCube(radius,particle)
  local x,y,z = -radius,-radius,-radius
  for i= 1, (radius*2)^3 do

    if not world.getBlockState((vec(x,y,z)/8)+(player:getPos()*4):floor()/4):hasCollision() then
      createParticle({position = (vec(x,y,z)/8)+(player:getPos()*4):floor()/4,particle = particle})
      num = num + 1
    end
    x = x + 1
    if x == radius then
      y = y + 1
      x = -radius
    end
    if y == radius then
      z = z + 1
      y = -radius  
    end
  end

end

function iterate()

  for i, tablex in pairs(Atoms) do
    for j, tabley in pairs(tablex) do
      for k, atom in pairs(tabley) do
        if atom[3] == 1 then
          if Atoms[atom[2].x*8][(atom[2].y-0.125)*8] == nil then
            Atoms[atom[2].x*8][(atom[2].y-0.125)*8] = {}
          end
          if Atoms[atom[2].x*8][(atom[2].y-0.125)*8][atom[2].z*8] == nil and not world.getBlockState(atom[2]-vec(0,0,0)):hasCollision() then
            atom[2]:sub(0,0.125,0)
            atom[1]:setPos(atom[2]*16+vec(0,2,0))
            Atoms[atom[2].x*8][(atom[2].y)*8][atom[2].z*8] = {atom[1],atom[2],atom[3]}
            Atoms[atom[2].x*8][(atom[2].y+0.125)*8][atom[2].z*8] = nil
            break
          end
  
  

            if Atoms[(atom[2].x-0.125)*8] == nil then
              Atoms[(atom[2].x-0.125)*8] = {}
            end
            if Atoms[(atom[2].x-0.125)*8][(atom[2].y-0.125)*8] == nil then
              Atoms[(atom[2].x-0.125)*8][(atom[2].y-0.125)*8] = {}
            end
            if Atoms[(atom[2].x-0.125)*8][(atom[2].y-0.125)*8][atom[2].z*8] == nil and not world.getBlockState(atom[2]-vec(0.125,0,0)):hasCollision() then
              atom[2]:sub(0.125,0.125,0)
              atom[1]:setPos(atom[2]*16+vec(0,2,0))
              Atoms[(atom[2].x)*8][(atom[2].y)*8][atom[2].z*8] = {atom[1],atom[2],atom[3]}
              Atoms[(atom[2].x+0.125)*8][(atom[2].y+0.125)*8][atom[2].z*8] = nil
              break
            end

  

            if Atoms[(atom[2].x+0.125)*8] == nil then
              Atoms[(atom[2].x+0.125)*8] = {}
            end
            if Atoms[(atom[2].x+0.125)*8][(atom[2].y-0.125)*8] == nil then
              Atoms[(atom[2].x+0.125)*8][(atom[2].y-0.125)*8] = {}
            end
            if Atoms[(atom[2].x+0.125)*8][(atom[2].y-0.125)*8][atom[2].z*8] == nil and not world.getBlockState(atom[2]-vec(-0.125,0,0)):hasCollision() then
              atom[2]:sub(-0.125,0.125,0)
              atom[1]:setPos(atom[2]*16+vec(0,2,0))
              Atoms[(atom[2].x)*8][(atom[2].y)*8][atom[2].z*8] = {atom[1],atom[2],atom[3]}
              Atoms[(atom[2].x-0.125)*8][(atom[2].y+0.125)*8][atom[2].z*8] = nil
              break
            end

  
  

            if Atoms[(atom[2].x)*8][(atom[2].y-0.125)*8][(atom[2].z-0.125)*8] == nil and not world.getBlockState(atom[2]-vec(0,0,0.125)):hasCollision() then
              atom[2]:sub(0,0.125,0.125)
              atom[1]:setPos(atom[2]*16+vec(0,2,0))
              Atoms[(atom[2].x)*8][(atom[2].y)*8][atom[2].z*8] = {atom[1],atom[2],atom[3]}
              Atoms[(atom[2].x)*8][(atom[2].y+0.125)*8][(atom[2].z+0.125)*8] = nil
              break
            end
 
  
  

            if Atoms[(atom[2].x)*8][(atom[2].y-0.125)*8][(atom[2].z+0.125)*8] == nil and not world.getBlockState(atom[2]-vec(0,0,-0.125)):hasCollision() then
              atom[2]:sub(0,0.125,-0.125)
              atom[1]:setPos(atom[2]*16+vec(0,2,0))
              Atoms[(atom[2].x)*8][(atom[2].y)*8][atom[2].z*8] = {atom[1],atom[2],atom[3]}
              Atoms[(atom[2].x)*8][(atom[2].y+0.125)*8][(atom[2].z-0.125)*8] = nil
              break
            end
        
        end

        
        if atom[3] == 2 then
          if Atoms[atom[2].x*8][(atom[2].y-0.125)*8] == nil then
            Atoms[atom[2].x*8][(atom[2].y-0.125)*8] = {}
          end
          if Atoms[atom[2].x*8][(atom[2].y-0.125)*8][atom[2].z*8] == nil and not world.getBlockState(atom[2]-vec(0,0,0)):hasCollision() then
            atom[2]:sub(0,0.125,0)

            atom[1]:setPos(atom[2]*16+vec(0,2,0))
            Atoms[atom[2].x*8][(atom[2].y)*8][atom[2].z*8] = {atom[1],atom[2],atom[3]}
            Atoms[atom[2].x*8][(atom[2].y+0.125)*8][atom[2].z*8] = nil

          end
  











            local counter = 0

            done = false



              local randomdir = math.random(0,3)
          if randomdir == 0  and not done then
            if Atoms[(atom[2].x-0.125)*8] == nil then
              Atoms[(atom[2].x-0.125)*8] = {}
            end
            if Atoms[(atom[2].x-0.125)*8][(atom[2].y)*8] == nil then
              Atoms[(atom[2].x-0.125)*8][(atom[2].y)*8] = {}
            end
            if Atoms[(atom[2].x-0.125)*8][(atom[2].y)*8][atom[2].z*8] == nil and not world.getBlockState(atom[2]-vec(0.125,-0.126,0)):hasCollision() then
              
              atom[2]:sub(0.125,0,0)
              atom[1]:setPos(atom[2]*16+vec(0,2,0))
              Atoms[(atom[2].x)*8][(atom[2].y)*8][atom[2].z*8] = {atom[1],atom[2],atom[3]}
              Atoms[(atom[2].x+0.125)*8][(atom[2].y)*8][atom[2].z*8] = nil
              done = true
              
            end
          end
  
          if randomdir == 1 and not done then 
            if Atoms[(atom[2].x+0.125)*8] == nil then
              Atoms[(atom[2].x+0.125)*8] = {}
            end
            if Atoms[(atom[2].x+0.125)*8][(atom[2].y)*8] == nil then
              Atoms[(atom[2].x+0.125)*8][(atom[2].y)*8] = {}
            end
            if Atoms[(atom[2].x+0.125)*8][(atom[2].y)*8][atom[2].z*8] == nil and not world.getBlockState(atom[2]-vec(-0.125,-0.126,0)):hasCollision() then
              atom[2]:sub(-0.125,0,0)
              atom[1]:setPos(atom[2]*16+vec(0,2,0))
              Atoms[(atom[2].x)*8][(atom[2].y)*8][atom[2].z*8] = {atom[1],atom[2],atom[3]}
              Atoms[(atom[2].x-0.125)*8][(atom[2].y)*8][atom[2].z*8] = nil
              done = true
              
            end
          end
  
  
          if randomdir == 2 and not done  then
            if Atoms[(atom[2].x)*8][(atom[2].y)*8][(atom[2].z-0.125)*8] == nil and not world.getBlockState(atom[2]-vec(0,-0.126,0.125)):hasCollision() then
              atom[2]:sub(0,0,0.125)
              atom[1]:setPos(atom[2]*16+vec(0,2,0))
              Atoms[(atom[2].x)*8][(atom[2].y)*8][atom[2].z*8] = {atom[1],atom[2],atom[3]}
              Atoms[(atom[2].x)*8][(atom[2].y)*8][(atom[2].z+0.125)*8] = nil
              done = true
              
            end
          end
  
          if randomdir == 3 and not done then
            if Atoms[(atom[2].x)*8][(atom[2].y)*8][(atom[2].z+0.125)*8] == nil and not world.getBlockState(atom[2]-vec(0,-0.126,-0.125)):hasCollision() then
              atom[2]:sub(0,0,-0.125)
              atom[1]:setPos(atom[2]*16+vec(0,2,0))
              Atoms[(atom[2].x)*8][(atom[2].y)*8][atom[2].z*8] = {atom[1],atom[2],atom[3]}
              Atoms[(atom[2].x)*8][(atom[2].y)*8][(atom[2].z-0.125)*8] = nil
              done = true

            
          end
        end

        if done then
          break
        end 
        end
      end
    end
  end
end  



function collectGarbage()
  for i, tablex in pairs(Atoms) do
    for j, tabley in pairs(tablex) do
      for k, atom in pairs(tabley) do
        if not next(atom) then
          Atoms[i][j][k] = nil
        end
      end
      if not next(tabley) then
        Atoms[i][j] = nil
      end
    end
    if not next(tablex) then
      Atoms[i] = nil
    end
  end

end  