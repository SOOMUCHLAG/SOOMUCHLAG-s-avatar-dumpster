local mRandom = math.random
if love then mRandom = love.math.random end
local mRandomSeed = math.randomseed
if love then mRandomSeed = love.math.setRandomSeed end

local rand = { mySeed = 1, lastN = -1 }

 function rand:get(seed, n)
  if n <= 0 then n = -2 * n
  else n = 2 * n - 1
  end

  if seed ~= self.mySeed or self.lastN < 0 or n <= self.lastN then
    self.mySeed = seed
    mRandomSeed(seed)
    self.lastN = -1
  end
  while self.lastN < n do
    num = mRandom()
    self.lastN = self.lastN + 1
  end
  return num - 0.5
end

 function rand:num()
  rand.lastN = -1
  return mRandom() - 0.5
end

-- takes table of L values and returns N*(L-3) interpolated values
local function interpolate1D(values, N)
  local newData = {}
  for i = 1, #values - 3 do
    local P = (values[i+3] - values[i+2]) - (values[i] - values[i+1])
    local Q = (values[i] - values[i+1]) - P
    local R = (values[i+2] - values[i])
    local S = values[i+1]
    for j = 0, N-1 do
      local x = j/N
      table.insert(newData, P*x^3 + Q*x^2 + R*x + S)
    end
  end
  return newData
end

local function perlinComponent1D(seed, length, N, amplitude)
  local rawData = {}
  local finalData = {}
  for i = 1, math.ceil(length/N) + 3 do
 rawData[i] = amplitude * rand:get(seed, i)
  end
  local interpData = interpolate1D(rawData, N)
  assert(#interpData >= length)
  for i = 1, length do
    finalData[i] = interpData[i]
  end
  return finalData
end

local function OneD(seed, length, persistence, N, amplitude)
  local min, max = 0, 0
  local data = {}
  for i = 1, length do
    data[i] = 0
  end
  for i = N, 1, -1 do
    local compInterp = 2^(i-1)
    local compAmplitude = amplitude * persistence^(N-i)
    local comp = perlinComponent1D(seed+i, length, i, compAmplitude)
    for i = 1, length do
      data[i] = data[i] + comp[i]
      if data[i] > max then max = data[i] end
      if data[i] < min then min = data[i]  end
    end
  end
  return data, min, max
end

local function interpolate2D(values, N)
  local newData1 = {}
  for r = 1, #values do
    newData1[r] = {}
    for c = 1, #values[r] - 3 do
      local P = (values[r][c+3] - values[r][c+2]) - (values[r][c] - values[r][c+1])
      local Q = (values[r][c] - values[r][c+1]) - P
      local R = (values[r][c+2] - values[r][c])
      local S = values[r][c+1]
      for j = 0, N-1 do
        local x = j/N
        table.insert(newData1[r], P*x^3 + Q*x^2 + R*x + S)
      end
    end
  end
  
  local newData2 = {}
  for r = 1, (#newData1-3) * N do
    newData2[r] = {}
  end
  for c = 1, #newData1[1] do
    for r = 1, #newData1 - 3 do
      local P = (newData1[r+3][c] - newData1[r+2][c]) - (newData1[r][c] - newData1[r+1][c])
      local Q = (newData1[r][c] - newData1[r+1][c]) - P
      local R = (newData1[r+2][c] - newData1[r][c])
      local S = newData1[r+1][c]
      for j = 0, N-1 do
        local x = j/N
        newData2[(r-1)*N+j+1][c] = P*x^3 + Q*x^2 + R*x + S
      end
    end
  end
  
  return newData2
end

local function perlinComponent2D(seed, width, height, N, amplitude)
  local rawData = {}
  local finalData = {}
  for r = 1, math.ceil(height/N) + 3 do
    rawData[r] = {}
    for c = 1, math.ceil(width/N) + 3 do
      rawData[r][c] = amplitude * rand:get(seed+r, c)
    end
  end
  local interpData = interpolate2D(rawData, N)
  assert(#interpData >= height and #interpData[1] >= width)
  for r = 1, height do
    finalData[r] = {}
    for c = 1, width do
      finalData[r][c] = interpData[r][c]
    end
  end
  return finalData
end

local function TwoD(seed, width, height, persistence, N, amplitude)
  local data = {}
  for r = 1, height do
    data[r] = {}
    for c = 1, width do
      data[r][c] = 0
    end
  end
  local min, max = 0, 0
  for i = 1, N do
    local compInterp = 2^(N-i)
    local compAmplitude = amplitude * (persistence^(i-1))
    local comp = perlinComponent2D(seed+i*1000, width, height, compInterp, compAmplitude)
    for r = 1, height do
      for c = 1, width do
        data[r][c] = data[r][c] + comp[r][c]
        if data[r][c] < min then min = data[r][c] end
        if data[r][c] > max then max = data[r][c] end
      end
    end
  end
  return data, min, max
end

local Perlin = {
  OneD = OneD,
  TwoD = TwoD,
}
Textsize =60
x=0
y=0
number = 0
timer = 0
Copies = {}
Sprites = {}
models.Body:setParentType("WORLD")
models.Copystore:setParentType("WORLD")
function events.entity_init()
  pos = vec(math.floor(player:getPos().x-Textsize/2),math.floor(player:getPos().y),math.floor(player:getPos().z-Textsize/2))
  if Sprites ~= {} then
    for k ,sprite in pairs(Sprites) do
    sprite:remove()
    end
    Sprites = {}
  end
  if Copies ~= {} then
    for k ,copy in pairs(Copies) do
    copy:getParent():removeChild(copy)
    end
    Copies = {}
  end
  noise = TwoD((player:getPos().x+player:getPos().y+player:getPos().z)*5, Textsize, Textsize, 0.45, 7, 1)
  mytext = textures:newTexture("Name", Textsize, Textsize)
  x=0
  y=0
  for i=0, Textsize*Textsize do

  if x < Textsize and y <Textsize then
  mytext:setPixel(x, y, vectors.hsvToRGB(0,0,-noise[x+1][y+1]+0.2))

  end
  x=x+1
  
  if x > Textsize-1 then
    x = 0 
    y = y+1
  end
end
x1 = 0
y1 = 0
smalltext = textures:newTexture(""..math.random(), 1, 1)
smalltext:setPixel(0,0,1,1,1)
local detail = 3
local height = 90
for i = 1, Textsize*Textsize do
  
  if x1 < Textsize and y1 <Textsize then

local mysprite = models.Body:newSprite(""..x1..y1..math.random()):setTexture(smalltext,1,1):setRot(0,0,0):setColor(mytext:getPixel(x1,y1)):setPos(Textsize*16/2,0,Textsize*16/2)
if noise[x1+2] ~= nil and noise[x1+2][y1+2] ~= nil then
mysprite:getVertices()[1]:setPos(-pos*16+vec(y1,noise[x1+1][y1+1]*height,x1)*detail+vec(0,0,32*pos.z))
mysprite:getVertices()[2]:setPos(-pos*16+vec(y1+1,noise[x1+1][y1+2]*height,x1)*detail+vec(0,0,32*pos.z))
mysprite:getVertices()[3]:setPos(-pos*16+vec(y1+1,noise[x1+2][y1+2]*height,x1+1)*detail+vec(0,0,32*pos.z))
mysprite:getVertices()[4]:setPos(-pos*16+vec(y1,noise[x1+2][y1+1]*height,x1+1)*detail+vec(0,0,32*pos.z))
end

table.insert(Sprites,mysprite)

end
x1=x1+1

if x1 > Textsize then

  x1 = 0 
  y1 = y1+1

end

end


end
number1 = 0
x2 = 0
y2 = 0
function events.tick()
 -- log(((number1/(Textsize*Textsize))*100).."%")
  --[[
  if number1 < Textsize^2 then
for i = 1, 21 do 
number1 = number1 + 1
if noise[x2+1][y2+1] ~= nil then
  
host:sendChatCommand("setblock "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*16,x2)).x).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*4,x2)).y).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16,x2)).z).." grass_block")
host:sendChatCommand("setblock "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*16,x2)).x).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*4,x2)).y-1).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16,x2)).z).." dirt")
host:sendChatCommand("setblock "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*16,x2)).x).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*4,x2)).y-2).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16,x2)).z).." dirt")
for f = 1,100 do
host:sendChatCommand("setblock "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*16,x2)).x).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*4,x2)).y-2-f).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16,x2)).z).." stone")
end

host:sendChatCommand("setblock "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*16,x2)).x).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*4,x2)).y).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16,x2)).z).." barrier")
host:sendChatCommand("setblock "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*16,x2)).x).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*4-1,x2)).y).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16,x2)).z).." barrier")
host:sendChatCommand("setblock "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*16,x2)).x).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*4-2,x2)).y).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16,x2)).z).." barrier")
host:sendChatCommand("setblock "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*16,x2)).x).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*4-3,x2)).y).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16,x2)).z).." barrier")
host:sendChatCommand("setblock "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*16,x2)).x).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16*4-4,x2)).y).." "..math.floor((pos+vec(y2,(noise[x2+1][y2+1]+0.5)*120/16,x2)).z).." barrier")
end

x2=x2+1

if x2 == Textsize then

  x2 = 0 
  y2 = y2+1

end
end  
end
]]
end


function events.key_press(key, action, modifier)
if key == 74 and action == 1 then
Demat()
end  
if key == 75 and action == 1 then
  Mat()
  end  
end

function Demat()
for i, copy in pairs(Copies) do 
copy:setVisible(false)
end  
end  
function Mat()
  for i, copy in pairs(Copies) do 
  copy:setVisible(true)
  end  
  end  








